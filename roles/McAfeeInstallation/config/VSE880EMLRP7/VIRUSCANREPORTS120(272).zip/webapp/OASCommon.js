// "ExtensionMode" enumeration
var g_ExtensionMode = 0;
var g_AllFiles      = 1;
var g_DefaultPlus   = 2;
var g_Default       = 3;
var g_Specified     = 4;

 // Exclusions constants to OR against the "flags" value..
var ON_READ 		= 2;
var ON_WRITE		= 1;
var INCLUDE_SUBFOLDERS	= 4;

var ACTION_VALUE_INVALID	= 0;
var ACTION_VALUE_DENY	    = 1;
var ACTION_VALUE_MOVE     	= 3;
var ACTION_VALUE_DELETE		= 4;
var ACTION_VALUE_CLEAN		= 5;
var ACTION_VALUE_CONTINUE   = 6;

var g_iCurrentPrimaryActionValue 			= 0;
var g_iCurrentPrimaryActionUnwantedValue 	= 0;
var g_iCurrentSecondaryActionValue			= 0;
var g_iCurrentSecondaryActionUnwantedValue	= 0;

// Global DOM objects
var g_primaryActionSelect;
var g_secondaryActionSelect;
var g_primaryActionSelectUnwanted;
var g_secondaryActionSelectUnwanted;

function fnApplyPolicySuccess()
{
    OrionCore.doAction("/PolicyMgmt/PolicyCatalog.do");
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function fnSetDetectionValues()
{
    var allFilesRadio = document.getElementById("radioID_AllFiles").checked;
    var defaultFilesRadio = document.getElementById("radioID_DefaultAndSpecified").checked;
    var specifiedFilesRadio = document.getElementById("radioID_SpecifiedOnly").checked;
    var scanForMacrosCheckbox = document.getElementById("checkboxID_ScanForMarcros").checked;
    var additionalFileTypesTextArea = document.getElementById("ID_AdditionalFileTypes");
    var specifiedFileTypesTextArea = document.getElementById("ID_SpecifiedFileTypes");
    var extensionMode=g_AllFiles;

    document.getElementById(Constants.OAS_COMMON_INCLUDE_EXTS).value = additionalFileTypesTextArea.value;
    document.getElementById(Constants.OAS_COMMON_PROG_EXTS).value = specifiedFileTypesTextArea.value;

    if(allFilesRadio)
    {
        extensionMode = g_AllFiles;
    }
    else if(defaultFilesRadio)
    {
        if(scanForMacrosCheckbox)
        {
            extensionMode = g_DefaultPlus;
        }
        else
        {
            extensionMode = g_Default;
        }
    }
    else
    {
        extensionMode = g_Specified;
    }

    document.getElementById(Constants.OAS_COMMON_LOCAL_EXTENSION_MODE).value = extensionMode;
    document.getElementById(Constants.OAS_COMMON_NETWORK_EXTENSION_MODE).value = extensionMode;
}

function fnSetExclusionsValues()
{
    document.getElementById(Constants.OAS_COMMON_APPEND_EXCLUSIONS).value = !document.getElementById("checkboxID_OverwriteClient").checked;
}

function selectExclItemChange(exclItem)
{
    var itemValue = exclItem.value;
    var itemID = exclItem.id.replace("select_exclusion_", "");
    var patternDivElement = $("div_exclpattern_" + itemID);
    var filetypeDivElement = $("div_exclfiletype_" + itemID);
    var fileageDivElement = $("div_exclfileage_" + itemID);

    if(itemValue == '0')
    {
        patternDivElement.style.display = "none";
        filetypeDivElement.style.display = "none";
        fileageDivElement.style.display = "none";
    }
    else if(itemValue == '1')
    {
        patternDivElement.style.display = "inline";
        filetypeDivElement.style.display = "none";
        fileageDivElement.style.display = "none";
    }
    else if(itemValue == '2')
    {
        patternDivElement.style.display = "none";
        filetypeDivElement.style.display = "inline";
        fileageDivElement.style.display = "none";
    }
    else if(itemValue == '3')
    {
        patternDivElement.style.display = "none";
        filetypeDivElement.style.display = "none";
        fileageDivElement.style.display = "inline";
    }
    else if(itemValue == '4')
    {
        patternDivElement.style.display = "none";
        filetypeDivElement.style.display = "none";
        fileageDivElement.style.display = "none";
    }

    updateExclusionItemData(itemID);
}

function exclInputKeyup(exclInputItem)
{
    var itemID = exclInputItem.id.substring(exclInputItem.id.lastIndexOf("_")+1, exclInputItem.id.length);

    updateExclusionItemData(itemID);

    epoEnableApplyButton();
}

function updateExclusionItemData(exclItemID)
{
    var selectedExclusionType = $("select_exclusion_" + exclItemID).value;
    var exclusionDataElement = $("hidden_exclusion_data_" + exclItemID);
    var exclusionData = "||";

    if(selectedExclusionType == '0')
    {
        exclusionData = "||";
    }
    else if(selectedExclusionType == '1')
    {
        var exclFlags = (ON_READ+ON_WRITE);
        var exclPattern = $("excl_pattern_" + exclItemID).value;

        if(exclPattern != "")
        {
            if($("excl_subfolders_" + exclItemID).checked)
            {
                exclFlags += INCLUDE_SUBFOLDERS;
            }
            exclusionData = "3|" + exclFlags + "|" + exclPattern;
        }
    }
    else if(selectedExclusionType == '2')
    {
        var exclFiletype = $("excl_filetype_"+ exclItemID).value;

        if(exclFiletype != "")
        {
            exclusionData = "4|" + (ON_READ+ON_WRITE) + "|" + exclFiletype;
        }
    }
    else if(selectedExclusionType == '3')
    {
        var exclAccessType = $("select_fileage_accesstype_" + exclItemID).value;
        var exclFileAge = $("excl_fileage_" + exclItemID).value;

        if(exclFileAge != "")
        {
            exclusionData =  exclAccessType + "|" + (ON_READ+ON_WRITE) + "|" + exclFileAge;
        }
    }
    else if(selectedExclusionType == '4')
    {
        exclusionData = "5|" + (ON_READ+ON_WRITE) + "|";
    }

    exclusionDataElement.value = exclusionData;
}

function exclAddCallback(newDiv)
{
    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("exclusionsList_awrow_", "");
        var selectedExclusionType = $("select_exclusion_" + itemID);
        var hiddenValueName = "exclusionsList_hiddenvalue_" + itemID;
        var hiddenValueElement = $(hiddenValueName);
        var hiddenValue = "||";

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        if(hiddenValue != "||" && hiddenValue !="")
        {
            var exclusionSplit = hiddenValue.split("|");
            if(exclusionSplit.length > 0)
            {
                // exclusion is by age
                if(exclusionSplit[0] >= "0" && exclusionSplit[0] <= "2")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        var selectAccessType = $("select_fileage_accesstype_" + itemID);
                        var exclFileAge = $("excl_fileage_" + itemID);

                        selectedExclusionType.selectedIndex = 3;
                        selectAccessType.value = exclusionSplit[0];
                        exclFileAge.value = exclusionSplit[2];
                    }
                }
                // By pattern
                else if(exclusionSplit[0] == "3")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        var exclPattern = $("excl_pattern_" + itemID);
                        var exclSubfoldersCheckbox = $("excl_subfolders_" + itemID);

                        selectedExclusionType.selectedIndex = 1;
                        if(exclusionSplit[1] == "7")
                        {
                            exclSubfoldersCheckbox.checked = true;
                        }
                        else
                        {
                            exclSubfoldersCheckbox.checked = false;
                        }
                        exclPattern.value = exclusionSplit[2];
                    }
                }
                // By file type
                else if(exclusionSplit[0] == "4")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        var exclFileType = $("excl_filetype_" + itemID);

                        selectedExclusionType.selectedIndex = 2;
                        exclFileType.value = exclusionSplit[2];
                    }
                }
                // Windows Filexe Protection
                else if(exclusionSplit[0] == "5")
                {
                    selectedExclusionType.selectedIndex = 4;
                }
                // Unknown -- should never get here
                else
                {
                    selectedExclusionType.selectedIndex = 0;
                }
            }
        }

        selectExclItemChange(selectedExclusionType);
        updateExclIDList();
        updateExclusionItemData(newDiv.id.replace("exclusionsList_awrow_", ""));
    }
}

function exclRemoveCallback()
{
    updateExclIDList();
}

function updateExclIDList()
{
    // update the hidden list of element ID's containing values
    var myrows = g_exclusionsAddWidget.getList();
    var elementIDList = "";
    for(var i in myrows)
    {
        var currentItemID = myrows[i].replace("exclusionsList_awrow_", "");
        elementIDList += ("hidden_exclusion_data_" + currentItemID+ ",");
    }

    $("hiddenID_ExclusionItemIDList").value = elementIDList.substring(0, elementIDList.length-1);
}

function fnSetPrimaryAction(selectID_CurrentAction, iPrimaryValue)
{
	for (var i = 0; i < selectID_CurrentAction.length; i++)
	{
		if ( parseInt(selectID_CurrentAction.options[i].value) == parseInt(iPrimaryValue) )
		{
			selectID_CurrentAction.selectedIndex = i;
		}
	}
}

function fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue)
{
	for(var i=0; i<selectID_CurrentSecondaryAction.length;i++)
	{
		if (selectID_CurrentSecondaryAction.options[i].value == iSecondaryValue)
		{
			selectID_CurrentSecondaryAction.selectedIndex = i;
		}
	}
}

function fnSecondaryAction_OnChange(selectID_CurrentSecondaryAction, iSecondaryValue, bPromptForDelete)
{
    if( selectID_CurrentSecondaryAction == g_secondaryActionSelect )
    {
        g_iCurrentSecondaryActionValue = iSecondaryValue;
    }
    else if( selectID_CurrentSecondaryAction == g_secondaryActionSelectUnwanted )
    {
        g_iCurrentSecondaryActionProgramValue = iSecondaryValue;
    }

    fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue);
}

function fnApplyNVPChange()
{
    fnToggleApplyNVPState();
    epoEnableApplyButton();
}

function fnToggleApplyNVPState()
{
    if (document.getElementById(Constants.OAS_COMMON_APPLY_NVP).checked)
    {
        document.getElementById("selectID_UnwantedPrimaryAction").disabled = false;

        if((document.getElementById("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_CONTINUE)&&
           (document.getElementById("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_DENY))
        {
            document.getElementById("selectID_UnwantedSecondaryAction").disabled = false;
        }
        else
        {
            document.getElementById("selectID_UnwantedSecondaryAction").disabled = true;
        }
    }
    else
    {
        document.getElementById("selectID_UnwantedPrimaryAction").disabled = true;
        document.getElementById("selectID_UnwantedSecondaryAction").disabled = true;
    }
}

function fnSetActionsValues()
{
    document.getElementById(Constants.OAS_COMMON_ACTION).value = g_primaryActionSelect.value;
    document.getElementById(Constants.OAS_COMMON_SEC_ACTION).value = g_secondaryActionSelect.value;
    document.getElementById(Constants.OAS_COMMON_ACTION_PROGRAM).value = g_primaryActionSelectUnwanted.value;
    document.getElementById(Constants.OAS_COMMON_SEC_ACTION_PROGRAM).value = g_secondaryActionSelectUnwanted.value;
}

function selectAppItemChange(appItem)
{
    var itemValue = appItem.value;
    var itemID = appItem.id.replace("select_application_", "");
    var patternDivElement = $("div_apppattern_" + itemID);
    var filetypeDivElement = $("div_appfiletype_" + itemID);
    var fileageDivElement = $("div_appfileage_" + itemID);

    if(itemValue == '0')
    {
        patternDivElement.style.display = "none";
        filetypeDivElement.style.display = "none";
        fileageDivElement.style.display = "none";
    }
    else if(itemValue == '1')
    {
        patternDivElement.style.display = "inline";
        filetypeDivElement.style.display = "none";
        fileageDivElement.style.display = "none";
    }
    else if(itemValue == '2')
    {
        patternDivElement.style.display = "none";
        filetypeDivElement.style.display = "inline";
        fileageDivElement.style.display = "none";
    }
    else if(itemValue == '3')
    {
        patternDivElement.style.display = "none";
        filetypeDivElement.style.display = "none";
        fileageDivElement.style.display = "inline";
    }
    else if(itemValue == '4')
    {
        patternDivElement.style.display = "none";
        filetypeDivElement.style.display = "none";
        fileageDivElement.style.display = "none";
    }
}

function appInputKeyup(appInputItem)
{
    epoEnableApplyButton();
}

function appAddCallback(newDiv)
{
    updateAppIDList();
}

function appRemoveCallback()
{
    updateAppIDList();
}

function updateAppIDList()
{
    // update the hidden list of element ID's containing values
    var myrows = g_applicationsAddWidget.getList();
    var elementIDList = "";
    for(var i in myrows)
    {
        var currentItemID = myrows[i].replace("applicationsList_awrow_", "");
        elementIDList += ("app_filetype_" + currentItemID+ ",");
    }

    $("hiddenID_ApplicationItemIDList").value = elementIDList.substring(0, elementIDList.length-1);
}