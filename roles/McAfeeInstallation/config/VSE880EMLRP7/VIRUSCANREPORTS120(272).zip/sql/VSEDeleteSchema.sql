-------------------------------------------------------------------------------
--
-- VSEDeleteSchema.sql : Remove the DB schema created by the extension.
--
-- Copyright (c) 2010 McAfee, Inc.  All Rights Reserved.
--
-------------------------------------------------------------------------------
 IF EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = OBJECT_ID(N'[dbo].[FK_VSECustomProps_EPOProductProperties]') AND type = 'F')
 	ALTER TABLE [dbo].[VSECustomProps] DROP CONSTRAINT [FK_VSECustomProps_EPOProductProperties]
 GO
 
if  exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[VSECustomProps]') AND type in (N'U'))
  DROP TABLE [dbo].[VSECustomProps]
GO

 IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[VSECustomPropsView]'))
     DROP VIEW [dbo].[VSECustomPropsView]
 GO

IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[VSEadditionalpropsView]'))
     DROP VIEW [dbo].[VSEadditionalpropsView]
 GO

IF EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = OBJECT_ID(N'[dbo].[FK_VSECustomEvent_EPOEvents]') AND type = 'F')
 	ALTER TABLE [dbo].[VSECustomEvent] DROP CONSTRAINT [FK_VSECustomEvent_EPOEvents]
 GO

if  exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[VSECustomEvent]') AND type in (N'U'))
  DROP TABLE [dbo].[VSECustomEvent]
GO