-----------------------------------------------------------
-- VSE_ReplaceIPV6Zeros (Utility Function)
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects
			 WHERE name = 'VSE_ReplaceIPV6Zeros'
			   AND type = 'FN' )
	DROP FUNCTION dbo.VSE_ReplaceIPV6Zeros
GO

CREATE FUNCTION dbo.VSE_ReplaceIPV6Zeros(@HexStr VARCHAR(50)) RETURNS VARCHAR(50)
AS
BEGIN

DECLARE @LoopIndex	[SMALLINT]
DECLARE @Result    	[VARCHAR] (2000)
DECLARE @octet		[VARCHAR] (5)
DECLARE @count		[SMALLINT]
DECLARE @consec		[VARCHAR]  (100)
DECLARE @diff		[SMALLINT]

SET @count = 0
SET @Result = ''
SET @LoopIndex = 0
SET @octet = ''
SET @consec = ''
SET @diff = 0

SET @count = LEN(@HexStr) - LEN(REPLACE(@HexStr,':',''))

IF(@count = 0)
BEGIN
  RETURN @Result
END

/*
End the IPv6 address with 0000 if the given string ends with ':'
*/
IF(SUBSTRING(REVERSE(@HexStr),1,1) = ':')
BEGIN
	SET @HexStr = @HexStr +'0000'
END

/*
Substitue zeros for continuous '::' in the IPv6 address
*/
WHILE(@count < 7)
BEGIN
	SET @LoopIndex = CHARINDEX(N':', @HexStr, @LoopIndex+1)
	SET @diff = CHARINDEX(N':', @HexStr, @LoopIndex+1) - @LoopIndex
	IF(@diff = 1)
	BEGIN
		WHILE(@count < 8)
		BEGIN
			SET @consec='0000:'+@consec
			SET @count = @count+1
		END
		IF(@LoopIndex = 1)
		BEGIN
			SET @HexStr = '0000'+SUBSTRING(@HexStr, 1, @LoopIndex)+@consec+SUBSTRING(@HexStr,@LoopIndex+2,LEN(@HexStr))
		END
		ELSE
		BEGIN
			SET @HexStr = SUBSTRING(@HexStr, 1, @LoopIndex)+@consec+SUBSTRING(@HexStr,@LoopIndex+2,LEN(@HexStr))
		END
	END
END

/*
Make length of each octect 4 by prepending 0s. This will be make the IP address in long form and easier to convert to Binary format
*/
WHILE (@HexStr <> '')
BEGIN
	SET @LoopIndex = CHARINDEX(N':',@HexStr)
	IF (@LoopIndex = 0)
	BEGIN
		WHILE(LEN(@HexStr) < 4)
		BEGIN
			SET @HexStr = '0'+@HexStr
		END
		SET @Result = @Result + @HexStr
		SET @HexStr = ''
	END
	ELSE
	BEGIN
		SET @octet = SUBSTRING(@HexStr,1,@LoopIndex)
		WHILE(LEN(@octet) < 5)
		begin
			SET @octet = '0'+@octet
		end
		SET @Result = @Result + @octet
		SET @HexStr = SUBSTRING(@HexStr, @LoopIndex+1, LEN(@HexStr))
	END
END

RETURN @Result
END

GO

-----------------------------------------------------------
-- VSE_HexStrToVarBin  (Utility Function)
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects
			 WHERE name = 'VSE_HexStrToVarBin'
			   AND type = 'FN' )
	DROP FUNCTION dbo.VSE_HexStrToVarBin
GO

CREATE FUNCTION dbo.VSE_HexStrToVarBin(@HexStr VARCHAR(50)) returns VARBINARY(140)
/*
** Convert a hex string to it's varbinary equivalent value.
**
** Returns null on an invalid hex string input.
*/
AS
BEGIN

   DECLARE @Length	[INT]
   DECLARE @Pos 	[INT]
   DECLARE @Digit1 	[TINYINT]
   DECLARE @Digit2 	[TINYINT]
   DECLARE @Val 	[BINARY]  	(1)
   DECLARE @Result 	[VARBINARY]	(140)

   -- Ensure we're working with lowercase hex characters.

   SET @HexStr = LOWER(@HexStr)

   -- Remove the leading hex designator (0x) if it's there.

   IF (SUBSTRING(@HexStr, 1, 2) = '0x')
      SET @HexStr = SUBSTRING(@HexStr,3,37)

   -- Convert 0 or no digit case to 4 zeros

   SET @HexStr = dbo.VSE_ReplaceIPV6Zeros(@HexStr)

   SET @HexStr = REPLACE(@HexStr,':','')

   -- Ensure we have an even number of hex digits.
   IF (LEN(@HexStr) % 2 = 1)
      SET @HexStr = '0' + @HexStr

   -- Initialise working variables.
   SET @Result = 0x
   SET @Pos = 1
   SET @Length = LEN(@HexStr)

   -- Loop over string and build binary Val.
   WHILE @Pos < @Length
   BEGIN
      SET @Digit1 = ASCII(SUBSTRING(@HexStr, @Pos, 1))
      SET @Digit2 = ASCII(SUBSTRING(@HexStr, @Pos + 1, 1))

      IF (@Digit1 not between 48 and 57 and @Digit1 not between 97 and 102) OR
         (@Digit2 not between 48 and 57 and @Digit2 not between 97 and 102)
         RETURN NULL

      SET @Val = 16 * (@Digit1 - CASE WHEN @Digit1 < 58 THEN 48 ELSE 87 END)
                      + (@Digit2 - CASE WHEN @Digit2 < 58 THEN 48 ELSE 87 END)

      SET @Result = @Result + @Val
      SET @Pos = @Pos + 2
   END

   RETURN @Result
END
GO

-----------------------------------------------------------
-----------------------------------------------------------
-- VSE_InsertBehaviourBlockEvent (File Block)
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertBehaviourBlockEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertBehaviourBlockEvent
GO

CREATE PROCEDURE dbo.VSE_InsertBehaviourBlockEvent
(
@AgentGUID 		[UNIQUEIDENTIFIER],
@UserName 		[NVARCHAR] (32),
@MachineName 		[NVARCHAR] (512),
@OSName			[NVARCHAR] (260), -- parameter not mapped to any field in table
@IPAddress 		[NVARCHAR] (48),
@TimeZoneBias		[NVARCHAR] (260), -- parameter not mapped to any field in table
@ProductFamily		[NVARCHAR] (260), -- parameter not mapped to any field in table	
@ProductName 		[NVARCHAR] (64),	
@ProductVersion 	[NVARCHAR] (16),
@ScannerType		[NVARCHAR] (260), -- parameter not mapped to any field in table
@TaskName 		[NVARCHAR] (128),
@lEventID 		[INT],
@Severity 		[INT],
@LocalTime 		[DATETIME],
@UTCTime 		[DATETIME],
@RuleName 		[NVARCHAR] (260),
@ProcessName 		[NVARCHAR] (260),
@FileName		[NVARCHAR] (260),
@Source			[NVARCHAR] (260),
@lActionsBlocked	[INT]
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @TmpAnalyzer NVARCHAR(16)	
	DECLARE @TmpAnalyzerIPV4 INT
	DECLARE @TmpAnalyzerIPV6 AS BINARY(16)
	DECLARE @TmpSource NVARCHAR(128)
	DECLARE @TmpSourceIPV4 INT
	DECLARE @TmpSourceIPV6 AS BINARY(16)
	DECLARE @TmpSourceHostName NVARCHAR(128)
	DECLARE @TmpSourceProcessName NVARCHAR(128)
	DECLARE @TmpTargetPort INT
	DECLARE @TmpThreatActionTaken NVARCHAR(24)
	DECLARE @TmpThreatEventID INT
	DECLARE @TmpThreatCategory NVARCHAR(128)
	DECLARE @TmpSeverity TINYINT
	DECLARE @TmpThreatHandled TINYINT

	DECLARE @IP AS BIGINT
	DECLARE @EventID INT
	
	IF RIGHT(@ScannerType, LEN('2B^|2B')) = '2B^|2B'
	BEGIN
		SELECT @TmpAnalyzer = LEFT(@ScannerType, LEN(@ScannerType) - LEN('2B^|2B'))
	END
	ELSE
	BEGIN
		IF @ProductVersion = '8.0'
		OR @ProductVersion LIKE '8.0%'
		BEGIN
        		SELECT @TmpAnalyzer = 'VIRUSCAN8000'
    		END
		ELSE IF @ProductVersion = '8.5'
		OR @ProductVersion LIKE '8.5%'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8600'
		END
		ELSE IF @ProductVersion = '8.7' OR @ProductVersion = '8.7.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8700'
		END
        ELSE IF @ProductVersion = '8.8' OR @ProductVersion = '8.8.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8800'
		END
		ELSE
		BEGIN
	    		SELECT @TmpAnalyzer = 'Unknown'
		END
	END

	IF @lEventID > 20000
	BEGIN
		SET @TmpThreatEventID = @lEventID - 20000
	END
	ELSE
	BEGIN
		SET @TmpThreatEventID = @lEventID
	END
		
	IF @TmpThreatEventID IN (1024, 1026, 1037, 1051, 1053, 1059, 1061, 1095, 1096, 1099, 1100, 1103, 1202, 1203, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413, 2001, 1034, 1064, 1065, 1067, 1087, 1088, 1089, 1035, 1038, 1039, 1118, 1119, 1120, 1121, 1129, 4700, 4702, 1335, 1336)
	AND @TaskName <> 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1024, 1026, 1037, 1053, 1061, 1100, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'access denied'
	END
	ELSE IF @TmpThreatEventID IN (1087, 1088)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1023, 1430)
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1025, 1060)
	BEGIN
		SET @TmpThreatActionTaken = 'cleaned'
	END
	ELSE IF @TmpThreatEventID IN (1027, 1028, 1054, 1055, 1101, 1104, 1278, 1279, 1280, 1281, 1293, 1303, 1306, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1405, 1408, 1410, 1414, 1415, 1416, 1417, 1418, 1419, 1420)
	BEGIN
		SET @TmpThreatActionTaken = 'deleted'
	END
	ELSE IF @TmpThreatEventID IN (1032, 1056, 1102, 1270, 1271, 1272, 1273, 1297, 1301, 1309, 1403, 1406, 1412)
	BEGIN
		SET @TmpThreatActionTaken = 'moved'
	END
	ELSE IF @TmpThreatEventID IN (1091, 1093, 1094)
	BEGIN
		SET @TmpThreatActionTaken = 'blocked'
	END
	ELSE IF @TmpThreatEventID IN (1096, 1099)
	BEGIN
		SET @TmpThreatActionTaken = 'would block'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'deny create'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'deny read'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'deny write'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'deny terminate'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny create'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny read'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny write'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny terminate'
	END
	ELSE
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END

	IF @lEventID in (1024, 1025, 1026, 1027, 1028, 1032, 1037, 1060, 1061, 1091, 1103, 1270, 1272, 1273, 1274, 1276, 1277, 1278, 1280, 1281, 1282, 1284, 1285, 1289, 1290, 1292, 1293, 1294, 1296, 1297, 1298, 1300, 1306, 1307, 1309, 1310, 1312, 1313, 1314, 1315, 1317, 1318, 1319, 1322, 1323, 1326, 1327, 1328)
	BEGIN
		SET @TmpThreatCategory = 'av.detect'
	END
	ELSE IF @lEventID in (1053, 1054, 1055, 1056, 1100, 1101, 1102, 1104, 1271, 1275, 1279, 1283, 1291, 1301, 1302, 1303, 1304, 1305, 1308, 1311, 1316, 1320, 1321, 1324, 1325)
	BEGIN
		SET @TmpThreatCategory = 'av.detect.heuristics'
	END
	ELSE IF @lEventID > 20000
	BEGIN
		SET @TmpThreatCategory = 'av.pup'
	END
	ELSE IF @lEventID in (1094, 1096)
	BEGIN
		SET @TmpThreatCategory = 'fw.detect'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName NOT LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.file'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.registry'
	END
	ELSE IF @lEventID in (1093, 1099)
	BEGIN
		SET @TmpThreatCategory = 'hip.bo'
	END
	ELSE IF @lEventID in (1051, 1059, 2001)
	BEGIN
		SET @TmpThreatCategory = 'ops'
	END		
	ELSE IF @lEventID in (1087)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.start'
	END	
	ELSE IF @lEventID in (1088)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.end'
	END
	ELSE IF @lEventID in (1202, 1335)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.start'
	END
	ELSE IF @lEventID in (1034, 1038, 1039, 1203, 1336)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.end'
	END	
	ELSE IF @lEventID in (1035,  1129)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.cancel'
	END
	ELSE IF @lEventID in (1067)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.error'
	END
	ELSE IF @lEventID in (1064)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.start'
	END
	ELSE IF @lEventID in (1065)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.end'
	END	
	ELSE IF @lEventID in (1089, 4700, 4702)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.error'
	END
	ELSE IF @lEventID in (1120)
	BEGIN
		SET @TmpThreatCategory = 'ops.update'
	END
	ELSE IF @lEventID in (1118,  1119)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.end'
	END	
	ELSE IF @lEventID in (1121)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.cancel'
	END
	ELSE
	BEGIN
		SET @TmpThreatCategory = 'av'
	END

	IF @lEventID in (51, 53, 55, 56, 58, 59, 62, 64, 66, 69, 1026, 1028, 1030, 
			 1031, 1033, 1042, 1043, 1044, 1045, 1050, 1051, 1055, 1057, 
			 1059, 1061, 1101, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 
			 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1294, 1295, 
			 1296, 1298, 1299, 1300, 1502, 21026, 21028, 21031, 21033, 
			 21055, 21057, 21274, 21275, 21276, 21277, 21282, 21283, 
			 21284, 21285, 21286, 21287, 21288, 21289, 21290, 21291, 
			 21292, 21294, 21295, 21296, 21298, 21299, 21300, 21401, 
			 21402, 21404, 21407, 21409, 21411, 21413)
	BEGIN
		SET @TmpThreatHandled = 0
	END
	ELSE
	BEGIN
		SET @TmpThreatHandled = 1
	END

	IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
	BEGIN
	EXECUTE @IP = vseConvertIPStringToIPV4 @IPAddress;
	SELECT @TmpAnalyzerIPV4  = CAST(@IP - 2147483648 AS INT);	
		EXECUTE @TmpAnalyzerIPV6 = vseConvertIPStringToIPV6 @IPAddress;
	END
	ELSE
	BEGIN                              -- IPV6 Address
		EXECUTE @TmpAnalyzerIPV6 = dbo.VSE_HexStrToVarBin @IPAddress;
		SELECT  @TmpAnalyzerIPV4 = -2147483648;
	END
	
	SELECT @TmpSourceProcessName = @ProcessName

	IF LEN(@Source) > 0
	AND CHARINDEX(':',@Source) > 0
	BEGIN
		-- @Source = '123.123.123.123:80'
		-- @Source = 'machinename:80'
	
		IF ISNUMERIC (RIGHT (@Source, LEN(@Source) - CHARINDEX(':',@Source))) > 0
		BEGIN
			SELECT @TmpTargetPort = RIGHT (@Source, LEN(@Source) - CHARINDEX(':',@Source))
		END
	
		SELECT @TmpSource = LEFT (@Source, CHARINDEX(':',@Source) - 1)
	END
	ELSE IF LEN(@Source) > 0
	AND CHARINDEX('(',@Source) > 0
	AND CHARINDEX(')',@Source) > CHARINDEX('(',@Source)
	BEGIN
		-- @Source = '123.123.123.123 (machinename)'
		SELECT @TmpSource = LEFT (@Source, CHARINDEX('(',@Source) - 1)	
		SELECT @TmpSourceHostName = RIGHT (LEFT(@Source, LEN(@Source) - 1), LEN(@Source) - CHARINDEX('(',@Source) - 1)
	END
	ELSE
	BEGIN
		SELECT @TmpSourceHostName = @Source
	END
	
	IF LEN(@TmpSource) > 0
	BEGIN
		IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
		BEGIN
			EXECUTE @IP = vseConvertIPStringToIPV4 @TmpSource;
			IF @IP > 0
			BEGIN		
				SELECT @TmpSourceIPV4 = CAST(@IP - 2147483648 AS INT);
				EXECUTE @TmpSourceIPV6 = vseConvertIPStringToIPV6 @TmpSource;
			END
			ELSE
			BEGIN
				SELECT @TmpSourceHostName = @TmpSource
			END
		END
		ElSE
		BEGIN -- IPV6 Address
			EXECUTE @TmpSourceIPV6 = dbo.VSE_HexStrToVarBin @TmpSource;
			SELECT  @TmpSourceIPV4 = -2147483648;
		END
	END

	IF @Severity = 4		-- Critical(4) -> Critical(2)
	BEGIN
		SELECT @TmpSeverity = 2
	END
	ELSE IF @Severity = 3		-- Major(3) -> Alert(1)
	BEGIN
		SELECT @TmpSeverity = 1
	END
	ELSE IF @Severity = 2		-- Minor(2) -> Notice(5)
	BEGIN
		SELECT @TmpSeverity = 5
	END
	ELSE IF @Severity = 1		-- Warning(1) -> Warning(4)
	BEGIN
		SELECT @TmpSeverity = 4
	END
	ELSE IF @Severity = 0		-- Informational(0) -> Information(6)
	BEGIN
		SELECT @TmpSeverity = 6
	END

    EXEC EPOEvents_InsertEvent2
    	DEFAULT, -- @ServerID nvarchar(16) = 'ePO_SERVERNAME',
    	@UTCTime, -- @DetectedUTC datetime,
    	@AgentGUID, -- @AgentGUID uniqueidentifier,

    	@TmpAnalyzer,   -- @Analyzer nvarchar(16),
    	@ProductName,   -- @AnalyzerName nvarchar(64),
    	@ProductVersion,-- @AnalyzerVersion nvarchar(20),         
    	@MachineName,   -- @AnalyzerHostName nvarchar(128) = NULL,
    	@TmpAnalyzerIPV4,     -- @AnalyzerIPV4 int = NULL,
    	@TmpAnalyzerIPV6,        -- @AnalyzerIPV6 binary(16) = NULL,
    	DEFAULT,        -- @AnalyzerMAC nvarchar(16) = NULL,
    	DEFAULT,		-- @AnalyzerDATVersion nvarchar(20) = NULL,
    	DEFAULT,		-- @AnalyzerEngineVersion nvarchar(20) = NULL,
    	@TaskName,	-- @AnalyzerDetectionMethod nvarchar(20) = NULL,

    	@TmpSourceHostName,     -- @SourceHostName nvarchar(128) = NULL,
    	@TmpSourceIPV4, -- @SourceIPV4 int = NULL,
    	@TmpSourceIPV6,	-- @SourceIPV6 binary(16) = NULL,
    	DEFAULT,        -- @SourceMAC nvarchar(16) = NULL,
    	DEFAULT,        -- @SourceUserName nvarchar(128) = NULL,
    	@TmpSourceProcessName,  -- @SourceProcessName nvarchar(128) = NULL,
    	DEFAULT,        -- @SourceURL nvarchar(256) = NULL,

    	@MachineName,	-- @TargetHostName nvarchar(128) = NULL,
    	@TmpAnalyzerIPV4,     -- @TargetIPV4 int = NULL,
    	@TmpAnalyzerIPV6,     -- @TargetIPV6 binary(16) = NULL,
    	DEFAULT,        -- @TargetMAC nvarchar(16) = NULL,
    	@UserName,		-- @TargetUserName nvarchar(128) = NULL,
    	DEFAULT,        -- @TargetPort int = NULL,
    	DEFAULT,        -- @TargetProtocol nvarchar(16) = NULL,
    	DEFAULT,		-- @TargetProcessName nvarchar(128) = NULL,
    	@FileName,		-- @TargetFileName nvarchar(266) = NULL,

    	@TmpThreatCategory,	-- @ThreatCategory nvarchar(128),    ==> @SignatureID???
    	@lEventID,      -- @ThreatEventID int,
    	@RuleName,		-- @ThreatName nvarchar(128),
    	'access protection',		-- @ThreatType nvarchar(32),
    	@TmpSeverity,	-- @ThreatSeverity tinyint = 1,
    	@TmpThreatActionTaken,-- @ThreatActionTaken nvarchar(24) = 'none',
    	@TmpThreatHandled,	-- @ThreatHandled tinyint = 1,

    	@EventID OUTPUT, -- @AutoID int = NULL ,
    	DEFAULT;        -- @AutoGUID uniqueidentifier = NULL OUTPUT


	SELECT @EventID AS nResult;
END
GO

-----------------------------------------------------------
-- VSE_InsertEnterceptEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertEnterceptEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertEnterceptEvent
GO

CREATE PROCEDURE dbo.VSE_InsertEnterceptEvent
(
@AgentGUID 		[UNIQUEIDENTIFIER],
@UserName 		[NVARCHAR] (32),
@MachineName 		[NVARCHAR] (512),
@OSName			[NVARCHAR] (260), -- parameter not mapped to any field in table	
@IPAddress 		[NVARCHAR] (48),
@TimeZoneBias		[NVARCHAR] (260), -- parameter not mapped to any field in table
@ProductFamily		[NVARCHAR] (260), -- parameter not mapped to any field in table
@ProductName 		[NVARCHAR] (64),	
@ProductVersion 	[NVARCHAR] (16),
@ScannerType		[NVARCHAR] (260), -- parameter not mapped to any field in table
@EngineVersion		[NVARCHAR] (16),
@DATVersion		[NVARCHAR] (16),
@TaskName 		[NVARCHAR] (128),
@lEventID 		[INT],
@Severity 		[INT],
@LocalTime 		[DATETIME],
@UTCTime 		[DATETIME],
@ProcessName 		[NVARCHAR] (260),
@ModuleName		[NVARCHAR] (260),
@APIName		[NVARCHAR] (260),
@ExploitName		[NVARCHAR] (260)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @TmpAnalyzer NVARCHAR(16)
	DECLARE @TmpAnalyzerIPV4 INT
	DECLARE @TmpAnalyzerIPV6 AS BINARY(16)
	DECLARE @TmpSource NVARCHAR(128)
	DECLARE @TmpSourceIPV4 INT
	DECLARE @TmpSourceIPV6 AS BINARY(16)
	DECLARE @TmpSourceHostName NVARCHAR(128)
	DECLARE @TmpSourceProcessName NVARCHAR(128)
	DECLARE @TmpTargetPort INT
	DECLARE @TmpTargetFileName NVARCHAR(266)
	DECLARE @TmpThreatActionTaken NVARCHAR(24)
	DECLARE @TmpThreatEventID INT
	DECLARE @TmpThreatCategory NVARCHAR(128)
	DECLARE @TmpSeverity TINYINT
	DECLARE @TmpThreatHandled TINYINT

	DECLARE @IP AS BIGINT
	DECLARE @EventID INT
	DECLARE @lActionsBlocked INT 		-- Not used
	DECLARE @FileName [NVARCHAR] (260)	-- Not used
	DECLARE @Source	NVARCHAR (260)		-- Not used

	IF RIGHT(@ScannerType, LEN('2B^|2B')) = '2B^|2B'
	BEGIN
		SELECT @TmpAnalyzer = LEFT(@ScannerType, LEN(@ScannerType) - LEN('2B^|2B'))
	END
	ELSE
	BEGIN
		IF @ProductVersion = '8.0'
		OR @ProductVersion LIKE '8.0%'
		BEGIN
        		SELECT @TmpAnalyzer = 'VIRUSCAN8000'
    		END
		ELSE IF @ProductVersion = '8.5'
		OR @ProductVersion LIKE '8.5%'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8600'
		END
		ELSE IF @ProductVersion = '8.7' OR @ProductVersion = '8.7.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8700'
		END
        ELSE IF @ProductVersion = '8.8' OR @ProductVersion = '8.8.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8800'
		END
		ELSE
		BEGIN
	    		SELECT @TmpAnalyzer = 'Unknown'
		END
	END

	IF @lEventID > 20000
	BEGIN
		SET @TmpThreatEventID = @lEventID - 20000
	END
	ELSE
	BEGIN
		SET @TmpThreatEventID = @lEventID
	END
		
	IF @TmpThreatEventID IN (1024, 1026, 1037, 1051, 1053, 1059, 1061, 1095, 1096, 1099, 1100, 1103, 1202, 1203, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413, 2001, 1034, 1064, 1065, 1067, 1087, 1088, 1089, 1035, 1038, 1039, 1118, 1119, 1120, 1121, 1129, 4700, 4702, 1335, 1336)
	AND @TaskName <> 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1024, 1026, 1037, 1053, 1061, 1100, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'access denied'
	END
	ELSE IF @TmpThreatEventID IN (1087, 1088)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1023, 1430)
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1025, 1060)
	BEGIN
		SET @TmpThreatActionTaken = 'cleaned'
	END
	ELSE IF @TmpThreatEventID IN (1027, 1028, 1054, 1055, 1101, 1104, 1278, 1279, 1280, 1281, 1293, 1303, 1306, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1405, 1408, 1410, 1414, 1415, 1416, 1417, 1418, 1419, 1420)
	BEGIN
		SET @TmpThreatActionTaken = 'deleted'
	END
	ELSE IF @TmpThreatEventID IN (1032, 1056, 1102, 1270, 1271, 1272, 1273, 1297, 1301, 1309, 1403, 1406, 1412)
	BEGIN
		SET @TmpThreatActionTaken = 'moved'
	END
	ELSE IF @TmpThreatEventID IN (1091, 1093, 1094)
	BEGIN
		SET @TmpThreatActionTaken = 'blocked'
	END
	ELSE IF @TmpThreatEventID IN (1096, 1099)
	BEGIN
		SET @TmpThreatActionTaken = 'would block'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'deny create'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'deny read'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'deny write'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'deny terminate'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny create'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny read'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny write'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny terminate'
	END
	ELSE
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END

	IF @lEventID in (1023, 1024, 1025, 1026, 1027, 1028, 1032, 1037, 1060, 1061, 1091, 1103, 1270, 1272, 1273, 1274, 1276, 1277, 1278, 1280, 1281, 1282, 1284, 1285, 1289, 1290, 1292, 1293, 1294, 1296, 1297, 1298, 1300, 1306, 1307, 1309, 1310, 1312, 1313, 1314, 1315, 1317, 1318, 1319, 1322, 1323, 1326, 1327, 1328)
	BEGIN
		SET @TmpThreatCategory = 'av.detect'
	END
	ELSE IF @lEventID in (1053, 1054, 1055, 1056, 1100, 1101, 1102, 1104, 1271, 1275, 1279, 1283, 1291, 1301, 1302, 1303, 1304, 1305, 1308, 1311, 1316, 1320, 1321, 1324, 1325)
	BEGIN
		SET @TmpThreatCategory = 'av.detect.heuristics'
	END
	ELSE IF @lEventID > 20000
	BEGIN
		SET @TmpThreatCategory = 'av.pup'
	END
	ELSE IF @lEventID in (1094, 1096)
	BEGIN
		SET @TmpThreatCategory = 'fw.detect'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName NOT LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.file'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.registry'
	END
	ELSE IF @lEventID in (1093, 1099)
	BEGIN
		SET @TmpThreatCategory = 'hip.bo'
	END
	ELSE IF @lEventID in (1051, 1059, 2001)
	BEGIN
		SET @TmpThreatCategory = 'ops'
	END		
	ELSE IF @lEventID in (1087)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.start'
	END	
	ELSE IF @lEventID in (1088)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.end'
	END
	ELSE IF @lEventID in (1202, 1335)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.start'
	END
	ELSE IF @lEventID in (1034, 1038, 1039, 1203, 1336)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.end'
	END	
	ELSE IF @lEventID in (1035,  1129)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.cancel'
	END
	ELSE IF @lEventID in (1067)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.error'
	END
	ELSE IF @lEventID in (1064)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.start'
	END
	ELSE IF @lEventID in (1065)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.end'
	END	
	ELSE IF @lEventID in (1089, 4700, 4702)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.error'
	END
	ELSE IF @lEventID in (1120)
	BEGIN
		SET @TmpThreatCategory = 'ops.update'
	END
	ELSE IF @lEventID in (1118,  1119)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.end'
	END	
	ELSE IF @lEventID in (1121)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.cancel'
	END
	ELSE
	BEGIN
		SET @TmpThreatCategory = 'av'
	END

	IF @lEventID in (51, 53, 55, 56, 58, 59, 62, 64, 66, 69, 1026, 1028, 1030, 
			 1031, 1033, 1042, 1043, 1044, 1045, 1050, 1051, 1055, 1057, 
			 1059, 1061, 1101, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 
			 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1294, 1295, 
			 1296, 1298, 1299, 1300, 1502, 21026, 21028, 21031, 21033, 
			 21055, 21057, 21274, 21275, 21276, 21277, 21282, 21283, 
			 21284, 21285, 21286, 21287, 21288, 21289, 21290, 21291, 
			 21292, 21294, 21295, 21296, 21298, 21299, 21300, 21401, 
			 21402, 21404, 21407, 21409, 21411, 21413)
	BEGIN
		SET @TmpThreatHandled = 0
	END
	ELSE
	BEGIN
		SET @TmpThreatHandled = 1
	END

	IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
	BEGIN
		EXECUTE @IP = vseConvertIPStringToIPV4 @IPAddress;
		SELECT @TmpAnalyzerIPV4  = CAST(@IP - 2147483648 AS INT);
		EXECUTE @TmpAnalyzerIPV6 = vseConvertIPStringToIPV6 @IPAddress;
	END
	ELSE
	BEGIN                              -- IPV6 Address
		EXECUTE @TmpAnalyzerIPV6 = dbo.VSE_HexStrToVarBin @IPAddress;
		SELECT  @TmpAnalyzerIPV4 = -2147483648;
	END
	
	SELECT @TmpSourceProcessName = @ProcessName

	IF LEN(@Source) > 0
	AND CHARINDEX(':',@Source) > 0
	BEGIN
		-- @Source = '123.123.123.123:80'
		-- @Source = 'machinename:80'
	
		IF ISNUMERIC (RIGHT (@Source, LEN(@Source) - CHARINDEX(':',@Source))) > 0
		BEGIN
			SELECT @TmpTargetPort = RIGHT (@Source, LEN(@Source) - CHARINDEX(':',@Source))
		END
	
		SELECT @TmpSource = LEFT (@Source, CHARINDEX(':',@Source) - 1)
	END
	ELSE IF LEN(@Source) > 0
	AND CHARINDEX('(',@Source) > 0
	AND CHARINDEX(')',@Source) > CHARINDEX('(',@Source)
	BEGIN
		-- @Source = '123.123.123.123 (machinename)'
		SELECT @TmpSource = LEFT (@Source, CHARINDEX('(',@Source) - 1)	
		SELECT @TmpSourceHostName = RIGHT (LEFT(@Source, LEN(@Source) - 1), LEN(@Source) - CHARINDEX('(',@Source) - 1)
	END
	ELSE
	BEGIN
		SELECT @TmpSourceHostName = @Source
	END
	
	IF LEN(@TmpSource) > 0
	BEGIN
		IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
		BEGIN
			EXECUTE @IP = vseConvertIPStringToIPV4 @TmpSource;
			IF @IP > 0
			BEGIN		
				SELECT @TmpSourceIPV4 = CAST(@IP - 2147483648 AS INT);
				EXECUTE @TmpSourceIPV6 = vseConvertIPStringToIPV6 @TmpSource;
			END
			ELSE
			BEGIN
				SELECT @TmpSourceHostName = @TmpSource
			END
		END
		ElSE
		BEGIN -- IPV6 Address
			EXECUTE @TmpSourceIPV6 = dbo.VSE_HexStrToVarBin @TmpSource;
			SELECT  @TmpSourceIPV4 = -2147483648;
		END
	END

	IF @Severity = 4		-- Critical(4) -> Critical(2)
	BEGIN
		SELECT @TmpSeverity = 2
	END
	ELSE IF @Severity = 3		-- Major(3) -> Alert(1)
	BEGIN
		SELECT @TmpSeverity = 1
	END
	ELSE IF @Severity = 2		-- Minor(2) -> Notice(5)
	BEGIN
		SELECT @TmpSeverity = 5
	END
	ELSE IF @Severity = 1		-- Warning(1) -> Warning(4)
	BEGIN
		SELECT @TmpSeverity = 4
	END
	ELSE IF @Severity = 0		-- Informational(0) -> Information(6)
	BEGIN
		SELECT @TmpSeverity = 6
	END

	SELECT @TmpTargetFileName = @ModuleName + ':' + @APIName

    EXEC EPOEvents_InsertEvent2
    	DEFAULT, -- @ServerID nvarchar(16) = 'ePO_SERVERNAME',
    	@UTCTime, -- @DetectedUTC datetime,
    	@AgentGUID, -- @AgentGUID uniqueidentifier,

    	@TmpAnalyzer,      -- @Analyzer nvarchar(16),
    	@ProductName,   -- @AnalyzerName nvarchar(64),
    	@ProductVersion,-- @AnalyzerVersion nvarchar(20),         
    	@MachineName,   -- @AnalyzerHostName nvarchar(128) = NULL,
    	@TmpAnalyzerIPV4,-- @AnalyzerIPV4 int = NULL,
    	@TmpAnalyzerIPV6,-- @AnalyzerIPV6 binary(16) = NULL,
    	DEFAULT,        -- @AnalyzerMAC nvarchar(16) = NULL,
    	@DATVersion,	-- @AnalyzerDATVersion nvarchar(20) = NULL,
    	@EngineVersion,	-- @AnalyzerEngineVersion nvarchar(20) = NULL,
    	@TaskName,	-- @AnalyzerDetectionMethod nvarchar(20) = NULL,

    	@TmpSourceHostName,     -- @SourceHostName nvarchar(128) = NULL,
    	@TmpSourceIPV4, -- @SourceIPV4 int = NULL,
    	@TmpSourceIPV6,	-- @SourceIPV6 binary(16) = NULL,
    	DEFAULT,        -- @SourceMAC nvarchar(16) = NULL,
    	DEFAULT,        -- @SourceUserName nvarchar(128) = NULL,
    	@TmpSourceProcessName,  -- @SourceProcessName nvarchar(128) = NULL,
    	DEFAULT,        -- @SourceURL nvarchar(256) = NULL,

    	@MachineName,	-- @TargetHostName nvarchar(128) = NULL,
    	@TmpAnalyzerIPV4,-- @TargetIPV4 int = NULL,
    	@TmpAnalyzerIPV6,-- @TargetIPV6 binary(16) = NULL,
    	DEFAULT,        -- @TargetMAC nvarchar(16) = NULL,
    	@UserName,		-- @TargetUserName nvarchar(128) = NULL,
    	DEFAULT,        -- @TargetPort int = NULL,
    	DEFAULT,       -- @TargetProtocol nvarchar(16) = NULL,
    	DEFAULT,		-- @TargetProcessName nvarchar(128) = NULL,
    	@TmpTargetFileName,	-- @TargetFileName nvarchar(266) = NULL,

    	@TmpThreatCategory,	-- @ThreatCategory nvarchar(128),    ==> @SignatureID???
    	@lEventID,      -- @ThreatEventID int,
    	@ExploitName,   -- @ThreatName nvarchar(128),
    	'buffer overflow',		-- @ThreatType nvarchar(32),
    	@TmpSeverity,	-- @ThreatSeverity tinyint = 1,
    	@TmpThreatActionTaken,	-- @ThreatActionTaken nvarchar(24) = 'none',
    	@TmpThreatHandled,      -- @ThreatHandled tinyint = 1,

    	@EventID OUTPUT, -- @AutoID int = NULL ,
    	DEFAULT;        -- @AutoGUID uniqueidentifier = NULL OUTPUT


	SELECT @EventID AS nResult;
END
GO

-----------------------------------------------------------
-- VSE_InsertPortBlockEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertPortBlockEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertPortBlockEvent
GO

CREATE PROCEDURE dbo.VSE_InsertPortBlockEvent
(
@AgentGUID 		[UNIQUEIDENTIFIER],
@UserName 		[NVARCHAR] (32),
@MachineName 		[NVARCHAR] (512),
@OSName			[NVARCHAR] (260), -- parameter not mapped to any field in table	
@IPAddress 		[NVARCHAR] (48),
@TimeZoneBias		[NVARCHAR] (260), -- parameter not mapped to any field in table
@ProductFamily		[NVARCHAR] (260), -- parameter not mapped to any field in table	
@ProductName 		[NVARCHAR] (64),	
@ProductVersion 	[NVARCHAR] (16),
@ScannerType		[NVARCHAR] (260), -- parameter not mapped to any field in table
@TaskName 		[NVARCHAR] (128),
@lEventID 		[INT],
@Severity 		[INT],
@LocalTime 		[DATETIME],
@UTCTime 		[DATETIME],
@RuleName		[NVARCHAR] (260),
@ProcessName 	[NVARCHAR] (260),
@Source			[NVARCHAR] (260)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @TmpAnalyzer NVARCHAR(16)
	DECLARE @TmpAnalyzerIPV4 INT
	DECLARE @TmpAnalyzerIPV6 AS BINARY(16)
	DECLARE @TmpSource NVARCHAR(128)
	DECLARE @TmpSourceIPV4 INT
	DECLARE @TmpSourceIPV6 AS BINARY(16)
	DECLARE @TmpSourceHostName NVARCHAR(128)
	DECLARE @TmpSourceProcessName NVARCHAR(128)
	DECLARE @TmpTargetPort INT
	DECLARE @TmpThreatCategory NVARCHAR(128)
	DECLARE @TmpThreatActionTaken NVARCHAR(24)
	DECLARE @TmpThreatEventID INT
	DECLARE @TmpSeverity TINYINT
	DECLARE @TmpThreatHandled TINYINT

	DECLARE @IP AS BIGINT
	DECLARE @EventID INT
	DECLARE @lActionsBlocked INT 		-- Not used
	DECLARE @FileName [NVARCHAR] (260)	-- Not used	

	IF RIGHT(@ScannerType, LEN('2B^|2B')) = '2B^|2B'
	BEGIN
		SELECT @TmpAnalyzer = LEFT(@ScannerType, LEN(@ScannerType) - LEN('2B^|2B'))
	END
	ELSE
	BEGIN
		IF @ProductVersion = '8.0'
		OR @ProductVersion LIKE '8.0%'
		BEGIN
        		SELECT @TmpAnalyzer = 'VIRUSCAN8000'
    		END
		ELSE IF @ProductVersion = '8.5'
		OR @ProductVersion LIKE '8.5%'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8600'
		END
		ELSE IF @ProductVersion = '8.7' OR @ProductVersion = '8.7.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8700'
		END
        ELSE IF @ProductVersion = '8.8' OR @ProductVersion = '8.8.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8800'
		END
		ELSE
		BEGIN
	    		SELECT @TmpAnalyzer = 'Unknown'
		END
	END
		
	IF @lEventID > 20000
	BEGIN
		SET @TmpThreatEventID = @lEventID - 20000
	END
	ELSE
	BEGIN
		SET @TmpThreatEventID = @lEventID
	END

	IF @TmpThreatEventID IN (1024, 1026, 1037, 1051, 1053, 1059, 1061, 1095, 1096, 1099, 1100, 1103, 1202, 1203, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413, 2001, 1034, 1064, 1065, 1067, 1087, 1088, 1089, 1035, 1038, 1039, 1118, 1119, 1120, 1121, 1129, 4700, 4702, 1335, 1336)
	AND @TaskName <> 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1024, 1026, 1037, 1053, 1061, 1100, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'access denied'
	END
	ELSE IF @TmpThreatEventID IN (1087, 1088)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1023, 1430)
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1025, 1060)
	BEGIN
		SET @TmpThreatActionTaken = 'cleaned'
	END
	ELSE IF @TmpThreatEventID IN (1027, 1028, 1054, 1055, 1101, 1104, 1278, 1279, 1280, 1281, 1293, 1303, 1306, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1405, 1408, 1410, 1414, 1415, 1416, 1417, 1418, 1419, 1420)
	BEGIN
		SET @TmpThreatActionTaken = 'deleted'
	END
	ELSE IF @TmpThreatEventID IN (1032, 1056, 1102, 1270, 1271, 1272, 1273, 1297, 1301, 1309, 1403, 1406, 1412)
	BEGIN
		SET @TmpThreatActionTaken = 'moved'
	END
	ELSE IF @TmpThreatEventID IN (1091, 1093, 1094)
	BEGIN
		SET @TmpThreatActionTaken = 'blocked'
	END
	ELSE IF @TmpThreatEventID IN (1096, 1099)
	BEGIN
		SET @TmpThreatActionTaken = 'would block'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'deny create'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'deny read'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'deny write'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'deny terminate'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny create'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny read'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny write'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny terminate'
	END
	ELSE
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END

	IF @lEventID in (1023, 1024, 1025, 1026, 1027, 1028, 1032, 1037, 1060, 1061, 1091, 1103, 1270, 1272, 1273, 1274, 1276, 1277, 1278, 1280, 1281, 1282, 1284, 1285, 1289, 1290, 1292, 1293, 1294, 1296, 1297, 1298, 1300, 1306, 1307, 1309, 1310, 1312, 1313, 1314, 1315, 1317, 1318, 1319, 1322, 1323, 1326, 1327, 1328)
	BEGIN
		SET @TmpThreatCategory = 'av.detect'
	END
	ELSE IF @lEventID in (1053, 1054, 1055, 1056, 1100, 1101, 1102, 1104, 1271, 1275, 1279, 1283, 1291, 1301, 1302, 1303, 1304, 1305, 1308, 1311, 1316, 1320, 1321, 1324, 1325)
	BEGIN
		SET @TmpThreatCategory = 'av.detect.heuristics'
	END
	ELSE IF @lEventID > 20000
	BEGIN
		SET @TmpThreatCategory = 'av.pup'
	END
	ELSE IF @lEventID in (1094, 1096)
	BEGIN
		SET @TmpThreatCategory = 'fw.detect'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName NOT LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.file'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.registry'
	END
	ELSE IF @lEventID in (1093, 1099)
	BEGIN
		SET @TmpThreatCategory = 'hip.bo'
	END
	ELSE IF @lEventID in (1051, 1059, 2001)
	BEGIN
		SET @TmpThreatCategory = 'ops'
	END		
	ELSE IF @lEventID in (1087)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.start'
	END	
	ELSE IF @lEventID in (1088)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.end'
	END
	ELSE IF @lEventID in (1202, 1335)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.start'
	END
	ELSE IF @lEventID in (1034, 1038, 1039, 1203, 1336)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.end'
	END	
	ELSE IF @lEventID in (1035,  1129)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.cancel'
	END
	ELSE IF @lEventID in (1067)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.error'
	END
	ELSE IF @lEventID in (1064)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.start'
	END
	ELSE IF @lEventID in (1065)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.end'
	END	
	ELSE IF @lEventID in (1089, 4700, 4702)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.error'
	END
	ELSE IF @lEventID in (1120)
	BEGIN
		SET @TmpThreatCategory = 'ops.update'
	END
	ELSE IF @lEventID in (1118,  1119)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.end'
	END	
	ELSE IF @lEventID in (1121)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.cancel'
	END
	ELSE
	BEGIN
		SET @TmpThreatCategory = 'av'
	END

	IF @lEventID in (51, 53, 55, 56, 58, 59, 62, 64, 66, 69, 1026, 1028, 1030, 
			 1031, 1033, 1042, 1043, 1044, 1045, 1050, 1051, 1055, 1057, 
			 1059, 1061, 1101, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 
			 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1294, 1295, 
			 1296, 1298, 1299, 1300, 1502, 21026, 21028, 21031, 21033, 
			 21055, 21057, 21274, 21275, 21276, 21277, 21282, 21283, 
			 21284, 21285, 21286, 21287, 21288, 21289, 21290, 21291, 
			 21292, 21294, 21295, 21296, 21298, 21299, 21300, 21401, 
			 21402, 21404, 21407, 21409, 21411, 21413)
	BEGIN
		SET @TmpThreatHandled = 0
	END
	ELSE
	BEGIN
		SET @TmpThreatHandled = 1
	END

	IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
	BEGIN
		EXECUTE @IP = vseConvertIPStringToIPV4 @IPAddress;
		SELECT @TmpAnalyzerIPV4  = CAST(@IP - 2147483648 AS INT);
		EXECUTE @TmpAnalyzerIPV6 = vseConvertIPStringToIPV6 @IPAddress;
	END
	ELSE
	BEGIN                              -- IPV6 Address
		EXECUTE @TmpAnalyzerIPV6 = dbo.VSE_HexStrToVarBin @IPAddress;
		SELECT  @TmpAnalyzerIPV4 = -2147483648;
	END
	
	SELECT @TmpSourceProcessName = @ProcessName

	IF LEN(@Source) > 0
	AND CHARINDEX(N':',@Source) > 0
	BEGIN
		-- @Source = '123.123.123.123:80'
		-- @Source = 'machinename:80'
		-- @Source = '12:2::1:80' (IPv6)

    DECLARE @portInd INT;
    SET @portInd = LEN(@Source) - (CHARINDEX(':', REVERSE(@Source))) + 1;
	
		IF ISNUMERIC (RIGHT (@Source, LEN(@Source) - @portInd)) > 0
		BEGIN
			SELECT @TmpTargetPort = RIGHT (@Source, LEN(@Source) - @portInd)
		END
	
		SELECT @TmpSource = LEFT (@Source, @portInd - 1)
	END
	ELSE IF LEN(@Source) > 0
	AND CHARINDEX('(',@Source) > 0
	AND CHARINDEX(')',@Source) > CHARINDEX('(',@Source)
	BEGIN
		-- @Source = '123.123.123.123 (machinename)'
		SELECT @TmpSource = LEFT (@Source, CHARINDEX('(',@Source) - 1)	
		SELECT @TmpSourceHostName = RIGHT (LEFT(@Source, LEN(@Source) - 1), LEN(@Source) - CHARINDEX('(',@Source) - 1)
	END
	ELSE
	BEGIN
		SELECT @TmpSourceHostName = @Source
	END
	
	IF LEN(@TmpSource) > 0
	BEGIN
		IF(CHARINDEX(N':',@TmpSource) = 0) -- IPV4 Address
		BEGIN
			EXECUTE @IP = vseConvertIPStringToIPV4 @TmpSource;
			IF @IP > 0
			BEGIN		
				SELECT @TmpSourceIPV4 = CAST(@IP - 2147483648 AS INT);
				EXECUTE @TmpSourceIPV6 = vseConvertIPStringToIPV6 @TmpSource;
			END
			ELSE
			BEGIN
				SELECT @TmpSourceHostName = @TmpSource
			END
		END
		ElSE
		BEGIN -- IPV6 Address
			EXECUTE @TmpSourceIPV6 = dbo.VSE_HexStrToVarBin @TmpSource;
			IF @TmpSourceIPV6 <= 0
			BEGIN
				SELECT @TmpSourceHostName = @TmpSource
			END
			SELECT  @TmpSourceIPV4 = -2147483648;
		END
	END

	IF @Severity = 4		-- Critical(4) -> Critical(2)
	BEGIN
		SELECT @TmpSeverity = 2
	END
	ELSE IF @Severity = 3		-- Major(3) -> Alert(1)
	BEGIN
		SELECT @TmpSeverity = 1
	END
	ELSE IF @Severity = 2		-- Minor(2) -> Notice(5)
	BEGIN
		SELECT @TmpSeverity = 5
	END
	ELSE IF @Severity = 1		-- Warning(1) -> Warning(4)
	BEGIN
		SELECT @TmpSeverity = 4
	END
	ELSE IF @Severity = 0		-- Informational(0) -> Information(6)
	BEGIN
		SELECT @TmpSeverity = 6
	END

    EXEC EPOEvents_InsertEvent2
    	DEFAULT, -- @ServerID nvarchar(16) = 'ePO_SERVERNAME',
    	@UTCTime, -- @DetectedUTC datetime,
    	@AgentGUID, -- @AgentGUID uniqueidentifier,

    	@TmpAnalyzer,      -- @Analyzer nvarchar(16),
    	@ProductName,   -- @AnalyzerName nvarchar(64),
    	@ProductVersion,-- @AnalyzerVersion nvarchar(20),         
    	@MachineName,   -- @AnalyzerHostName nvarchar(128) = NULL,
    	@TmpAnalyzerIPV4,-- @AnalyzerIPV4 int = NULL,
    	@TmpAnalyzerIPV6,-- @AnalyzerIPV6 binary(16) = NULL,
    	DEFAULT,        -- @AnalyzerMAC nvarchar(16) = NULL,
    	DEFAULT,		-- @AnalyzerDATVersion nvarchar(20) = NULL,
    	DEFAULT,		-- @AnalyzerEngineVersion nvarchar(20) = NULL,
    	@TaskName,	-- @AnalyzerDetectionMethod nvarchar(20) = NULL,

    	@TmpSourceHostName,     -- @SourceHostName nvarchar(128) = NULL,
    	@TmpSourceIPV4, -- @SourceIPV4 int = NULL,
    	@TmpSourceIPV6,	-- @SourceIPV6 binary(16) = NULL,
    	DEFAULT,        -- @SourceMAC nvarchar(16) = NULL,
    	DEFAULT,        -- @SourceUserName nvarchar(128) = NULL,
    	@TmpSourceProcessName,  -- @SourceProcessName nvarchar(128) = NULL,
    	DEFAULT,        -- @SourceURL nvarchar(256) = NULL,

    	@MachineName,	-- @TargetHostName nvarchar(128) = NULL,
    	@TmpAnalyzerIPV4,-- @TargetIPV4 int = NULL,
    	@TmpAnalyzerIPV6,-- @TargetIPV6 binary(16) = NULL,
    	DEFAULT,        -- @TargetMAC nvarchar(16) = NULL,
    	@UserName,		-- @TargetUserName nvarchar(128) = NULL,
    	@TmpTargetPort, -- @TargetPort int = NULL,
    	DEFAULT,        -- @TargetProtocol nvarchar(16) = NULL,
    	DEFAULT,		-- @TargetProcessName nvarchar(128) = NULL,
    	DEFAULT,		-- @TargetFileName nvarchar(266) = NULL,

    	@TmpThreatCategory,	-- @ThreatCategory nvarchar(128),    ==> @SignatureID???
    	@lEventID,      -- @ThreatEventID int,
    	@RuleName,		-- @ThreatName nvarchar(128),
    	'access protection',		-- @ThreatType nvarchar(32),
    	@TmpSeverity,	-- @ThreatSeverity tinyint = 1,
    	@TmpThreatActionTaken,	-- @ThreatActionTaken nvarchar(24) = 'none',
    	@TmpThreatHandled,      -- @ThreatHandled tinyint = 1,

    	@EventID OUTPUT, -- @AutoID int = NULL ,
    	DEFAULT;        -- @AutoGUID uniqueidentifier = NULL OUTPUT


	SELECT @EventID AS nResult;
END
GO

-----------------------------------------------------------
-- VSE_InsertTaskStatusEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertTaskStatusEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertTaskStatusEvent
GO

CREATE PROCEDURE dbo.VSE_InsertTaskStatusEvent
(
@AgentGUID 		[UNIQUEIDENTIFIER],
@UserName 		[NVARCHAR] (32),
@MachineName 		[NVARCHAR] (512),
@OSName			[NVARCHAR] (260), -- parameter not mapped to any field in table	
@IPAddress 		[NVARCHAR] (48),
@TimeZoneBias		[NVARCHAR] (260), -- parameter not mapped to any field in table
@ProductFamily		[NVARCHAR] (260), -- parameter not mapped to any field in table	
@ProductName 		[NVARCHAR] (64),	
@ProductVersion 	[NVARCHAR] (16),
@ScannerType		[NVARCHAR] (260), -- parameter not mapped to any field in table
@EngineVersion		[NVARCHAR] (16),
@DATVersion		[NVARCHAR] (16),
@TaskName 		[NVARCHAR] (128),
@lEventID 		[INT],
@Severity 		[INT],
@LocalTime 		[DATETIME],
@UTCTime 		[DATETIME]
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @TmpAnalyzer NVARCHAR(16)
	DECLARE @TmpAnalyzerIPV4 INT
	DECLARE @TmpAnalyzerIPV6 AS BINARY(16)
	DECLARE @TmpSource NVARCHAR(128)
	DECLARE @TmpSourceIPV4 INT
	DECLARE @TmpSourceIPV6 AS BINARY(16)
	DECLARE @TmpSourceHostName NVARCHAR(128)
	DECLARE @TmpSourceProcessName NVARCHAR(128)
	DECLARE @TmpTargetPort INT
	DECLARE @TmpThreatActionTaken NVARCHAR(24)
	DECLARE @TmpThreatEventID INT
	DECLARE @TmpThreatCategory NVARCHAR(128)
	DECLARE @TmpSeverity TINYINT
	DECLARE @TmpThreatHandled TINYINT

	DECLARE @IP AS BIGINT
	DECLARE @EventID INT
	DECLARE @lActionsBlocked INT 		-- Not used
	DECLARE @FileName NVARCHAR (260)	-- Not used
	DECLARE @Source	NVARCHAR (260)		-- Not used

	IF RIGHT(@ScannerType, LEN('2B^|2B')) = '2B^|2B'
	BEGIN
		SELECT @TmpAnalyzer = LEFT(@ScannerType, LEN(@ScannerType) - LEN('2B^|2B'))
	END
	ELSE
	BEGIN
		IF @ProductVersion = '8.0'
		OR @ProductVersion LIKE '8.0%'
		BEGIN
        		SELECT @TmpAnalyzer = 'VIRUSCAN8000'
    		END
		ELSE IF @ProductVersion = '8.5'
		OR @ProductVersion LIKE '8.5%'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8600'
		END
		ELSE IF @ProductVersion = '8.7' OR @ProductVersion = '8.7.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8700'
		END
        ELSE IF @ProductVersion = '8.8' OR @ProductVersion = '8.8.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8800'
		END
		ELSE
		BEGIN
	    		SELECT @TmpAnalyzer = 'Unknown'
		END
	END
		
	IF @lEventID > 20000
	BEGIN
		SET @TmpThreatEventID = @lEventID - 20000
	END
	ELSE
	BEGIN
		SET @TmpThreatEventID = @lEventID
	END

	IF @TmpThreatEventID IN (1024, 1026, 1037, 1051, 1053, 1059, 1061, 1095, 1096, 1099, 1100, 1103, 1202, 1203, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413, 2001, 1034, 1064, 1065, 1067, 1087, 1088, 1089, 1035, 1038, 1039, 1118, 1119, 1120, 1121, 1129, 4700, 4702, 1335, 1336)
	AND @TaskName <> 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1024, 1026, 1037, 1053, 1061, 1100, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'access denied'
	END
	ELSE IF @TmpThreatEventID IN (1087, 1088)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1023, 1430)
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1025, 1060)
	BEGIN
		SET @TmpThreatActionTaken = 'cleaned'
	END
	ELSE IF @TmpThreatEventID IN (1027, 1028, 1054, 1055, 1101, 1104, 1278, 1279, 1280, 1281, 1293, 1303, 1306, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1405, 1408, 1410, 1414, 1415, 1416, 1417, 1418, 1419, 1420)
	BEGIN
		SET @TmpThreatActionTaken = 'deleted'
	END
	ELSE IF @TmpThreatEventID IN (1032, 1056, 1102, 1270, 1271, 1272, 1273, 1297, 1301, 1309, 1403, 1406, 1412)
	BEGIN
		SET @TmpThreatActionTaken = 'moved'
	END
	ELSE IF @TmpThreatEventID IN (1091, 1093, 1094)
	BEGIN
		SET @TmpThreatActionTaken = 'blocked'
	END
	ELSE IF @TmpThreatEventID IN (1096, 1099)
	BEGIN
		SET @TmpThreatActionTaken = 'would block'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'deny create'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'deny read'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'deny write'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'deny terminate'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny create'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny read'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny write'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny terminate'
	END
	ELSE
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END

	IF @lEventID in (1023, 1024, 1025, 1026, 1027, 1028, 1032, 1037, 1060, 1061, 1091, 1103, 1270, 1272, 1273, 1274, 1276, 1277, 1278, 1280, 1281, 1282, 1284, 1285, 1289, 1290, 1292, 1293, 1294, 1296, 1297, 1298, 1300, 1306, 1307, 1309, 1310, 1312, 1313, 1314, 1315, 1317, 1318, 1319, 1322, 1323, 1326, 1327, 1328)
	BEGIN
		SET @TmpThreatCategory = 'av.detect'
	END
	ELSE IF @lEventID in (1053, 1054, 1055, 1056, 1100, 1101, 1102, 1104, 1271, 1275, 1279, 1283, 1291, 1301, 1302, 1303, 1304, 1305, 1308, 1311, 1316, 1320, 1321, 1324, 1325)
	BEGIN
		SET @TmpThreatCategory = 'av.detect.heuristics'
	END
	ELSE IF @lEventID > 20000
	BEGIN
		SET @TmpThreatCategory = 'av.pup'
	END
	ELSE IF @lEventID in (1094, 1096)
	BEGIN
		SET @TmpThreatCategory = 'fw.detect'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName NOT LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.file'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.registry'
	END
	ELSE IF @lEventID in (1093, 1099)
	BEGIN
		SET @TmpThreatCategory = 'hip.bo'
	END
	ELSE IF @lEventID in (1051, 1059, 2001)
	BEGIN
		SET @TmpThreatCategory = 'ops'
	END		
	ELSE IF @lEventID in (1087)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.start'
	END	
	ELSE IF @lEventID in (1088)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.end'
	END
	ELSE IF @lEventID in (1202, 1335)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.start'
	END
	ELSE IF @lEventID in (1034, 1038, 1039, 1203, 1336)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.end'
	END	
	ELSE IF @lEventID in (1035,  1129)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.cancel'
	END
	ELSE IF @lEventID in (1067)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.error'
	END
	ELSE IF @lEventID in (1064)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.start'
	END
	ELSE IF @lEventID in (1065)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.end'
	END	
	ELSE IF @lEventID in (1089, 4700, 4702)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.error'
	END
	ELSE IF @lEventID in (1120)
	BEGIN
		SET @TmpThreatCategory = 'ops.update'
	END
	ELSE IF @lEventID in (1118,  1119)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.end'
	END	
	ELSE IF @lEventID in (1121)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.cancel'
	END
	ELSE
	BEGIN
		SET @TmpThreatCategory = 'av'
	END

	IF @lEventID in (51, 53, 55, 56, 58, 59, 62, 64, 66, 69, 1026, 1028, 1030, 
			 1031, 1033, 1042, 1043, 1044, 1045, 1050, 1051, 1055, 1057, 
			 1059, 1061, 1101, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 
			 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1294, 1295, 
			 1296, 1298, 1299, 1300, 1502, 21026, 21028, 21031, 21033, 
			 21055, 21057, 21274, 21275, 21276, 21277, 21282, 21283, 
			 21284, 21285, 21286, 21287, 21288, 21289, 21290, 21291, 
			 21292, 21294, 21295, 21296, 21298, 21299, 21300, 21401, 
			 21402, 21404, 21407, 21409, 21411, 21413)
	BEGIN
		SET @TmpThreatHandled = 0
	END
	ELSE
	BEGIN
		SET @TmpThreatHandled = 1
	END

	IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
	BEGIN
		EXECUTE @IP = vseConvertIPStringToIPV4 @IPAddress;
		SELECT @TmpAnalyzerIPV4  = CAST(@IP - 2147483648 AS INT);
		EXECUTE @TmpAnalyzerIPV6 = vseConvertIPStringToIPV6 @IPAddress;
	END
	ELSE
	BEGIN                              -- IPV6 Address
		EXECUTE @TmpAnalyzerIPV6 = dbo.VSE_HexStrToVarBin @IPAddress;
		SELECT  @TmpAnalyzerIPV4 = -2147483648;
	END

	IF LEN(@Source) > 0
	AND CHARINDEX(':\',@Source) > 0
	BEGIN
		-- @Source = 'C:\WINNT\System32\exectuble.exe "C:\script.vbs"'
		SELECT @TmpSourceProcessName = @Source
	END
	ELSE IF LEN(@Source) > 0
	AND CHARINDEX(':',@Source) > 0
	BEGIN
		-- @Source = '123.123.123.123:80'
		-- @Source = 'machinename:80'
	
		IF ISNUMERIC (RIGHT (@Source, LEN(@Source) - CHARINDEX(':',@Source))) > 0
		BEGIN
			SELECT @TmpTargetPort = RIGHT (@Source, LEN(@Source) - CHARINDEX(':',@Source))
		END
	
		SELECT @TmpSource = LEFT (@Source, CHARINDEX(':',@Source) - 1)
	END
	ELSE IF LEN(@Source) > 0
	AND CHARINDEX('(',@Source) > 0
	AND CHARINDEX(')',@Source) > CHARINDEX('(',@Source)
	BEGIN
		-- @Source = '123.123.123.123 (machinename)'
		SELECT @TmpSource = LEFT (@Source, CHARINDEX('(',@Source) - 1)	
		SELECT @TmpSourceHostName = RIGHT (LEFT(@Source, LEN(@Source) - 1), LEN(@Source) - CHARINDEX('(',@Source) - 1)
	END
	ELSE
	BEGIN
		SELECT @TmpSourceHostName = @Source
	END
	
	IF LEN(@TmpSource) > 0
	BEGIN
		IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
		BEGIN
			EXECUTE @IP = vseConvertIPStringToIPV4 @TmpSource;
			IF @IP > 0
			BEGIN		
				SELECT @TmpSourceIPV4 = CAST(@IP - 2147483648 AS INT);
				EXECUTE @TmpSourceIPV6 = vseConvertIPStringToIPV6 @TmpSource;
			END
			ELSE
			BEGIN
				SELECT @TmpSourceHostName = @TmpSource
			END
		END
		ElSE
		BEGIN -- IPV6 Address
			EXECUTE @TmpSourceIPV6 = dbo.VSE_HexStrToVarBin @TmpSource;
			SELECT  @TmpSourceIPV4 = -2147483648;
		END
	END

	IF @Severity = 4		-- Critical(4) -> Critical(2)
	BEGIN
		SELECT @TmpSeverity = 2
	END
	ELSE IF @Severity = 3		-- Major(3) -> Alert(1)
	BEGIN
		SELECT @TmpSeverity = 1
	END
	ELSE IF @Severity = 2		-- Minor(2) -> Notice(5)
	BEGIN
		SELECT @TmpSeverity = 5
	END
	ELSE IF @Severity = 1		-- Warning(1) -> Warning(4)
	BEGIN
		SELECT @TmpSeverity = 4
	END
	ELSE IF @Severity = 0		-- Informational(0) -> Information(6)
	BEGIN
		SELECT @TmpSeverity = 6
	END

    EXEC EPOEvents_InsertEvent2
    	DEFAULT, -- @ServerID nvarchar(16) = 'ePO_SERVERNAME',
    	@UTCTime, -- @DetectedUTC datetime,
    	@AgentGUID, -- @AgentGUID uniqueidentifier,

    	@TmpAnalyzer,      -- @Analyzer nvarchar(16),
    	@ProductName,   -- @AnalyzerName nvarchar(64),
    	@ProductVersion,-- @AnalyzerVersion nvarchar(20),         
    	@MachineName,   -- @AnalyzerHostName nvarchar(128) = NULL,
    	@TmpAnalyzerIPV4,-- @AnalyzerIPV4 int = NULL,
    	@TmpAnalyzerIPV6,-- @AnalyzerIPV6 binary(16) = NULL,
    	DEFAULT,        -- @AnalyzerMAC nvarchar(16) = NULL,
    	@DATVersion,	-- @AnalyzerDATVersion nvarchar(20) = NULL,
    	@EngineVersion, -- @AnalyzerEngineVersion nvarchar(20) = NULL,
    	@TaskName,	-- @AnalyzerDetectionMethod nvarchar(20) = NULL,

    	@TmpSourceHostName,     -- @SourceHostName nvarchar(128) = NULL,
    	@TmpSourceIPV4, -- @SourceIPV4 int = NULL,
    	@TmpSourceIPV6,	-- @SourceIPV6 binary(16) = NULL,
    	DEFAULT,        -- @SourceMAC nvarchar(16) = NULL,
    	DEFAULT,        -- @SourceUserName nvarchar(128) = NULL,
    	@TmpSourceProcessName,  -- @SourceProcessName nvarchar(128) = NULL,
    	DEFAULT,        -- @SourceURL nvarchar(256) = NULL,

    	@MachineName,	-- @TargetHostName nvarchar(128) = NULL,
    	@TmpAnalyzerIPV4,-- @TargetIPV4 int = NULL,
    	@TmpAnalyzerIPV6,-- @TargetIPV6 binary(16) = NULL,
    	DEFAULT,        -- @TargetMAC nvarchar(16) = NULL,
    	@UserName,		-- @TargetUserName nvarchar(128) = NULL,
    	DEFAULT,        -- @TargetPort int = NULL,
    	DEFAULT,        -- @TargetProtocol nvarchar(16) = NULL,
    	DEFAULT,		-- @TargetProcessName nvarchar(128) = NULL,
    	DEFAULT,		-- @TargetFileName nvarchar(266) = NULL,

    	@TmpThreatCategory,	-- @ThreatCategory nvarchar(128),    ==> @SignatureID???
    	@lEventID,      	-- @ThreatEventID int,
    	'none',		-- @ThreatName nvarchar(128),
    	'none',		-- @ThreatType nvarchar(32),
    	@TmpSeverity,-- @ThreatSeverity tinyint = 1,
    	@TmpThreatActionTaken,	-- @ThreatActionTaken nvarchar(24) = 'none',
    	@TmpThreatHandled,     	-- @ThreatHandled tinyint = 1,

    	@EventID OUTPUT, 	-- @AutoID int = NULL ,
    	DEFAULT;        	-- @AutoGUID uniqueidentifier = NULL OUTPUT


	SELECT @EventID AS nResult;
END
GO

-----------------------------------------------------------
-- VSE_InsertVirusDetectionEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertVirusDetectionEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertVirusDetectionEvent
GO

CREATE PROCEDURE dbo.VSE_InsertVirusDetectionEvent
(
@AgentGUID 		[UNIQUEIDENTIFIER],
@UserName 		[NVARCHAR] (32),
@MachineName 		[NVARCHAR] (512),
@OSName			[NVARCHAR] (260), -- parameter not mapped to any field in table	
@IPAddress 		[NVARCHAR] (48), 
@TimeZoneBias		[NVARCHAR] (260), -- parameter not mapped to any field in table
@ProductFamily		[NVARCHAR] (260), -- parameter not mapped to any field in table	
@ProductName 		[NVARCHAR] (64),	
@ProductVersion 	[NVARCHAR] (16),
@ScannerType		[NVARCHAR] (260),
@EngineVersion		[NVARCHAR] (16),
@DATVersion		[NVARCHAR] (16),
@TaskName 		[NVARCHAR] (128),
@lEventID 		[INT],
@Severity 		[INT],
@LocalTime 		[DATETIME],
@UTCTime 		[DATETIME],
@FileName		[NVARCHAR] (260),
@VirusName		[NVARCHAR] (128),
@szVirusType		[NVARCHAR] (260),
@lVirusType		[INT],
--@SensitivityLevel  [NVARCHAR] (4),
@Source			[NVARCHAR] (260)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @TmpAnalyzer NVARCHAR(16)
	DECLARE @TmpAnalyzerIPV4 INT
	DECLARE @TmpAnalyzerIPV6 AS BINARY(16)
	DECLARE @TmpSource NVARCHAR(128)
	DECLARE @TmpSourceIPV4 INT
	DECLARE @TmpSourceIPV6 AS BINARY(16)
	DECLARE @TmpSourceHostName NVARCHAR(128)
	DECLARE @TmpSourceProcessName NVARCHAR(128)
	DECLARE @TmpTargetPort INT
	DECLARE @TmpThreatActionTaken NVARCHAR(24)
	DECLARE @TmpThreatEventID INT
	DECLARE @TmpThreatCategory NVARCHAR(128)
	DECLARE @TmpSeverity TINYINT
	DECLARE @TmpThreatHandled TINYINT

	DECLARE @IP AS BIGINT
	DECLARE @EventID INT
	DECLARE @lActionsBlocked INT 		-- Not used

	IF RIGHT(@ScannerType, LEN('2B^|2B')) = '2B^|2B'
	BEGIN
		SELECT @TmpAnalyzer = LEFT(@ScannerType, LEN(@ScannerType) - LEN('2B^|2B'))
	END
	ELSE
	BEGIN
		IF @ProductVersion = '8.0'
		OR @ProductVersion LIKE '8.0%'
		BEGIN
        		SELECT @TmpAnalyzer = 'VIRUSCAN8000'
    		END
		ELSE IF @ProductVersion = '8.5'
		OR @ProductVersion LIKE '8.5%'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8600'
		END
		ELSE IF @ProductVersion = '8.7' OR @ProductVersion = '8.7.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8700'
		END
        ELSE IF @ProductVersion = '8.8' OR @ProductVersion = '8.8.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8800'
		END
		ELSE
		BEGIN
	    		SELECT @TmpAnalyzer = 'Unknown'
		END
	END
		
	IF @lEventID > 20000
	BEGIN
		SET @TmpThreatEventID = @lEventID - 20000
	END
	ELSE
	BEGIN
		SET @TmpThreatEventID = @lEventID
	END

	IF @TmpThreatEventID IN (1024, 1026, 1037, 1051, 1053, 1059, 1061, 1095, 1096, 1099, 1100, 1103, 1202, 1203, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413, 2001, 1034, 1064, 1065, 1067, 1087, 1088, 1089, 1035, 1038, 1039, 1118, 1119, 1120, 1121, 1129, 4700, 4702, 1335, 1336)
	AND @TaskName <> 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1024, 1026, 1037, 1053, 1061, 1100, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1289, 1290, 1291, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1400, 1401, 1402, 1404, 1407, 1409, 1411, 1413)	
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'access denied'
	END
	ELSE IF @TmpThreatEventID IN (1087, 1088)
	AND @TaskName = 'OAS'
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1023, 1430)
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END
	ELSE IF @TmpThreatEventID IN (1025, 1060)
	BEGIN
		SET @TmpThreatActionTaken = 'cleaned'
	END
	ELSE IF @TmpThreatEventID IN (1027, 1028, 1054, 1055, 1101, 1104, 1278, 1279, 1280, 1281, 1293, 1303, 1306, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1405, 1408, 1410, 1414, 1415, 1416, 1417, 1418, 1419, 1420)
	BEGIN
		SET @TmpThreatActionTaken = 'deleted'
	END
	ELSE IF @TmpThreatEventID IN (1032, 1056, 1102, 1270, 1271, 1272, 1273, 1297, 1301, 1309, 1403, 1406, 1412)
	BEGIN
		SET @TmpThreatActionTaken = 'moved'
	END
	ELSE IF @TmpThreatEventID IN (1091, 1093, 1094)
	BEGIN
		SET @TmpThreatActionTaken = 'blocked'
	END
	ELSE IF @TmpThreatEventID IN (1096, 1099)
	BEGIN
		SET @TmpThreatActionTaken = 'would block'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'deny create'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'deny read'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'deny write'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1092)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'deny terminate'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x10000 OR @lActionsBlocked = 3)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny create'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x20000 OR @lActionsBlocked = 4)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny read'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x40000 OR @lActionsBlocked = 5)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny write'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x80000 OR @lActionsBlocked = 6)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny execute'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 0x100000 OR @lActionsBlocked = 7)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny delete'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 8)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny modify'
	END
	ELSE IF @TmpThreatEventID IN (1095)
	AND (@lActionsBlocked = 9)
	BEGIN
		SET @TmpThreatActionTaken = 'would deny terminate'
	END
	ELSE
	BEGIN
		SET @TmpThreatActionTaken = 'none'
	END

	IF @lEventID in (1023, 1024, 1025, 1026, 1027, 1028, 1032, 1037, 1060, 1061, 1091, 1103, 1270, 1272, 1273, 1274, 1276, 1277, 1278, 1280, 1281, 1282, 1284, 1285, 1289, 1290, 1292, 1293, 1294, 1296, 1297, 1298, 1300, 1306, 1307, 1309, 1310, 1312, 1313, 1314, 1315, 1317, 1318, 1319, 1322, 1323, 1326, 1327, 1328)
	BEGIN
		SET @TmpThreatCategory = 'av.detect'
	END
	ELSE IF @lEventID in (1053, 1054, 1055, 1056, 1100, 1101, 1102, 1104, 1271, 1275, 1279, 1283, 1291, 1301, 1302, 1303, 1304, 1305, 1308, 1311, 1316, 1320, 1321, 1324, 1325)
	BEGIN
		SET @TmpThreatCategory = 'av.detect.heuristics'
	END
	ELSE IF @lEventID > 20000
	BEGIN
		SET @TmpThreatCategory = 'av.pup'
	END
	ELSE IF @lEventID in (1094, 1096)
	BEGIN
		SET @TmpThreatCategory = 'fw.detect'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName NOT LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.file'
	END
	ELSE IF @lEventID in (1092, 1095)
	AND @FileName LIKE '\REGISTRY\%'
	BEGIN
		SET @TmpThreatCategory = 'hip.registry'
	END
	ELSE IF @lEventID in (1093, 1099)
	BEGIN
		SET @TmpThreatCategory = 'hip.bo'
	END
	ELSE IF @lEventID in (1051, 1059, 2001)
	BEGIN
		SET @TmpThreatCategory = 'ops'
	END		
	ELSE IF @lEventID in (1087)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.start'
	END	
	ELSE IF @lEventID in (1088)
	BEGIN
		SET @TmpThreatCategory = 'ops.scan.end'
	END
	ELSE IF @lEventID in (1202, 1335)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.start'
	END
	ELSE IF @lEventID in (1034, 1038, 1039, 1203, 1336)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.end'
	END	
	ELSE IF @lEventID in (1035,  1129)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.cancel'
	END
	ELSE IF @lEventID in (1067)
	BEGIN
		SET @TmpThreatCategory = 'ops.task.error'
	END
	ELSE IF @lEventID in (1064)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.start'
	END
	ELSE IF @lEventID in (1065)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.end'
	END	
	ELSE IF @lEventID in (1089, 4700, 4702)
	BEGIN
		SET @TmpThreatCategory = 'ops.service.error'
	END
	ELSE IF @lEventID in (1120)
	BEGIN
		SET @TmpThreatCategory = 'ops.update'
	END
	ELSE IF @lEventID in (1118,  1119)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.end'
	END	
	ELSE IF @lEventID in (1121)
	BEGIN
		SET @TmpThreatCategory = 'ops.update.cancel'
	END
	ELSE
	BEGIN
		SET @TmpThreatCategory = 'av'
	END

	IF @lEventID in (51, 53, 55, 56, 58, 59, 62, 64, 66, 69, 1026, 1028, 1030,
			 1031, 1033, 1042, 1043, 1044, 1045, 1050, 1051, 1055, 1057, 
			 1059, 1061, 1101, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 
			 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1294, 1295, 
			 1296, 1298, 1299, 1300, 1502, 21026, 21028, 21031, 21033, 
			 21055, 21057, 21274, 21275, 21276, 21277, 21282, 21283, 
			 21284, 21285, 21286, 21287, 21288, 21289, 21290, 21291, 
			 21292, 21294, 21295, 21296, 21298, 21299, 21300, 21401, 
			 21402, 21404, 21407, 21409, 21411, 21413)
	BEGIN
		SET @TmpThreatHandled = 0
	END
	ELSE
	BEGIN
		SET @TmpThreatHandled = 1
	END
	
	IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
	BEGIN
		EXECUTE @IP = vseConvertIPStringToIPV4 @IPAddress;
		SELECT @TmpAnalyzerIPV4  = CAST(@IP - 2147483648 AS INT);
		EXECUTE @TmpAnalyzerIPV6 = vseConvertIPStringToIPV6 @IPAddress;
	END
	ELSE
	BEGIN                              -- IPV6 Address
		EXECUTE @TmpAnalyzerIPV6 = dbo.VSE_HexStrToVarBin @IPAddress;
		SELECT  @TmpAnalyzerIPV4 = -2147483648;
	END

	IF LEN(@Source) > 0
	AND CHARINDEX(':\',@Source) > 0
	BEGIN
		-- @Source = 'C:\WINNT\System32\exectuble.exe "C:\script.vbs"'
		SELECT @TmpSourceProcessName = @Source
	END
	ELSE IF LEN(@Source) > 0
	AND CHARINDEX(':',@Source) > 0
	BEGIN
		-- @Source = '123.123.123.123:80'
		-- @Source = 'machinename:80'
	
		IF ISNUMERIC (RIGHT (@Source, LEN(@Source) - CHARINDEX(':',@Source))) > 0
		BEGIN
			SELECT @TmpTargetPort = RIGHT (@Source, LEN(@Source) - CHARINDEX(':',@Source))
		END
	
		SELECT @TmpSource = LEFT (@Source, CHARINDEX(':',@Source) - 1)
	END
	ELSE IF LEN(@Source) > 0
	AND CHARINDEX('(',@Source) > 0
	AND CHARINDEX(')',@Source) > CHARINDEX('(',@Source)
	BEGIN
		-- @Source = '123.123.123.123 (machinename)'
		SELECT @TmpSource = LEFT (@Source, CHARINDEX('(',@Source) - 1)	
		SELECT @TmpSourceHostName = RIGHT (LEFT(@Source, LEN(@Source) - 1), LEN(@Source) - CHARINDEX('(',@Source) - 1)
	END
	ELSE
	BEGIN
		SELECT @TmpSourceHostName = @Source
	END
	
	IF LEN(@TmpSource) > 0
	BEGIN
		IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
		BEGIN
			EXECUTE @IP = vseConvertIPStringToIPV4 @TmpSource;
			IF @IP > 0
			BEGIN		
				SELECT @TmpSourceIPV4 = CAST(@IP - 2147483648 AS INT);
				EXECUTE @TmpSourceIPV6 = vseConvertIPStringToIPV6 @TmpSource;
			END
			ELSE
			BEGIN
				SELECT @TmpSourceHostName = @TmpSource
			END
		END
		ElSE
		BEGIN -- IPV6 Address
			EXECUTE @TmpSourceIPV6 = dbo.VSE_HexStrToVarBin @TmpSource;
			SELECT  @TmpSourceIPV4 = -2147483648;
		END
	END

	IF @Severity = 4		-- Critical(4) -> Critical(2)
	BEGIN
		SELECT @TmpSeverity = 2
	END
	ELSE IF @Severity = 3		-- Major(3) -> Alert(1)
	BEGIN
		SELECT @TmpSeverity = 1
	END
	ELSE IF @Severity = 2		-- Minor(2) -> Notice(5)
	BEGIN
		SELECT @TmpSeverity = 5
	END
	ELSE IF @Severity = 1		-- Warning(1) -> Warning(4)
	BEGIN
		SELECT @TmpSeverity = 4
	END
	ELSE IF @Severity = 0		-- Informational(0) -> Information(6)
	BEGIN
		SELECT @TmpSeverity = 6
	END

      EXEC EPOEvents_InsertEvent2
    	DEFAULT, -- @ServerID nvarchar(16) = 'ePO_SERVERNAME',
    	@UTCTime, -- @DetectedUTC datetime,
    	@AgentGUID, -- @AgentGUID uniqueidentifier,

    	@TmpAnalyzer,      -- @Analyzer nvarchar(16),
    	@ProductName,   -- @AnalyzerName nvarchar(64),
    	@ProductVersion,-- @AnalyzerVersion nvarchar(20),         
    	@MachineName,   -- @AnalyzerHostName nvarchar(128) = NULL,
	@TmpAnalyzerIPV4,     -- @AnalyzerIPV4 int = NULL,
    	@TmpAnalyzerIPV6,     -- @AnalyzerIPV6 binary(16) = NULL,
    	DEFAULT,        -- @AnalyzerMAC nvarchar(16) = NULL,
    	@DATVersion,    -- @AnalyzerDATVersion nvarchar(20) = NULL,
    	@EngineVersion, -- @AnalyzerEngineVersion nvarchar(20) = NULL,
    	@TaskName,	-- @AnalyzerDetectionMethod nvarchar(20) = NULL,

    	@TmpSourceHostName,     -- @SourceHostName nvarchar(128) = NULL,
    	@TmpSourceIPV4, -- @SourceIPV4 int = NULL,
    	@TmpSourceIPV6,	-- @SourceIPV6 binary(16) = NULL,
    	DEFAULT,        -- @SourceMAC nvarchar(16) = NULL,
    	DEFAULT,        -- @SourceUserName nvarchar(128) = NULL,
    	@TmpSourceProcessName,  -- @SourceProcessName nvarchar(128) = NULL,
    	DEFAULT,        -- @SourceURL nvarchar(256) = NULL,

    	@MachineName,	-- @TargetHostName nvarchar(128) = NULL,
	@TmpAnalyzerIPV4,     -- @TargetIPV4 int = NULL,
    	@TmpAnalyzerIPV6,     -- @TargetIPV6 binary(16) = NULL,
    	DEFAULT,        -- @TargetMAC nvarchar(16) = NULL,
    	@UserName,		-- @TargetUserName nvarchar(128) = NULL,
    	DEFAULT,        -- @TargetPort int = NULL,
    	DEFAULT,        -- @TargetProtocol nvarchar(16) = NULL,
    	DEFAULT,		-- @TargetProcessName nvarchar(128) = NULL,
    	@FileName,		-- @TargetFileName nvarchar(266) = NULL,

    	@TmpThreatCategory,   -- @ThreatCategory nvarchar(128),    ==> @SignatureID???
    	@lEventID,      -- @ThreatEventID int,
    	@VirusName,     -- @ThreatName nvarchar(128),
    	@szVirusType,   -- @ThreatType nvarchar(32),
    	@TmpSeverity,	-- @ThreatSeverity tinyint = 1,
    	@TmpThreatActionTaken,      -- @ThreatActionTaken nvarchar(24) = 'none',
    	@TmpThreatHandled,-- @ThreatHandled tinyint = 1,

    	@EventID OUTPUT, -- @AutoID int = NULL ,
    	DEFAULT;        -- @AutoGUID uniqueidentifier = NULL OUTPUT

  	--IF @lEventID in (1022)
    --BEGIN
    --INSERT INTO VSECustomEvent ([ParentID],[SensitivityLevel])
    --VALUES (@EventID,@SensitivityLevel)
    --END

	SELECT @EventID AS nResult;
END
GO

-----------------------------------------------------------
-- VSE_InsertGenericEvent
-----------------------------------------------------------

IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'VSE_InsertGenericEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.VSE_InsertGenericEvent
GO

CREATE PROCEDURE dbo.VSE_InsertGenericEvent
(
@AgentGUID                 [UNIQUEIDENTIFIER],
@UserName                  [NVARCHAR] (32),
@MachineName               [NVARCHAR] (512),
@OSName                    [NVARCHAR] (260),	-- parameter not mapped to any field in table	
@IPAddress                 [NVARCHAR] (48),
@TimeZoneBias              [NVARCHAR] (260),	-- parameter not mapped to any field in table
@ProductFamily             [NVARCHAR] (260),	-- parameter not mapped to any field in table
@ProductName               [NVARCHAR] (64),         
@ProductVersion            [NVARCHAR] (16),
@ScannerType               [NVARCHAR] (260),
@EngineVersion             [NVARCHAR] (16),
@DATVersion                [NVARCHAR] (16),
@TaskName                  [NVARCHAR] (128),
@lEventID                     [INT],
@Severity                     [INT],
@LocalTime                  [DATETIME],
@UTCTime                    [DATETIME],
@Param1                  [NVARCHAR] (1024),
@Param2                  [NVARCHAR] (1024),
@Param3                  [NVARCHAR] (1024),
@Param4                  [NVARCHAR] (1024)
)
AS
BEGIN
	SET NOCOUNT ON
	
	DECLARE @TmpAnalyzer NVARCHAR(16)	
	DECLARE @TmpAnalyzerIPV4 INT
	DECLARE @TmpAnalyzerIPV6 AS BINARY(16)
	DECLARE @TmpSeverity TINYINT	
	DECLARE @TmpThreatHandled TINYINT
	
	DECLARE @IP AS BIGINT
	DECLARE @EventID INT
	
	IF RIGHT(@ScannerType, LEN('2B^|2B')) = '2B^|2B'
	BEGIN
		SELECT @TmpAnalyzer = LEFT(@ScannerType, LEN(@ScannerType) - LEN('2B^|2B'))
	END
	ELSE
	BEGIN
		IF @ProductVersion = '8.0'
		OR @ProductVersion LIKE '8.0%'
		BEGIN
        		SELECT @TmpAnalyzer = 'VIRUSCAN8000'
    		END
		ELSE IF @ProductVersion = '8.5'
		OR @ProductVersion LIKE '8.5%'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8600'
		END
		ELSE IF @ProductVersion = '8.7' OR @ProductVersion = '8.7.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8700'
		END
        ELSE IF @ProductVersion = '8.8' OR @ProductVersion = '8.8.0'
		BEGIN
	    		SELECT @TmpAnalyzer = 'VIRUSCAN8800'
		END
		ELSE
		BEGIN
	    		SELECT @TmpAnalyzer = 'Unknown'
		END
	END	
	
	IF(CHARINDEX(N':',@IPAddress) = 0) -- IPV4 Address
	BEGIN
		EXECUTE @IP = vseConvertIPStringToIPV4 @IPAddress;
		SELECT @TmpAnalyzerIPV4  = CAST(@IP - 2147483648 AS INT);
		EXECUTE @TmpAnalyzerIPV6 = vseConvertIPStringToIPV6 @IPAddress;
	END
	ELSE
	BEGIN                              -- IPV6 Address
		EXECUTE @TmpAnalyzerIPV6 = dbo.VSE_HexStrToVarBin @IPAddress;
		SELECT  @TmpAnalyzerIPV4 = -2147483648;
	END
	
	IF @Severity = 4		-- Critical(4) -> Critical(2)
	BEGIN
		SELECT @TmpSeverity = 2
	END
	ELSE IF @Severity = 3		-- Major(3) -> Alert(1)
	BEGIN
		SELECT @TmpSeverity = 1
	END
	ELSE IF @Severity = 2		-- Minor(2) -> Notice(5)
	BEGIN
		SELECT @TmpSeverity = 5
	END
	ELSE IF @Severity = 1		-- Warning(1) -> Warning(4)
	BEGIN
		SELECT @TmpSeverity = 4
	END
	ELSE IF @Severity = 0		-- Informational(0) -> Information(6)
	BEGIN
		SELECT @TmpSeverity = 6
	END	
	
	IF @Param4 = '0'
	BEGIN
		SET @TmpThreatHandled = 0
	END
	ELSE
	BEGIN
		SET @TmpThreatHandled = 1
	END
	
	EXEC EPOEvents_InsertEvent2
    	DEFAULT,			-- @ServerID nvarchar(16) = 'ePO_SERVERNAME',
    	@UTCTime,			-- @DetectedUTC datetime,
    	@AgentGUID,			-- @AgentGUID uniqueidentifier,

    	@TmpAnalyzer,		-- @Analyzer nvarchar(16),
    	@ProductName,		-- @AnalyzerName nvarchar(64),
    	@ProductVersion,	-- @AnalyzerVersion nvarchar(20),         
    	@MachineName,		-- @AnalyzerHostName nvarchar(128) = NULL,
		@TmpAnalyzerIPV4,   -- @AnalyzerIPV4 int = NULL,
    	@TmpAnalyzerIPV6,   -- @AnalyzerIPV6 binary(16) = NULL,
    	DEFAULT,			-- @AnalyzerMAC nvarchar(16) = NULL,
    	@DATVersion,		-- @AnalyzerDATVersion nvarchar(20) = NULL,
    	@EngineVersion,		-- @AnalyzerEngineVersion nvarchar(20) = NULL,
    	@TaskName,			-- @AnalyzerDetectionMethod nvarchar(20) = NULL,

    	DEFAULT,			-- @SourceHostName nvarchar(128) = NULL,
    	DEFAULT,			-- @SourceIPV4 int = NULL,
    	DEFAULT,				-- @SourceIPV6 binary(16) = NULL,
    	DEFAULT,			-- @SourceMAC nvarchar(16) = NULL,
    	DEFAULT,			-- @SourceUserName nvarchar(128) = NULL,
    	DEFAULT,			-- @SourceProcessName nvarchar(128) = NULL,
    	DEFAULT,			-- @SourceURL nvarchar(256) = NULL,

    	@MachineName,		-- @TargetHostName nvarchar(128) = NULL,
		@TmpAnalyzerIPV4,   -- @TargetIPV4 int = NULL,
    	@TmpAnalyzerIPV6,	-- @TargetIPV6 binary(16) = NULL,
    	DEFAULT,			-- @TargetMAC nvarchar(16) = NULL,
    	@UserName,			-- @TargetUserName nvarchar(128) = NULL,
    	DEFAULT,			-- @TargetPort int = NULL,
    	DEFAULT,			-- @TargetProtocol nvarchar(16) = NULL,
    	DEFAULT,			-- @TargetProcessName nvarchar(128) = NULL,
    	@Param1,			-- @TargetFileName nvarchar(266) = NULL,

    	@Param2,			-- @ThreatCategory nvarchar(128),    ==> @SignatureID???
    	@lEventID,			-- @ThreatEventID int,
    	'',			        -- @ThreatName nvarchar(128),
    	'',			        -- @ThreatType nvarchar(32),
    	@TmpSeverity,		-- @ThreatSeverity tinyint = 1,
    	@Param3,			-- @ThreatActionTaken nvarchar(24) = 'none',
    	@TmpThreatHandled,	-- @ThreatHandled tinyint = 1,

    	@EventID OUTPUT,	-- @AutoID int = NULL ,
    	DEFAULT;			-- @AutoGUID uniqueidentifier = NULL OUTPUT
	
	
	
	SELECT @EventID AS nResult;
END
GO	