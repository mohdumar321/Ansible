if exists (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[vseConvertIPStringToIPV4]'))
	drop function [dbo].[vseConvertIPStringToIPV4]
GO

CREATE FUNCTION [dbo].[vseConvertIPStringToIPV4]
(
	@ipstr nvarchar(64)
)
RETURNS bigint
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ipv4 bigint;
	SET @ipv4 = 0;

	-- cleanup string for starters
	SET @ipstr = LTrim(RTrim(@ipstr));
	IF (LEN(@ipstr) = 0)
		RETURN NULL;

	-- parse string (weak parse, but efficient)
	DECLARE @nPos int;
	SET @nPos = CHARINDEX(N'.', @ipstr);
	if (@nPos > 0)
	BEGIN
		DECLARE @strA nvarchar(4);
		SET @strA = SUBSTRING(@ipstr, 1, @nPos-1);
		SET @ipstr = SUBSTRING(@ipstr, @nPos+1, LEN(@ipstr) - @nPos);
		SET @nPos = CHARINDEX(N'.', @ipstr);
		if (@nPos > 0)
		BEGIN
			DECLARE @strB nvarchar(4);
			SET @strB = SUBSTRING(@ipstr, 1, @nPos-1);
			SET @ipstr = SUBSTRING(@ipstr, @nPos+1, LEN(@ipstr) - @nPos);
			SET @nPos = CHARINDEX(N'.', @ipstr);
			if (@nPos > 0)
			BEGIN
				DECLARE @strC nvarchar(4);
				SET @strC = SUBSTRING(@ipstr, 1, @nPos-1);
				SET @ipstr = SUBSTRING(@ipstr, @nPos+1, LEN(@ipstr) - @nPos);
				SET @ipv4 = CONVERT(bigint, @strA) * POWER(2,24) +
							CONVERT(bigint, @strB) * POWER(2,16) +
							CONVERT(bigint, @strC) * POWER(2,8) +
							CONVERT(bigint, @ipstr);
			END
		END
	END
	RETURN @ipv4;
END
GO

if exists (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[vseConvertIPStringToIPV6]'))
	drop function [dbo].[vseConvertIPStringToIPV6]
GO

CREATE FUNCTION [dbo].[vseConvertIPStringToIPV6]
(
	@ipstr nvarchar(64)
)
RETURNS binary(16)
AS
BEGIN
	RETURN (0x00000000000000000000FFFF + CONVERT(binary(4), [dbo].[epoConvertIPStringToIPV4](@ipstr)))
END
GO