
declare @Continue int
select @Continue = 1
DECLARE @ProductCode NVARCHAR(100)
DECLARE @PlatformCodeW NVARCHAR(100)
DECLARE @TaskType1 NVARCHAR(100)
DECLARE @TaskType2 NVARCHAR(100)
DECLARE @PlatformCodeS NVARCHAR(100)
DECLARE @PlatformCodeW10 NVARCHAR(100)
DECLARE @PlatformCodeS10 NVARCHAR(100)

SET @ProductCode='VIRUSCAN8800'
SET @PlatformCodeW='WIN8W'
SET @PlatformCodeW10='WINXW'
SET @TaskType1='VSC700_Scan_Task'
SET @TaskType2='VSC700_Quarantine_Restore'
SET @PlatformCodeS='WIN8S'
SET @PlatformCodeS10='WINXS'

if not exists(select ePOVersion from EPOServerInfo
				where ePOVersion like '4.0.%' or ePOVersion like'4.5.%')
begin
	select @Continue = 0
end

--Do this for epo 4.0 or 4.5
if @Continue=1
BEGIN

UPDATE [EPOTask]
   SET [PlatformsSupported] = [PlatformsSupported]+'|'+@PlatformCodeW,
       [TheTimestamp] = @@DBTS
   WHERE [ProductCode] = @ProductCode And [PlatformsSupported] Not
Like '%'+@PlatformCodeW+'%'
 AND [PlatformsSupported] LIKE '%WXPW%'
 AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2)

UPDATE [EPOTask]
   SET [PlatformsSupported] = [PlatformsSupported]+'|'+@PlatformCodeS,
       [TheTimestamp] = @@DBTS
   WHERE [ProductCode] = @ProductCode And [PlatformsSupported] Not
Like '%'+@PlatformCodeS+'%'
 AND [PlatformsSupported] LIKE '%WXPW%'
 AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2)

UPDATE [EPOTask]
   SET [PlatformsSupported] = [PlatformsSupported]+'|'+@PlatformCodeW10,
       [TheTimestamp] = @@DBTS
   WHERE [ProductCode] = @ProductCode And [PlatformsSupported] Not
Like '%'+@PlatformCodeW10+'%'
 AND [PlatformsSupported] LIKE '%WXPW%'
 AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2)

UPDATE [EPOTask]
   SET [PlatformsSupported] = [PlatformsSupported]+'|'+@PlatformCodeS10,
       [TheTimestamp] = @@DBTS
   WHERE [ProductCode] = @ProductCode And [PlatformsSupported] Not
Like '%'+@PlatformCodeS10+'%'
 AND [PlatformsSupported] LIKE '%WXPW%'
 AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2)

END

--Do this for epo 4.6/5.0
ELSE if @Continue=0

BEGIN

UPDATE [EPOTaskTypes]
   SET [PlatformsSupported] = [PlatformsSupported]+'|'+@PlatformCodeW
   WHERE [ProductCode] = @ProductCode And [PlatformsSupported] Not
Like '%'+@PlatformCodeW+'%'
 AND [PlatformsSupported] LIKE '%WXPW%'
 AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2)


UPDATE [EPOTaskTypes]
   SET [PlatformsSupported] = [PlatformsSupported]+'|'+@PlatformCodeS
   WHERE [ProductCode] = @ProductCode And [PlatformsSupported] Not
Like '%'+@PlatformCodeS+'%'
 AND [PlatformsSupported] LIKE '%WXPW%'
 AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2)

UPDATE [EPOTaskTypes]
   SET [PlatformsSupported] = [PlatformsSupported]+'|'+@PlatformCodeW10
   WHERE [ProductCode] = @ProductCode And [PlatformsSupported] Not
Like '%'+@PlatformCodeW10+'%'
 AND [PlatformsSupported] LIKE '%WXPW%'
 AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2)


UPDATE [EPOTaskTypes]
   SET [PlatformsSupported] = [PlatformsSupported]+'|'+@PlatformCodeS10
   WHERE [ProductCode] = @ProductCode And [PlatformsSupported] Not
Like '%'+@PlatformCodeS10+'%'
 AND [PlatformsSupported] LIKE '%WXPW%'
 AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2)

UPDATE [EPOTaskObjects]
  SET [SupportedPlatforms] = NULL
  WHERE [TaskTypeID] in (SELECT [TasktypeID] from [EPOTaskTypes]
  WHERE [ProductCode] = @ProductCode AND ([TaskType]=@TaskType1 OR [TaskType]=@TaskType2))
  AND [SupportedPlatforms] NOT Like 'NULL'

END

