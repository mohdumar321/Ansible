
declare @Continue int
select @Continue = 1

if not exists(select ePOVersion from EPOServerInfo
				where ePOVersion like '4.0.%' or ePOVersion like'4.5.%')
begin
	select @Continue = 0
end

--Do this for epo 4.0 or 4.5
if @Continue=1
BEGIN
DECLARE @JoiningID int

DECLARE TaskTableCursor CURSOR FORWARD_ONLY READ_ONLY FOR
SELECT autoid from EPOTask where ProductCode = 'VIRUSCAN8800' and TaskType = 'VSC700_Scan_Task' and ParentType in (6,5,4,3,1)

OPEN TaskTableCursor
FETCH NEXT FROM TaskTableCursor
INTO @JoiningID

WHILE @@FETCH_STATUS = 0
BEGIN
EXEC VSE_RemoveCookieSpyware_Proc @JoiningID

FETCH NEXT FROM TaskTableCursor
	INTO @JoiningID
END
CLOSE TaskTableCursor
DEALLOCATE TaskTableCursor

--Set 'Alert_ExcludeCookies' to 1 for all existing tasks
UPDATE EPOTaskSettings
SET Value = 1
WHERE SettingName = 'Alert_ExcludeCookies' AND ParentID IN (SELECT S.ParentID FROM [EPOTask] O
							INNER JOIN EPOTaskSettings S ON O.AutoID = S.ParentID
								WHERE ParentType in (6,5,4,3,1)
									AND TaskType = 'VSC700_Scan_Task'
									AND ProductCode = 'VIRUSCAN8800'
									AND SettingName = 'Alert_ExcludeCookies')

END

ELSE if @Continue=0
BEGIN
Declare @taskObjid int
Declare c1 CURSOR FORWARD_ONLY FOR
SELECT TaskObjectId FROM [EPOTaskObjects]
							INNER JOIN EPOTaskTypes ON EPOTaskTypes.TaskTypeId = EPOTaskObjects.TaskTypeId
								WHERE (32 & TaskObjectFlag = 0)
									AND TaskType = 'VSC700_Scan_Task'
									AND ProductCode = 'VIRUSCAN8800'

OPEN c1
FETCH NEXT FROM c1 INTO @taskObjid

WHILE @@FETCH_STATUS =0
BEGIN

EXEC VSE_epo46_Remove_Cookies @taskObjid

FETCH NEXT FROM c1 INTO @taskObjid
END

CLOSE c1
DEALLOCATE c1

--Set 'Alert_ExcludeCookies' to 1 for all existing tasks
UPDATE EPOTaskObjectSettings
SET SettingValue = 1 WHERE AutoID IN (
SELECT OS.AutoId FROM [EPOTaskObjects] O
							INNER JOIN EPOTaskTypes T ON T.TaskTypeId = O.TaskTypeId JOIN
								EPOTaskObjectSettings OS ON OS.TaskObjectID=O.TaskObjectID WHERE (32 & TaskObjectFlag = 0)
									AND TaskType = 'VSC700_Scan_Task'
									AND ProductCode = 'VIRUSCAN8800'
									AND SectionName = 'Reports'
									AND SettingName = 'Alert_ExcludeCookies')


END

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[dbo].[VSE_RemoveCookieSpyware_Proc]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[VSE_RemoveCookieSpyware_Proc]
	GO

if Exists(Select * from sysobjects where id = OBJECT_ID(N'[dbo].[VSE_epo46_Remove_Cookies]') and OBJECTPROPERTY(id,N'IsProcedure')=1)
DROP PROCEDURE [dbo].[VSE_epo46_Remove_Cookies]
GO
