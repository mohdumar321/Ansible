// "ExtensionMode" enumeration
var g_ExtensionMode = 0;
var g_AllFiles      = 1;
var g_DefaultPlus   = 2;
var g_Default       = 3;
var g_Specified     = 4;

 // Exclusions constants to OR against the "flags" value..
var ON_READ 		= 2;
var ON_WRITE		= 1;
var INCLUDE_SUBFOLDERS	= 4;

var ACTION_VALUE_INVALID	= 0;
var ACTION_VALUE_CONTINUE	= 1;
var ACTION_VALUE_DELETE		= 4;
var ACTION_VALUE_CLEAN		= 5;
var ACTION_VALUE_DENY		= 7;

var g_iCurrentPrimaryActionValue 			= 0;
var g_iCurrentPrimaryActionUnwantedValue 	= 0;
var g_iCurrentSecondaryActionValue			= 0;
var g_iCurrentSecondaryActionUnwantedValue	= 0;

// Global Dirty flag to handle list control
var g_bFormDirty = false;

// Global DOM objects
var g_primaryActionSelect;
var g_secondaryActionSelect;
var g_primaryActionSelectUnwanted;
var g_secondaryActionSelectUnwanted;

// Exclusions
var addeditExclDialog = null;
var g_bNewExclusion = false;
var g_ExclusionListWidget;
var g_arrListExclusionData = new Array();

ExclusionDataItem = function(obj)
{
    var exclData = "";
}

// Variables for Workstation/Server toggle
var uAction = new Array();
var uSecAction = new Array();
var dwMacroHeuristicsLevel = new Array();
var dwProgramHeuristicsLevel = new Array();
var ScanArchives = new Array();
var ScanMime = new Array();
var ScanBackupReads = new Array();
var bNetworkScanEnabled = new Array();
var bScanIncoming = new Array();
var bScanOutgoing = new Array();
var LocalExtensionMode = new Array();
var NetworkExtensionMode = new Array();
var szIncludeExts = new Array();
var szProgExts = new Array();
var bAppendExclusions = new Array();
var ApplyNVP = new Array();
var uAction_Program = new Array();
var uSecAction_Program = new Array();
var ExclusionsList = new Array();

// Risk processes section
var g_arrListRPData = new Array();
var g_RiskProcessesListWidget;
var addeditRPDialog = null;
var g_bNewRPItem = false;

RPDataItem = function(obj)
{
    var rpData = "";
}


function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function Exclusion_AddCallback(newRow)
{
    if(newRow != null)
    {
        var itemID = newRow.id.replace("divID_ExclusionsList_lwrow_", "");
        var exclusionItemElement = $("exclusion_item_" + itemID);
        var exclusionSubsElement = $("exclusion_include_subs_" + itemID);
        var exclusionAccessElement = $("exclusion_read_write_" + itemID);
        var hiddenValue = "||";

        var ruleItem = g_ExclusionListWidget.getItem(newRow.id);
        if(ruleItem != null)
        {
            hiddenValue = ruleItem.itemData.exclData;
        }

        if(hiddenValue != "||" && hiddenValue !="")
        {
            var exclusionSplit = hiddenValue.split("|");
            if(exclusionSplit.length > 0)
            {
                var exclusionFlags = 0;
                if(exclusionSplit[1])
                {
                    exclusionFlags = parseInt(exclusionSplit[1]);
                }

                $("labelID_SubsYes_" + itemID).style.display = "None";
                $("labelID_SubsNo_" + itemID).style.display = "None";
                $("labelID_SubsNA_" + itemID).style.display = "";

                // exclusion is by age
                if(exclusionSplit[0] >= "0" && exclusionSplit[0] <= "2")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        if(exclusionSplit[0] == "0")
                        {
                            $("labelID_TypeModifiedAge_" + itemID).style.display = "";
                            $("labelID_TypeModifiedAge_" + itemID).innerHTML = $("labelID_TypeModifiedAge_" + itemID).innerHTML.replace("DDD", exclusionSplit[2]);
                        }
                        else if(exclusionSplit[0] == "1")
                        {
                            $("labelID_TypeAccessedAge_" + itemID).style.display = "";
                            $("labelID_TypeAccessedAge_" + itemID).innerHTML = $("labelID_TypeAccessedAge_" + itemID).innerHTML.replace("DDD", exclusionSplit[2]);
                        }
                        else if(exclusionSplit[0] == "2")
                        {
                            $("labelID_TypeCreatedAge_" + itemID).style.display = "";
                            $("labelID_TypeCreatedAge_" + itemID).innerHTML = $("labelID_TypeCreatedAge_" + itemID).innerHTML.replace("DDD", exclusionSplit[2]);
                        }
                    }
                }
                // By pattern
                else if(exclusionSplit[0] == "3")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        $("labelID_Pattern_" + itemID).style.display = "";
                        $("labelID_Pattern_" + itemID).innerHTML = exclusionSplit[2];

                        if(exclusionFlags & INCLUDE_SUBFOLDERS)
                        {
                            $("labelID_SubsYes_" + itemID).style.display = "";
                            $("labelID_SubsNo_" + itemID).style.display = "None";
                            $("labelID_SubsNA_" + itemID).style.display = "None";
                        }
                        else
                        {
                            $("labelID_SubsYes_" + itemID).style.display = "None";
                            $("labelID_SubsNo_" + itemID).style.display = "";
                            $("labelID_SubsNA_" + itemID).style.display = "None";
                        }
                    }
                }
                // By file type
                else if(exclusionSplit[0] == "4")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        if(exclusionSplit[2] == ":::")
                        {
                            $("labelID_TypeNoExt_" + itemID).style.display = "";
                        }
                        else
                        {
                            $("labelID_TypeExt_" + itemID).style.display = "";
                            $("labelID_TypeExt_" + itemID).innerHTML = $("labelID_TypeExt_" + itemID).innerHTML.replace("TTT", exclusionSplit[2]);
                        }
                    }
                }
                // Windows Filexe Protection
                else if(exclusionSplit[0] == "5")
                {
                    $("labelID_TypeWFP_" + itemID).style.display = "";
                }
                // Unknown -- should never get here
                else
                {
                    exclusionItemElement.innerHTML = "Error";
                }

                var bOnRead = exclusionFlags & ON_READ;
                var bOnWrite = exclusionFlags & ON_WRITE;

                if(bOnRead && bOnWrite)
                {
                    $("labelID_ExclOnRead_" + itemID).style.display = "";
                    $("labelID_ExclSlash_" + itemID).style.display = "";
                    $("labelID_ExclOnWrite_" + itemID).style.display = "";
                }
                else if(bOnRead)
                {
                    $("labelID_ExclOnRead_" + itemID).style.display = "";
                    $("labelID_ExclSlash_" + itemID).style.display = "none";
                    $("labelID_ExclOnWrite_" + itemID).style.display = "none";
                }
                else if(bOnWrite)
                {
                    $("labelID_ExclOnRead_" + itemID).style.display = "none";
                    $("labelID_ExclSlash_" + itemID).style.display = "none";
                    $("labelID_ExclOnWrite_" + itemID).style.display = "";
                }
            }
        }

        validatePolicy();
    }
}

function exclUpdateRowDataCallback(selectedRow)
{
    // Update ExclusionData with data stored in Widget
    var exclItems = g_ExclusionListWidget.getItemList();
    g_arrListExclusionData[g_CurrentPolicyType] = new Array();
    for(i = 0; i < exclItems.length; ++i)
    {
        g_arrListExclusionData[g_CurrentPolicyType][i] = exclItems[i].itemData;                            
    }

    populateExclusionsList();
}

function exclRemoveCallback()
{
    validatePolicy();
}

function fnSetPrimaryAction(selectID_CurrentAction, iPrimaryValue)
{
	for (var i = 0; i < selectID_CurrentAction.length; i++)
	{
		if ( parseInt(selectID_CurrentAction.options[i].value) == parseInt(iPrimaryValue) )
		{
			selectID_CurrentAction.selectedIndex = i;
		}
	}
}

function fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue)
{
	for(var i=0; i<selectID_CurrentSecondaryAction.length;i++)
	{
		if (selectID_CurrentSecondaryAction.options[i].value == iSecondaryValue)
		{
			selectID_CurrentSecondaryAction.selectedIndex = i;
		}
	}
}

function fnSecondaryAction_OnChange(selectID_CurrentSecondaryAction, iSecondaryValue, bPromptForDelete)
{
    if( selectID_CurrentSecondaryAction == g_secondaryActionSelect )
    {
        g_iCurrentSecondaryActionValue = iSecondaryValue;
    }
    else if( selectID_CurrentSecondaryAction == g_secondaryActionSelectUnwanted )
    {
        g_iCurrentSecondaryActionProgramValue = iSecondaryValue;
    }

    fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue);
}

function fnApplyNVPChange()
{
    fnToggleApplyNVPState();
    validatePolicy();
}

function fnToggleApplyNVPState()
{
    $("selectID_UnwantedPrimaryAction").disabled = false;
    $("selectID_UnwantedSecondaryAction").disabled = false;

    if ($("checkboxID_ApplyNVP").checked)
    {
        $("selectID_UnwantedPrimaryAction").disabled = false;

        if(($("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_CONTINUE)&&
           ($("selectID_UnwantedPrimaryAction").value != ACTION_VALUE_DENY))
        {
            $("selectID_UnwantedSecondaryAction").disabled = false;
        }
        else
        {
            $("selectID_UnwantedSecondaryAction").disabled = true;
        }
    }
    else
    {
        $("selectID_UnwantedPrimaryAction").disabled = true;
        $("selectID_UnwantedSecondaryAction").disabled = true;
    }
}

function appAddCallback(newDiv)
{
    if(g_CurrentPolicyType == 0)
    {
        var itemID = newDiv.id.replace("divID_WrkstnApplicationsList_awrow_", "");
        var inputElement = $("wrkstn_app_filetype_" + itemID);

        if(inputElement != null)
        {
            OrionEvent.registerHandlerById("wrkstn_app_filetype_" + itemID, validatePolicy, null, "keyup", false);
        }
        Wrkstn_UpdateAppIDList();
    }
    else
    {
        var itemID = newDiv.id.replace("divID_ServerApplicationsList_awrow_", "");
        var inputElement = $("server_app_filetype_" + itemID);

        if(inputElement != null)
        {
            OrionEvent.registerHandlerById("server_app_filetype_" + itemID, validatePolicy, null, "keyup", false);
        }
        Server_UpdateAppIDList();
    }
}

function appRemoveCallback()
{
    if(g_CurrentPolicyType == 0)
    {
        Wrkstn_UpdateAppIDList();
    }
    else
    {
        Server_UpdateAppIDList();
    }

    validatePolicy();
}

function Wrkstn_UpdateAppIDList()
{
    // update the hidden list of element ID's containing values
     storeRiskProcessItems(g_CurrentPolicyType);
   var szRiskProcessesList = "";
    for(var i = 0; i < g_arrListRPData[0].length; ++i)
    {
      szRiskProcessesList += g_arrListRPData[0][i].rpData;
      if((i+1) < g_arrListRPData[0].length)
      {
         szRiskProcessesList += ",";
      }
    }

    $("hiddenID_WrkstnApplicationItemIDList").value = szRiskProcessesList;
}

function Server_UpdateAppIDList()
{
    storeRiskProcessItems(g_CurrentPolicyType);
    var szRiskProcessesList = "";
    for(var i = 0; i < g_arrListRPData[1].length; ++i)
    {
         szRiskProcessesList += g_arrListRPData[1][i].rpData;
         if((i+1) < g_arrListRPData[1].length)
         {
             szRiskProcessesList += ",";
         }
     }
    $("hiddenID_ServerApplicationItemIDList").value = szRiskProcessesList;
}

function validateFileTypes(szFileTypes)
{
    var valid = true;
    var filetypelen = 0;
    var wildcharlen = 0;

    if(szFileTypes != "")
    {
        // convert whitespace to spaces
        szFileTypes.replace(/\W+/g,' ');
        var szFileTypeTokens = szFileTypes.split(" ");

        var r = szFileTypes.indexOf("/");

        if (r == -1)
            r = szFileTypes.indexOf("\"");

        if (r == -1)
            r = szFileTypes.indexOf("|");

        if (r == -1)
            r = szFileTypes.indexOf("<");

        if (r == -1)
            r = szFileTypes.indexOf(">");

        if (r == -1)
            r = szFileTypes.indexOf("\\");

//We do not allow * for filetypes.

        if (r == -1)
            r = szFileTypes.indexOf("*");

//We do not allow only ? for filetype, for eg: ?, ???
        if (r == -1)
        {
           filetypelen = szFileTypes.length;

           for(var i=0; i<filetypelen; i++)
           {
                if(szFileTypes.charAt(i) == "?")
                {
                    wildcharlen++;
                }
            }

            if(filetypelen == wildcharlen)
                valid = false;
        }

        if(r != -1)
        {
            valid = false;
        }

        for(var i=0; valid && (i < szFileTypeTokens.length); ++i)
        {
            if(szFileTypeTokens[i].length > 3)
            {
                valid = false;
            }
            else if(szFileTypeTokens[i] != ":::") 
            {
                r = szFileTypeTokens[i].indexOf(":");
                if (r != -1)
                {
                    valid = false;
                }
            }
        }

    }

    return valid;
}

function Wrkstn_ValidateExclusions(exclusionRows)
{
    var valid = true;

    var elementIDList = "";
    for(var i in exclusionRows)
    {
        var currentItemID = exclusionRows[i].replace("divID_WrkstnExclusionsList_awrow_", "");
        var exclusionType = $("wrkstn_select_exclusion_" + currentItemID).value;

        if(exclusionType == 1) // by pattern
        {
            var szPattern = $("wrkstn_excl_pattern_" + currentItemID).value;            
            if(!IsValidExclusionPattern(szPattern))
            {
                valid = false;
                break;
            }
        }
        else if(exclusionType == 2) // by type
        {
            var szFileType = $("wrkstn_excl_filetype_" + currentItemID).value;
            if(!IsValidExclusionFileType(szFileType))
            {
                valid = false;
                break;
            }
        }
        else if(exclusionType == 3) // by age
        {
            var fileAge = $("wrkstn_excl_fileage_" + currentItemID).value;
            if(!IsValidFileAge(fileAge))
            {
                valid = false;
                break;
            }
        }
    }

    return valid;
}

function Server_ValidateExclusions(exclusionRows)
{
    var valid = true;

    var elementIDList = "";
    for(var i in exclusionRows)
    {
        var currentItemID = exclusionRows[i].replace("divID_ServerExclusionsList_awrow_", "");
        var exclusionType = $("server_select_exclusion_" + currentItemID).value;

        if(exclusionType == 1) // by pattern
        {
            var szPattern = $("server_excl_pattern_" + currentItemID).value;
            if(!IsValidExclusionPattern(szPattern))
            {
                valid = false;
                break;
            }
        }
        else if(exclusionType == 2) // by type
        {
            var szFileType = $("server_excl_filetype_" + currentItemID).value;
            if(!IsValidExclusionFileType(szFileType))
            {
                valid = false;
                break;
            }
        }
        else if(exclusionType == 3) // by age
        {
            var fileAge = $("server_excl_fileage_" + currentItemID).value;
            if(!IsValidFileAge(fileAge))
            {
                valid = false;
                break;
            }
        }
    }

    return valid;
}

function IsValidExclusionPattern(szPattern)
{
    var r;
    var patternlen = 0;
    var wildcharlen = 0;

    r = szPattern.indexOf("/");

	if(r == -1)
		r = szPattern.indexOf("|");

    if(r == -1)
		r = szPattern.indexOf("<");

    if(r == -1)
		r = szPattern.indexOf(">");

    //we do not allow only the wildchars (?,*) in the 'by Pattern' field. For eg: ***, ???, *?*.
    if(r == -1)
    {
         patternlen = szPattern.length;
         for(var i=0; i<patternlen; i++)
         {
            if(szPattern.charAt(i)=="*" || szPattern.charAt(i) == "?")
            wildcharlen++;
          }

         if(patternlen!=wildcharlen)
            return true;
    }
	return false;
}

function IsValidExclusionFileType(szFiletype)
{
    var r;
    var filetypelen = 0;
    var wildcharlen = 0;

    if(szFiletype == ":::")
        return true;

    r = szFiletype.indexOf("/");

	if(r == -1)
		r = szFiletype.indexOf("\"");

	if(r == -1)
		r = szFiletype.indexOf("|");

    if(r == -1)
		r = szFiletype.indexOf("<");

    if(r == -1)
		r = szFiletype.indexOf(">");

    if(r == -1)
		r = szFiletype.indexOf(":");

    if(r == -1)
		r = szFiletype.indexOf("\\");

    //we do not allow * on the vse console
    if(r == -1)
		r = szFiletype.indexOf("*");

    // we do not allow just ? in the filetype field, for eg: ???, ?? etc.
    if(r == -1)
	{
       filetypelen = szFiletype.length;
       for(var i=0; i<filetypelen; i++)
       {
          if(szFiletype.charAt(i) == "?")
           wildcharlen++;
       }
        if(filetypelen != wildcharlen)
        return true;
    }

	return false;
}

function IsValidFileAge(szFileAge)
{
    var valid = true;

    if(szFileAge == "")
        return false;

    for(var i=0; i < szFileAge.length; ++i)
    {
        if(szFileAge.charAt(i) < "0" || szFileAge.charAt(i) > "9")
        {
            valid = false;
            break;
        }
    }

    var fileAge = parseInt(szFileAge);

    if(valid)
    {
        valid = !(fileAge < 1 || fileAge > 9999);
    }

    return valid;
}

// *******************************************************************
// removeDuplicateExtensions - Sorts and removes duplicates from list
//
// Input: szExtensions - whitespace delimited list of extensions
//
// Returns: A space delimited sorted list of extensions with duplicates
// removed.
// *******************************************************************
function removeDuplicateExtensions(szExtensions)
{
    var szReturn = "";
    var szExtItems = szExtensions.split(/\s+/);
    szExtItems = szExtItems.sort();

    for(var i=0; i < szExtItems.length;)
    {
        var szCurrentItem = szExtItems[i];
        szReturn += szCurrentItem;
        ++i;
        while(i < szExtItems.length && szCurrentItem == szExtItems[i])
        {
            ++i;
        }

        if(i < szExtItems.length)
        {
            szReturn += " ";
        }
    }

    return szReturn;
}

// *******************************************************************
// removeNoExtensionMarker - Removes all ::: entries
//
// Input: szExtensions - whitespace delimited list of extensions
//
// Returns: A space delimited list of extensions with ::: removed
// *******************************************************************
function removeNoExtensionMarker(szExtensions)
{
    var szReturn = "";
    var szExtItems = szExtensions.split(/\s+/);
    szExtItems = szExtItems.sort();

    for(var i=0; i < szExtItems.length; ++i)
    {
        if(szExtItems[i] != ":::")
        {
            szReturn += szExtItems[i];
        }

        if(i < szExtItems.length - 1 && szReturn != "")
        {
            szReturn += " ";
        }
    }

    return szReturn;
}

function OASCommon_storePolicyData(policyType)
{
    bScanIncoming[policyType] = $("checkboxID_ScanIncoming").checked;
    bScanOutgoing[policyType] = $("checkboxID_ScanOutgoing").checked;
    bNetworkScanEnabled[policyType] = $("checkboxID_NetworkScanEnabled").checked;

    szIncludeExts[policyType] = $("textareaID_AdditionalFileTypes").value;
    if($("checkboxID_AdditionalNoExtension").checked)
    {
        szIncludeExts[policyType] += " :::";
    }

    szProgExts[policyType] = $("textareaID_SpecifiedFileTypes").value;
    if($("checkboxID_SpecifiedNoExtension").checked)
    {
        szProgExts[policyType] += " :::";
    }

    if($("radioID_AllFiles").checked)
    {
        LocalExtensionMode[policyType] = g_AllFiles;
    }
    else if($("radioID_DefaultAndSpecified").checked)
    {
        if($("checkboxID_ScanForMarcros").checked)
        {
            LocalExtensionMode[policyType] = g_DefaultPlus;
        }
        else
        {
            LocalExtensionMode[policyType] = g_Default;
        }
    }
    else
    {
        LocalExtensionMode[policyType] = g_Specified;
    }

    // Write exclusion data
    var exclItems = g_ExclusionListWidget.getItemList();
    g_arrListExclusionData[policyType] = new Array();
    for(i = 0; i < exclItems.length; ++i)
    {
        g_arrListExclusionData[policyType][i] = exclItems[i].itemData;                            
    }

    dwProgramHeuristicsLevel[policyType] = $("checkboxID_ProgramHeuristicsLevel").checked;
    dwMacroHeuristicsLevel[policyType] = $("checkboxID_MacroHeuristicsLevel").checked;

    ScanArchives[policyType] = $("checkboxID_ScanArchives").checked;
    ScanMime[policyType] = $("checkboxID_ScanMime").checked;
    ScanBackupReads[policyType] = $("checkboxID_ScanBackupReads").checked;
    ApplyNVP[policyType] = $("checkboxID_ApplyNVP").checked;

    uAction[policyType] = $("selectID_ThreatPrimaryAction").value;
    uSecAction[policyType] = $("selectID_ThreatSecondaryAction").value
    uAction_Program[policyType] = $("selectID_UnwantedPrimaryAction").value;
    uSecAction_Program[policyType] = $("selectID_UnwantedSecondaryAction").value;

    bAppendExclusions[policyType] = !($("checkboxID_OverwriteClient").checked);    
}

function storeRiskProcessItems(policyType)
{
    // Store RiskProcesses items data
    var RiskProcessesItems = g_RiskProcessesListWidget.getItemList();
    g_arrListRPData[policyType] = new Array();
    for(i = 0; i < RiskProcessesItems.length; ++i)
    {
        g_arrListRPData[policyType][i] = RiskProcessesItems[i].itemData;
    }
}

function OASCommon_displayPolicyData(policyType)
{
    $("checkboxID_ScanIncoming").checked = bScanIncoming[policyType];
    $("checkboxID_ScanOutgoing").checked = bScanOutgoing[policyType];
    $("checkboxID_NetworkScanEnabled").checked = bNetworkScanEnabled[policyType];

    _whattoscanTabInit();

    $("checkboxID_ProgramHeuristicsLevel").checked = dwProgramHeuristicsLevel[policyType];
    $("checkboxID_MacroHeuristicsLevel").checked = dwMacroHeuristicsLevel[policyType];

    $("checkboxID_ScanArchives").checked = ScanArchives[policyType];
    $("checkboxID_ScanMime").checked = ScanMime[policyType];
    $("checkboxID_ScanBackupReads").checked = ScanBackupReads[policyType];
    $("checkboxID_ApplyNVP").checked = ApplyNVP[policyType];

    populateExclusionsList();

    $("checkboxID_OverwriteClient").checked = !bAppendExclusions[policyType];

    SetSelectedActions();
    fnToggleApplyNVPState();
}

function displayApplicationsLists(policyType)
{
    if(policyType == 0)
    {
        $("divID_WrkstnApplicationsList").style.display = "";
        $("divID_ServerApplicationsList").style.display = "none";
    }
    else
    {
        $("divID_WrkstnApplicationsList").style.display = "none";
        $("divID_ServerApplicationsList").style.display = "";
    }
}

function OASCommon_WriteHiddenData()
{
    OASCommon_storePolicyData(g_CurrentPolicyType);

    $("hiddenID_WrkstnScanIncoming").value = bScanIncoming[0];
    $("hiddenID_WrkstnScanOutgoing").value = bScanOutgoing[0];
    $("hiddenID_WrkstnNetworkScanEnabled").value = bNetworkScanEnabled[0];
    $("hiddenID_WrkstnLocalExtensionMode").value = LocalExtensionMode[0];
    $("hiddenID_WrkstnNetworkExtensionMode").value = LocalExtensionMode[0];
    $("hiddenID_WrkstnIncludeExts").value = removeDuplicateExtensions(szIncludeExts[0]);
    $("hiddenID_WrkstnProgExts").value = removeDuplicateExtensions(szProgExts[0]);
    $("hiddenID_WrkstnProgramHeuristicsLevel").value = dwProgramHeuristicsLevel[0];
    $("hiddenID_WrkstnMacroHeuristicsLevel").value = dwMacroHeuristicsLevel[0];
    $("hiddenID_WrkstnScanArchives").value = ScanArchives[0];
    $("hiddenID_WrkstnScanMime").value = ScanMime[0];
    $("hiddenID_WrkstnScanBackupReads").value = ScanBackupReads[0];
    $("hiddenID_WrkstnScanMime").value = ScanMime[0];
    $("hiddenID_WrkstnApplyNVP").value = ApplyNVP[0];
    $("hiddenID_WrkstnOverwriteClient").value = bAppendExclusions[0];
    $("hiddenID_WrkstnThreatPrimaryAction").value = uAction[0];
    $("hiddenID_WrkstnThreatSecondaryAction").value = uSecAction[0];
    $("hiddenID_WrkstnUnwantedPrimaryAction").value = uAction_Program[0];
    $("hiddenID_WrkstnUnwantedSecondaryAction").value = uSecAction_Program[0];

    var szExclusionList = "";
    for(var i = 0; i < g_arrListExclusionData[0].length; ++i)
    {
        szExclusionList += g_arrListExclusionData[0][i].exclData;
        if((i+1) < g_arrListExclusionData[0].length)
        {
            szExclusionList += ",";
        }
    }
    
    $("hiddenID_WrkstnExclusionList").value = szExclusionList;         

    $("hiddenID_ServerScanIncoming").value = bScanIncoming[1];
    $("hiddenID_ServerScanOutgoing").value = bScanOutgoing[1];
    $("hiddenID_ServerNetworkScanEnabled").value = bNetworkScanEnabled[1];
    $("hiddenID_ServerLocalExtensionMode").value = LocalExtensionMode[1];
    $("hiddenID_ServerNetworkExtensionMode").value = LocalExtensionMode[1];
    $("hiddenID_ServerIncludeExts").value = removeDuplicateExtensions(szIncludeExts[1]);
    $("hiddenID_ServerProgExts").value = removeDuplicateExtensions(szProgExts[1]);
    $("hiddenID_ServerProgramHeuristicsLevel").value = dwProgramHeuristicsLevel[1];
    $("hiddenID_ServerMacroHeuristicsLevel").value = dwMacroHeuristicsLevel[1];
    $("hiddenID_ServerScanArchives").value = ScanArchives[1];
    $("hiddenID_ServerScanMime").value = ScanMime[1];
    $("hiddenID_ServerScanBackupReads").value = ScanBackupReads[1];
    $("hiddenID_ServerApplyNVP").value = ApplyNVP[1];
    $("hiddenID_ServerOverwriteClient").value = bAppendExclusions[1];
    $("hiddenID_ServerThreatPrimaryAction").value = uAction[1];
    $("hiddenID_ServerThreatSecondaryAction").value = uSecAction[1];
    $("hiddenID_ServerUnwantedPrimaryAction").value = uAction_Program[1];
    $("hiddenID_ServerUnwantedSecondaryAction").value = uSecAction_Program[1];

    szExclusionList = "";
    for(var i = 0; i < g_arrListExclusionData[1].length; ++i)
    {
        szExclusionList += g_arrListExclusionData[1][i].exclData;
        if((i+1) < g_arrListExclusionData[1].length)
        {
            szExclusionList += ",";
        }
    }
    $("hiddenID_ServerExclusionList").value = szExclusionList;       

}

// ************************************************************************
// ************************************************************************
// Exclusion button click event handlers
// ************************************************************************
// ************************************************************************

// ************************************************************************
// Add Exclusion button handler
// ************************************************************************
function AddExcl_onclick()
{
    g_bNewExclusion = true;

    addeditExclDialog.showDialog(true);
    addeditExclDialog.setWidth("400px");

    // remove the Access option from the Access typ dropdown for age.
    if($("selectID_AccessType").options.length > 2)
    {
        $("selectID_AccessType").options[1] = null;
    }

    // Show select element that was hidden by dialog code.
    var AccessTypeElement = $("selectID_AccessType");
    if(AccessTypeElement._visibility != null)
    {
        AccessTypeElement.style.visibility = AccessTypeElement._visibility;
        AccessTypeElement._visibility = null;
    }

    $("radioID_ExclByPattern").checked = true;
    $("textboxID_ExclPattern").value = "";
    $("checkboxID_ExclSubfolders").checked = false;
    $("textboxID_ExclFileType").value = "";
    $("textboxID_MinimumAge").value = "";
    $("checkboxID_ExclOnRead").checked = true;
    $("checkboxID_ExclOnWrite").checked = true;

    onExclTypeChange();
}

// ************************************************************************
// Edit existing exclusion button handler
// ************************************************************************
function EditExcl_onclick()
{
    g_bNewExclusion = false;

    var selectedCategoryItem = g_ExclusionListWidget.getSelected();
    if (selectedCategoryItem == null)
    {
        return;
    }

    var szExclusionItem = g_ExclusionListWidget.getSelected().itemData.exclData;
    if(szExclusionItem == "" && szExclusionItem != "||")
    {
        return;
    }
    
    addeditExclDialog.showDialog(true);
    addeditExclDialog.setWidth("400px");

    // remove the Access option from the Access typ dropdown for age.
    if($("selectID_AccessType").options.length > 2)
    {
        $("selectID_AccessType").options[1] = null;
    }

    // Show select element that was hidden by dialog code.
    var AccessTypeElement = $("selectID_AccessType");
    if(AccessTypeElement._visibility != null)
    {
        AccessTypeElement.style.visibility = AccessTypeElement._visibility;
        AccessTypeElement._visibility = null;
    }

    $("radioID_ExclByPattern").checked = false;
    $("textboxID_ExclPattern").value = "";
    $("checkboxID_ExclSubfolders").checked = false;
    $("textboxID_ExclFileType").value = "";
    $("textboxID_MinimumAge").value = "";
    $("checkboxID_ExclOnRead").checked = true;
    $("checkboxID_ExclOnWrite").checked = true;

    var exclusionSplit = szExclusionItem.split("|");
    if(exclusionSplit.length > 0)
    {
        var exclusionFlags = 0;
        if(exclusionSplit[1])
        {
            exclusionFlags = parseInt(exclusionSplit[1]);
        }

        // exclusion is by age
        if(exclusionSplit[0] >= "0" && exclusionSplit[0] <= "2")
        {
            if(exclusionSplit[1] && exclusionSplit[2])
            {
                $("radioID_ExclByFileAge").checked = true;
                if(parseInt(exclusionSplit[0]) == 0)
                {
                    $("selectID_AccessType").selectedIndex = 0;
                }
                else
                {
                    $("selectID_AccessType").selectedIndex = 1;
                }
                
                $("textboxID_MinimumAge").value = exclusionSplit[2];
            }
        }
        // By pattern
        else if(exclusionSplit[0] == "3")
        {
            $("radioID_ExclByPattern").checked = true;
            if(exclusionSplit[1] && exclusionSplit[2])
            {
                $("textboxID_ExclPattern").value = exclusionSplit[2];
                $("checkboxID_ExclSubfolders").checked = (exclusionFlags & INCLUDE_SUBFOLDERS);
            }
        }
        // By file type
        else if(exclusionSplit[0] == "4")
        {
            $("radioID_ExclByFileType").checked = true;
            if(exclusionSplit[1] && exclusionSplit[2])
            {
                if(exclusionSplit[2] == ":::")
                {
                    $("textboxID_ExclFileType").value = "";
                }
                else
                {
                    $("textboxID_ExclFileType").value = exclusionSplit[2];
                }
            }
        }
        // Windows Filexe Protection
        else if(exclusionSplit[0] == "5")
        {
            $("radioID_ExclWindowsProtection").checked = true;
        }

        $("checkboxID_ExclOnRead").checked = exclusionFlags & ON_READ;
        $("checkboxID_ExclOnWrite").checked = exclusionFlags & ON_WRITE;
    }

    onExclTypeChange();
}

// ************************************************************************
// Remove Exclusion button handler
// ************************************************************************
function RemoveExcl_onclick()
{
    g_ExclusionListWidget.removeSelected();
    g_bFormDirty = true;
}

// ************************************************************************
// Clear Exclusions button handler
// ************************************************************************
function ClearExcl_onclick()
{
    g_ExclusionListWidget.clearList();
    g_bFormDirty = true;
    validatePolicy();
}


// ************************************************************************
// ************************************************************************
// Exclusion DialogBox support code
// ************************************************************************
// ************************************************************************
function onAddEditExclOK()
{
    var exclusionFlags = 0;
    var exclusionType = 0;
    var exclusionData = "";

    if($("radioID_ExclByPattern").checked)
    {
        var strExclPattern = new String($("textboxID_ExclPattern").value);
        exclusionType = 3;
        exclusionData = strExclPattern.replace(/^\s+|\s+$/g,'');
        if($("checkboxID_ExclSubfolders").checked)
        {
            exclusionFlags += INCLUDE_SUBFOLDERS;
        }
    }
    else if($("radioID_ExclByFileType").checked)
    {
        exclusionType = 4;
        if($("textboxID_ExclFileType").value != "")
        {
            exclusionData = $("textboxID_ExclFileType").value;
        }
        else
        {
            if(!confirm($("stringID_ConfirmNoExtension").innerHTML))
            {
                return;
            }
            
            exclusionData = ":::";
        }
    }
    else if($("radioID_ExclByFileAge").checked)
    {
        exclusionType = $("selectID_AccessType").value;
        exclusionData = $("textboxID_MinimumAge").value;
    }
    else if($("radioID_ExclWindowsProtection").checked)
    {
        exclusionType = 5;
    }

    if($("checkboxID_ExclOnRead").checked)
    {
        exclusionFlags += ON_READ;
    }

    if($("checkboxID_ExclOnWrite").checked)
    {
        exclusionFlags += ON_WRITE;
    }
    addeditExclDialog.showDialog(false);

    var szExclusion = exclusionType + "|" + exclusionFlags + "|" + exclusionData;
    var ExclDataItem = new ExclusionDataItem();
    ExclDataItem.exclData = szExclusion;

    if(g_bNewExclusion)
    {
        var item = new VSE.ListItem2();
        item.itemData = ExclDataItem;
        g_ExclusionListWidget.add(item);
    }
    else
    {
        g_ExclusionListWidget.getSelected().itemData = ExclDataItem;
        g_ExclusionListWidget.selectedRowUpdate();
    }

    g_bFormDirty = true;
}

function onAddEditExclCancel()
{
    addeditExclDialog.showDialog(false);    
}

function onExclTypeChange()
{
    $("textboxID_ExclPattern").disabled = true;
    $("checkboxID_ExclSubfolders").disabled = true;
    $("textboxID_ExclFileType").disabled = true;
    $("labelID_AccessType").disabled = true;
    $("selectID_AccessType").disabled = true;
    $("labelID_MinimumAge").disabled = true;
    $("textboxID_MinimumAge").disabled = true;

    if($("radioID_ExclByPattern").checked)
    {
        $("textboxID_ExclPattern").disabled = false;
        $("checkboxID_ExclSubfolders").disabled = false;
    }
    else if($("radioID_ExclByFileType").checked)
    {
        $("textboxID_ExclFileType").disabled = false;
    }
    else if($("radioID_ExclByFileAge").checked)
    {
        $("labelID_AccessType").disabled = false;
        $("selectID_AccessType").disabled = false;
        $("labelID_MinimumAge").disabled = false;
        $("textboxID_MinimumAge").disabled = false;
    }

    validateExclusion();
}

function validateExclusion()
{
    var valid = false;

    $("exclusion_pattern_error").style.display = "none";
    $("exclusion_pattern_empty").style.display = "none";
    $("exclusion_filetype_error").style.display = "none";
    $("exclusion_fileage_error").style.display = "none";
    $("exclusion_fileage_empty").style.display = "none";
    $("exclusion_whentoexclude_empty").style.display = "none";

    if($("radioID_ExclByPattern").checked)
    {
        if($("textboxID_ExclPattern").value == "")
        {
            $("exclusion_pattern_empty").style.display = "";
        }
        else
        {
            valid = IsValidExclusionPattern($("textboxID_ExclPattern").value);
            if(!valid)
            {
                $("exclusion_pattern_error").style.display = "";
            }
        }
    }
    else if($("radioID_ExclByFileType").checked)
    {
        if($("textboxID_ExclFileType").value != "")
        {
            valid = IsValidExclusionFileType($("textboxID_ExclFileType").value);
            if(!valid)
            {
                $("exclusion_filetype_error").style.display = "";
            }
        }
        else
        {
            valid = true;
        }
    }
    else if($("radioID_ExclByFileAge").checked)
    {
        if($("textboxID_MinimumAge").value == "")
        {
            $("exclusion_fileage_empty").style.display = "";
        }
        else
        {
            valid = IsValidFileAge($("textboxID_MinimumAge").value);
            if(!valid)
            {
                $("exclusion_fileage_error").style.display = "";
            }
        }
    }
    else if($("radioID_ExclWindowsProtection").checked)
    {
        valid = true;
    }

    if(!($("checkboxID_ExclOnRead").checked) && !($("checkboxID_ExclOnWrite").checked))
    {
        valid = false;
        $("exclusion_whentoexclude_empty").style.display = "";
    }

    $("buttonID_ruleTypeSelectOK").disabled = !valid;            
}

function requireSpecifiedFileTypes(require)
{
    OrionForm.setFieldRequired("textareaID_SpecifiedFileTypes", require);
}

function RiskProcesses_AddCallback(newRow)
{
    if(newRow != null)
    {
        var itemID = newRow.id.replace("divID_RiskProcessesList_lwrow_", "");
        var rpProcessnameElement = $("rp__riskprocesses_processname_" + itemID);
        var hiddenValue = "";

        var ruleItem = g_RiskProcessesListWidget.getItem(newRow.id);
        if(ruleItem != null)
        {
            hiddenValue = ruleItem.itemData.rpData;
        }

       rpProcessnameElement.innerHTML = hiddenValue;

        validatePolicy();
    }
}

function OASCommon_RiskProcessesUpdateRowDataCallback(selectedRow)
{
    // Update RiskProcess data with data stored in Widget
    var RPItems = g_RiskProcessesListWidget.getItemList();
    g_arrListRPData[g_CurrentPolicyType] = new Array();
    for(i = 0; i < RPItems.length; ++i)
    {
        g_arrListRPData[g_CurrentPolicyType][i] = RPItems[i].itemData;
    }
}

function RiskProcessesRemoveCallback()
{
    validatePolicy();
}

// ************************************************************************
// ************************************************************************
// Add/Edit RP DialogBox support code
// ************************************************************************
// ************************************************************************
function onAddEditRPOK()
{
    addeditRPDialog.showDialog(false);

    var szRPItem = $("textboxID_risk_processname").value;
    var rpDataItem = new RPDataItem();
    rpDataItem.rpData = szRPItem;

    if(g_bNewRPItem)
    {
        var item = new VSE.ListItem2();
        item.itemData = rpDataItem;
        g_RiskProcessesListWidget.add(item);
    }
    else
    {
        g_RiskProcessesListWidget.getSelected().itemData = rpDataItem;
        g_RiskProcessesListWidget.selectedRowUpdate();
    }

    g_bFormDirty = true;
}

function onAddEditRPCancel()
{
    addeditRPDialog.showDialog(false);
}

function AddRPItem_onclick()
{
    g_bNewRPItem = true;
    addeditRPDialog.showDialog(true);
    addeditRPDialog.setWidth("400px");

    $("textboxID_risk_processname").value = "";

    validateProcessItem();
}

function EditRPItem_onclick()
{
    g_bNewRPItem = false;

    var selectedItem = g_RiskProcessesListWidget.getSelected();
    if( selectedItem == null)
    {
        return;
    }

    var szRPItem = selectedItem.itemData.rpData;
    if(szRPItem == "")
    {
        return;
    }

    addeditRPDialog.showDialog(true);
    addeditRPDialog.setWidth("400px");

    $("textboxID_risk_processname").value = "";
    $("textboxID_risk_processname").value = szRPItem;

    validateProcessItem();
}

function RemoveRPItem_onclick()
{
    g_RiskProcessesListWidget.removeSelected();
    g_bFormDirty = true;
    validatePolicy();
}

function ClearRPItem_onclick()
{
    g_RiskProcessesListWidget.clearList();
    g_bFormDirty = true;
    validatePolicy();
}

function validateProcessItem()
{
    var valid = true;
    $("RP_processname_empty").style.display = "none";
    $("RP_processname_error").style.display = "none";

    if($("textboxID_risk_processname").value == "")
    {
        $("RP_processname_empty").style.display = "";
        valid = false;
    }
    else
    {
        valid = validateProcessname($("textboxID_risk_processname").value);
        if(!valid)
        {
            $("RP_processname_error").style.display = "";
        }
    }

    $("buttonID_addEditRPItemOK").disabled = !valid;
}


function validateProcessname(szItem)
{
    var r;

	r = szItem.indexOf("/");

	if(r == -1)
		r = szItem.indexOf("\\");

    if(r == -1)
		r = szItem.indexOf("\*");

	if(r == -1)
		r = szItem.indexOf("?");

	if(r == -1)
		r = szItem.indexOf("\"");

	if(r == -1)
		r = szItem.indexOf("|");

    if(r == -1)
		r = szItem.indexOf("<");

    if(r == -1)
		r = szItem.indexOf(">");

    if(r == -1)
		r = szItem.indexOf(":");

    if(r == -1)
		return true;

	return false;
}