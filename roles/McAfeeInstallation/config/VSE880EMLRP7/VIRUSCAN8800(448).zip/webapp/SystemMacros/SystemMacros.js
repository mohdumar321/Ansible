var ie	= document.all
var ns6	= document.getElementById&&!document.all

// Used for macro validation, these strings should NOT be localized!
var g_szValidMacros = new Array();
g_szValidMacros[0]	= "SYSTEM_DRIVE";
g_szValidMacros[1]	= "SYSTEM_ROOT";
g_szValidMacros[2]	= "SYSTEM_DIR";
g_szValidMacros[3]	= "TEMP_DIR";
g_szValidMacros[4]	= "PROGRAM_FILES_DIR";
g_szValidMacros[5]	= "PROGRAM_FILES_COMMON_DIR";
g_szValidMacros[6]	= "SOFTWARE_INSTALLED_DIR";
g_szValidMacros[7]	= "COMPUTER_NAME";
g_szValidMacros[8]	= "USER_NAME";
g_szValidMacros[9]	= "DOMAIN_NAME";

var g_szValidMacroValues = new Array();
g_szValidMacroValues[0]	= "<SYSTEM_DRIVE>\\";
g_szValidMacroValues[1]	= "<SYSTEM_ROOT>\\";
g_szValidMacroValues[2]	= "<SYSTEM_DIR>\\";
g_szValidMacroValues[3]	= "<TEMP_DIR>\\";
g_szValidMacroValues[4]	= "<PROGRAM_FILES_DIR>\\";
g_szValidMacroValues[5]	= "<PROGRAM_FILES_COMMON_DIR>\\";
g_szValidMacroValues[6]	= "<SOFTWARE_INSTALLED_DIR>\\";
g_szValidMacroValues[7]	= "<COMPUTER_NAME>";
g_szValidMacroValues[8]	= "<USER_NAME>";
g_szValidMacroValues[9]	= "<DOMAIN_NAME>";

var menuElement;
var g_szIDforMacro;
var g_validateFunction;
var isMenu 	= false ;

var menuSelObj = null ;
var overpopupmenu = false;

function mouseSelect(e)
{
    var obj = ns6 ? e.target.parentNode : event.srcElement.parentElement;

    if( isMenu )
    {
        if( overpopupmenu == false )
        {
            isMenu = false ;
            overpopupmenu = false;
            $('MacroMenu').style.display = "none" ;
            restoreSelectInputs();
        }
        else
        {
            clickMenu(e);
            isMenu = false ;
            overpopupmenu = false;
            $('MacroMenu').style.display = "none" ;
            restoreSelectInputs();
            if(g_validateFunction != null)
            {
                g_validateFunction();
            }
        }
    }
    return false;
}

function showMacroMenu(e, targetTextbox, validateFunction)
{
    var	obj = ns6 ? e.target.parentNode : event.srcElement.parentElement;
    var macroButton = ns6 ? e.target : event.srcElement;
    document.onmousedown = mouseSelect;

    menuSelObj = obj ;

    if(targetTextbox == null || targetTextbox.disabled)
    {
        return;
    }

    macroButton.parentNode.insertBefore($('MacroMenu'), macroButton);
    g_validateFunction = validateFunction;
    g_szIDforMacro = targetTextbox;
    $('MacroMenu').style.display = "";
    hideSelectInputs();

    isMenu = true;
    return false ;
}

function clickMenu(e)
{
    var el = ns6 ? e.target : event.srcElement;

    var iMacroIndex = -1;
	var bPreviousMacroHadSlash = false;

	// figure out which macro has been chosen.
	for(var i = 0; i < g_szValidMacros.length; i++)
	{
		if (el.id == g_szValidMacros[i])
        {
            iMacroIndex = i;
        }
    }

	if(iMacroIndex != -1)
	{
		var szStartValue = g_szIDforMacro.value;

		// Erase any macros already at the start of the string.
		for(var i = 0; i < g_szValidMacroValues.length; i++)
		{
			if(szStartValue.indexOf(g_szValidMacroValues[i]) == 0)
			{
				// Find out if the macro being replaced had a slash at the end.
				if(g_szValidMacroValues[i].charAt( g_szValidMacroValues[i].length - 1 ) == "\\")
                {
                    bPreviousMacroHadSlash = true;
                }
                else
                {
                    bPreviousMacroHadSlash = false;
                }

                szStartValue = szStartValue.replace( g_szValidMacroValues[i], "");
			}
		}

		// if there is already a slash at the start of the string, remove it so another one isn't added.
		if((g_szValidMacroValues[iMacroIndex].charAt(g_szValidMacroValues[iMacroIndex].length - 1) == "\\") &&
		   (szStartValue.charAt(0) == "\\") && (szStartValue.length > 0))
		{
			szStartValue = szStartValue.substring(1, szStartValue.length);
		}

		// If the previous macro had a slash at the end, and the new macro doesn't, the slash needs to stay there, so re-add it.
		if(bPreviousMacroHadSlash && (g_szValidMacroValues[iMacroIndex].charAt( g_szValidMacroValues[iMacroIndex].length - 1 ) != "\\"))
		{
			szStartValue = "\\" + szStartValue;
		}

		szStartValue = g_szValidMacroValues[iMacroIndex] + szStartValue;

		g_szIDforMacro.value = szStartValue;
	}

	if(!g_szIDforMacro.disabled)
    {
        g_szIDforMacro.focus();
    }
}

function hideSelectInputs()
{
    var util = new BrowserUtil();
    if(!util.isIE())
        return;

    var selects = $("orionRootContentID").getElementsByTagName("SELECT");
    for(var i = 0; i < selects.length; i++)
    {
        selects[i]._visibility = selects[i].style.visibility;
        selects[i].style.visibility = "hidden";
    }
}

function restoreSelectInputs()
{
    var util = new BrowserUtil();
    if(!util.isIE())
        return;

    var selects = $("orionRootContentID").getElementsByTagName("SELECT");
    for(var i = 0; i < selects.length; i++)
    {
        if(selects[i]._visibility != null)
        {
            selects[i].style.visibility = selects[i]._visibility;
            selects[i]._visibility = null;
        }
    }
}
