var szQuarantineDir = new Array();
var nQuarantineAge = new Array();

function epoApplyPolicySettings()
{
    writeHiddenData();
    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveQuarantinePolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function writeHiddenData()
{
    storePolicyData(g_CurrentPolicyType);
    $("hiddenID_WrkstnQuarantineDirectory").value = szQuarantineDir[WRKSTN_POLICY];
    $("hiddenID_ServerQuarantineDirectory").value = szQuarantineDir[SERVER_POLICY];
    $("hiddenID_WrkstnQuarantineAge").value = nQuarantineAge[WRKSTN_POLICY];
    $("hiddenID_ServerQuarantineAge").value = nQuarantineAge[SERVER_POLICY];
}

function setQuarantineAge()
{
    var szElementID = "hiddenID_WrkstnQuarantineAge";
    var nAge = 0;

    if(g_CurrentPolicyType == SERVER_POLICY)
    {
        szElementID = "hiddenID_ServerQuarantineAge";
    }

    if(!($("checkboxID_AutoDeleteData").checked))
    {
        $(szElementID).value = 0;
    }
    else
    {
        $(szElementID).value = $("numberboxID_QuarantineAge").value;
        nAge = $(szElementID).value;
    }

    return nAge;
}

function UpdateQuarantineDir(szQuarantineDir)
{
    var szNewQuarantineDir = szQuarantineDir;
    var slashIndex = szQuarantineDir.indexOf("\\");

    if(slashIndex != -1)
    {
        var szDrive = szQuarantineDir.substring(0, slashIndex);
        if(szDrive.length > 1 &&
           szDrive.charAt(1) == ":" &&
           ((szDrive.charAt(0) >= 'a' && szDrive.charAt(0) <= 'z') || (szDrive.charAt(0) >= 'A' && szDrive.charAt(0) <= 'Z')))
        {
            szNewQuarantineDir = szQuarantineDir;
        }
        else if(szDrive.length > 1 && szDrive.charAt(0) == "<" && szDrive.charAt(szDrive.length-1) == ">")
        {
            szNewQuarantineDir = szQuarantineDir;
        }
        else if (szDrive.charAt(0) == ":")
        {
            szNewQuarantineDir = "<SYSTEM_DRIVE>\\" + szQuarantineDir.substring(slashIndex+1, szQuarantineDir.length);                        
        }
        else if (slashIndex == 0)
        {
            szNewQuarantineDir = "<SYSTEM_DRIVE>" + szQuarantineDir;            
        }
        else
        {
            szNewQuarantineDir = "<SYSTEM_DRIVE>\\" + szQuarantineDir;            
        }
    }
    else
    {
        szNewQuarantineDir = "<SYSTEM_DRIVE>\\" + szQuarantineDir;
    }

    return szNewQuarantineDir;
}

function storePolicyData(policyType)
{
    szQuarantineDir[policyType] = $("textboxID_QuarantineDirectory").value;
    szQuarantineDir[policyType] = UpdateQuarantineDir(szQuarantineDir[policyType]);
    nQuarantineAge[policyType] = setQuarantineAge();
}

function validateQuarantineAge(szQuarantineAge)
{
    var valid = true;

    if(!($("checkboxID_AutoDeleteData").checked))
    {
        return true;
    }

    if(szQuarantineAge < 1 || szQuarantineAge > 999)
    {
        valid = false;
    }

    return valid;
}

function displayPolicyData(policyType)
{
    $("textboxID_QuarantineDirectory").value = szQuarantineDir[policyType];
    $("numberboxID_QuarantineAge").value = nQuarantineAge[policyType];
    $("checkboxID_AutoDeleteData").checked = (nQuarantineAge[policyType] > 0);
    autoDelete_onClick($("checkboxID_AutoDeleteData").checked);
    _doReadonly();
}
