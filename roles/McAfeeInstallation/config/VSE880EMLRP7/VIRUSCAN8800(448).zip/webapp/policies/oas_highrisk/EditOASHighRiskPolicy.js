function epoApplyPolicySettings()
{
    writeHiddenData();

    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveOASHighRiskPolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
}

function storePolicyData(policyType)
{
    OASCommon_storePolicyData(policyType);
    storeRiskProcessItems(policyType)
}

function displayPolicyData(policyType)
{
    OASCommon_displayPolicyData(policyType);
    populateHighRiskProcessesList();    
    _doReadonly();
}

function writeHiddenData()
{
    OASCommon_WriteHiddenData();
    Wrkstn_UpdateAppIDList();
    Server_UpdateAppIDList();
}

function highRiskProcessesUpdateRowDataCallback(selectedRow)
{
    OASCommon_RiskProcessesUpdateRowDataCallback(selectedRow);
    populateHighRiskProcessesList();
}