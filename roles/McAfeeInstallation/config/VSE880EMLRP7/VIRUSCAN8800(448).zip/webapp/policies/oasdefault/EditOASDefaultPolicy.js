// Variables for Workstation/Server toggle
var OnlyUseDefaultConfig = new Array();

function epoApplyPolicySettings()
{
    writeHiddenData();

    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveOASDefaultPolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
};

function storePolicyData(policyType)
{
    OnlyUseDefaultConfig[policyType] = $("radioID_UseDefaultConfig").checked;
    OASCommon_storePolicyData(policyType);
}

function displayPolicyData(policyType)
{
    _processesTabInit();
    OASCommon_displayPolicyData(policyType);
    _doReadonly();
}

function writeHiddenData()
{
    storePolicyData(g_CurrentPolicyType);
    $("hiddenID_WrkstnUseDefaultConfig").value = OnlyUseDefaultConfig[0];
    $("hiddenID_ServerUseDefaultConfig").value = OnlyUseDefaultConfig[1];
    OASCommon_WriteHiddenData();
}
