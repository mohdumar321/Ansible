// global variables
var g_APCategoryListWidget;
var g_APRuleListWidget;
var g_selectedRuleType = RULE_TYPE_UNKNOWN;
var g_isNew = false;
var g_readOnly = false;

// Access Protection Data
var bAPEnabled = new Array();
var bLockdownEnabled = new Array();

var g_editedBOFRules = new Array();
g_editedBOFRules[0] = new Array();
g_editedBOFRules[1] = new Array();

var g_deletedUserRules = new Array();
g_deletedUserRules[0] = new Array();
g_deletedUserRules[1] = new Array();

var g_arrListRuleData = new Array();
g_arrListRuleData[0] = {};
g_arrListRuleData[1] = {};

// Reports Data
var bLogToFile = new Array();
var szLogFileName = new Array();
var bLimitSize = new Array();
var dwMaxLogSizeMB = new Array();
var logFileFormat = new Array();



// constants
var MCFILTER_NAMERULEFLAG_DENYCREATE		= 65536;	// 0x00010000
var MCFILTER_NAMERULEFLAG_DENYREAD			= 131072;	// 0x00020000
var MCFILTER_NAMERULEFLAG_DENYWRITE			= 262144;	// 0x00040000
var MCFILTER_NAMERULEFLAG_DENYEXECUTE		= 524288;	// 0x00080000
var MCFILTER_NAMERULEFLAG_DENYDELETE		= 1048576;  // 0x00100000

var LEAVE_ALONE					= 0;
var MAKE_READ_ONLY				= 1;
var HIDE_TOTALLY				= 2;

var PROTECT_MODE_NO_LOGGING		= 0;
var PROTECT_MODE_LOGGING		= 1;
var PROTECT_MODE_WARNING		= 2;

var FORMAT_VALUE_ANSI			= 0;
var FORMAT_VALUE_UTF8			= 1;
var FORMAT_VALUE_UTF16			= 2;

var RULE_TYPE_UNKNOWN           = -1;
var RULE_TYPE_PORT              = 0;
var RULE_TYPE_FILE              = 1;
var RULE_TYPE_REGISTRY          = 2;
var RULE_TYPE_PREDEFINED        = 100;

var NEW_RULE_ID                 = "NEWRULE";

function epoApplyPolicySettings()
{
    writeHiddenData();
    OrionCore.doAsyncFormAction("/VIRUSCAN8800/SaveAccessProtectionPolicy.do", null, fnApplyPolicySuccess, fnApplyPolicyFailure);
    return false;
};

function fnApplyPolicySuccess()
{
    fnGoBack();
};

function fnApplyPolicyFailure()
{
    alert("Unable to save policy");
    return false;
};

function writeHiddenData()
{
    storePolicyData(g_CurrentPolicyType);
    writeHiddenWrkstnRuleData();
    writeHiddenServerRuleData();

    $("hiddenID_WrkstnAPEnabled").value = bAPEnabled[0];
    $("hiddenID_WrkstnLockdownEnabled").value = bLockdownEnabled[0];
    $("hiddenID_WrkstnLogToFile").value = bLogToFile[0];
    $("hiddenID_WrkstnLogFileName").value = szLogFileName[0];
    $("hiddenID_WrkstnLimitLogSize").value = bLimitSize[0];
    $("hiddenID_WrkstnMaxLogSize").value = dwMaxLogSizeMB[0];
    $("hiddenID_WrkstnLogFileFormat").value = logFileFormat[0];

    $("hiddenID_ServerAPEnabled").value = bAPEnabled[1];
    $("hiddenID_ServerLockdownEnabled").value = bLockdownEnabled[1];
    $("hiddenID_ServerLogToFile").value = bLogToFile[1];
    $("hiddenID_ServerLogFileName").value = szLogFileName[1];
    $("hiddenID_ServerLimitLogSize").value = bLimitSize[1];
    $("hiddenID_ServerMaxLogSize").value = dwMaxLogSizeMB[1];
    $("hiddenID_ServerLogFileFormat").value = logFileFormat[1];
}

function writeHiddenWrkstnRuleData()
{
    // BOF Rules
    var editedBOFRules_Name = "";
    var editedBOFRules_ID = "";
    var editedBOFRules_ProcIncludes = "";
    var editedBOFRules_ProcExcludes = "";
    var editedBOFRules_Enforce = "";
    var editedBOFRules_Report = "";

    // User Rules
    var userRules_Name = "";
    var userRules_ID = "";
    var userRules_ProcIncludes = "";
    var userRules_ProcExcludes = "";
    var userRules_Definition = "";
    var userRules_Enforce = "";
    var userRules_Report = "";
    var deletedUserRules_ID = "";

    for(var i=0; i < g_editedBOFRules[0].length; ++i)
    {
        editedBOFRules_Name += g_editedBOFRules[0][i].ruleName;
        editedBOFRules_ID += g_editedBOFRules[0][i].ruleID;
        editedBOFRules_ProcIncludes += g_editedBOFRules[0][i].ruleProcIncludes;
        if(g_editedBOFRules[0][i].ruleProcExcludes != "")
        {
            editedBOFRules_ProcExcludes += g_editedBOFRules[0][i].ruleProcExcludes;
        }
        else
        {
            editedBOFRules_ProcExcludes += " ";            
        }
        editedBOFRules_Enforce += g_editedBOFRules[0][i].ruleEnforce;
        editedBOFRules_Report += g_editedBOFRules[0][i].ruleReport;

        if(i < (g_editedBOFRules[0].length-1))
        {
            editedBOFRules_Name += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_ID += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_ProcIncludes += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_ProcExcludes += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_Enforce += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_Report += Constants.LIST_TOKEN_SPLITTER;
        }
    }

    if(g_arrListRuleData[0]["G_User"] != null)
    {
        for(var i = 0; i < g_arrListRuleData[0]["G_User"].length; ++i)
        {
            // an empty rule is getting into the rule list for some reason
            if(g_arrListRuleData[0]["G_User"][i].ruleID == "")
            {
                continue;
            }

            userRules_Name += g_arrListRuleData[0]["G_User"][i].ruleName;
            userRules_ID += g_arrListRuleData[0]["G_User"][i].ruleID;
            userRules_ProcIncludes += g_arrListRuleData[0]["G_User"][i].ruleProcIncludes;

            if(g_arrListRuleData[0]["G_User"][i].ruleProcExcludes == "")
            {
                userRules_ProcExcludes += " ";
            }
            else
            {
                userRules_ProcExcludes += g_arrListRuleData[0]["G_User"][i].ruleProcExcludes;
            }

            userRules_Enforce += g_arrListRuleData[0]["G_User"][i].ruleEnforce;
            userRules_Report += g_arrListRuleData[0]["G_User"][i].ruleReport;
            userRules_Definition += g_arrListRuleData[0]["G_User"][i].ruleDefinition;

            if(i < (g_arrListRuleData[0]["G_User"].length-1))
            {
                userRules_Name += Constants.LIST_TOKEN_SPLITTER;
                userRules_ID += Constants.LIST_TOKEN_SPLITTER;
                userRules_ProcIncludes += Constants.LIST_TOKEN_SPLITTER;
                userRules_ProcExcludes += Constants.LIST_TOKEN_SPLITTER;
                userRules_Enforce += Constants.LIST_TOKEN_SPLITTER;
                userRules_Report += Constants.LIST_TOKEN_SPLITTER;
                userRules_Definition += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }

    for(var i=0; i < g_deletedUserRules[0].length; ++i)
    {
        deletedUserRules_ID += g_deletedUserRules[0][i].ruleID;

        if(i < (g_deletedUserRules[0].length-1))
        {
            deletedUserRules_ID += Constants.LIST_TOKEN_SPLITTER;
        }
    }

    $("hiddenID_Wrkstn_BOFRules_ruleName").value = editedBOFRules_Name;
    $("hiddenID_Wrkstn_BOFRules_ruleID").value = editedBOFRules_ID;
    $("hiddenID_Wrkstn_BOFRules_ruleProcIncludes").value = editedBOFRules_ProcIncludes;
    $("hiddenID_Wrkstn_BOFRules_ruleProcExcludes").value = editedBOFRules_ProcExcludes;
    $("hiddenID_Wrkstn_BOFRules_ruleEnforce").value = editedBOFRules_Enforce;
    $("hiddenID_Wrkstn_BOFRules_ruleReport").value = editedBOFRules_Report;

    $("hiddenID_Wrkstn_userRules_ruleName").value = userRules_Name;
    $("hiddenID_Wrkstn_userRules_ruleID").value = userRules_ID;
    $("hiddenID_Wrkstn_userRules_ruleProcIncludes").value = userRules_ProcIncludes;
    $("hiddenID_Wrkstn_userRules_ruleProcExcludes").value = userRules_ProcExcludes;
    $("hiddenID_Wrkstn_userRules_ruleEnforce").value = userRules_Enforce;
    $("hiddenID_Wrkstn_userRules_ruleReport").value = userRules_Report;
    $("hiddenID_Wrkstn_userRules_ruleDefinition").value = userRules_Definition;

    $("hiddenID_Wrkstn_deletedUserRules").value = deletedUserRules_ID;
}

function writeHiddenServerRuleData()
{
    // BOF Rules
    var editedBOFRules_Name = "";
    var editedBOFRules_ID = "";
    var editedBOFRules_ProcIncludes = "";
    var editedBOFRules_ProcExcludes = "";
    var editedBOFRules_Enforce = "";
    var editedBOFRules_Report = "";

    // User Rules
    var userRules_Name = "";
    var userRules_ID = "";
    var userRules_ProcIncludes = "";
    var userRules_ProcExcludes = "";
    var userRules_Definition = "";
    var userRules_Enforce = "";
    var userRules_Report = "";
    var deletedUserRules_ID = "";

    for(var i=0; i < g_editedBOFRules[1].length; ++i)
    {
        editedBOFRules_Name += g_editedBOFRules[1][i].ruleName;
        editedBOFRules_ID += g_editedBOFRules[1][i].ruleID;
        editedBOFRules_ProcIncludes += g_editedBOFRules[1][i].ruleProcIncludes;
         if(g_editedBOFRules[1][i].ruleProcExcludes != "")
        {
            editedBOFRules_ProcExcludes += g_editedBOFRules[1][i].ruleProcExcludes;
        }
        else
        {
            editedBOFRules_ProcExcludes += " ";
        }
        editedBOFRules_Enforce += g_editedBOFRules[1][i].ruleEnforce;
        editedBOFRules_Report += g_editedBOFRules[1][i].ruleReport;

        if(i < (g_editedBOFRules[1].length-1))
        {
            editedBOFRules_Name += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_ID += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_ProcIncludes += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_ProcExcludes += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_Enforce += Constants.LIST_TOKEN_SPLITTER;
            editedBOFRules_Report += Constants.LIST_TOKEN_SPLITTER;
        }
    }

    if(g_arrListRuleData[1]["G_User"] != null)
    {
        for(var i = 0; i < g_arrListRuleData[1]["G_User"].length; ++i)
        {
            // an empty rule is getting into the rule list for some reason
            if(g_arrListRuleData[1]["G_User"][i].ruleID == "")
            {
                continue;
            }

            userRules_Name += g_arrListRuleData[1]["G_User"][i].ruleName;
            userRules_ID += g_arrListRuleData[1]["G_User"][i].ruleID;
            userRules_ProcIncludes += g_arrListRuleData[1]["G_User"][i].ruleProcIncludes;

            if(g_arrListRuleData[1]["G_User"][i].ruleProcExcludes == "")
            {
                userRules_ProcExcludes += " ";
            }
            else
            {
                userRules_ProcExcludes += g_arrListRuleData[1]["G_User"][i].ruleProcExcludes;
            }

            userRules_Enforce += g_arrListRuleData[1]["G_User"][i].ruleEnforce;
            userRules_Report += g_arrListRuleData[1]["G_User"][i].ruleReport;
            userRules_Definition += g_arrListRuleData[1]["G_User"][i].ruleDefinition;

            if(i < (g_arrListRuleData[1]["G_User"].length-1))
            {
                userRules_Name += Constants.LIST_TOKEN_SPLITTER;
                userRules_ID += Constants.LIST_TOKEN_SPLITTER;
                userRules_ProcIncludes += Constants.LIST_TOKEN_SPLITTER;
                userRules_ProcExcludes += Constants.LIST_TOKEN_SPLITTER;
                userRules_Enforce += Constants.LIST_TOKEN_SPLITTER;
                userRules_Report += Constants.LIST_TOKEN_SPLITTER;
                userRules_Definition += Constants.LIST_TOKEN_SPLITTER;
            }
        }
    }

    for(var i=0; i < g_deletedUserRules[1].length; ++i)
    {
        deletedUserRules_ID += g_deletedUserRules[1][i].ruleID;

        if(i < (g_deletedUserRules[1].length-1))
        {
            deletedUserRules_ID += Constants.LIST_TOKEN_SPLITTER;
        }
    }

    $("hiddenID_Server_BOFRules_ruleName").value = editedBOFRules_Name;
    $("hiddenID_Server_BOFRules_ruleID").value = editedBOFRules_ID;
    $("hiddenID_Server_BOFRules_ruleProcIncludes").value = editedBOFRules_ProcIncludes;
    $("hiddenID_Server_BOFRules_ruleProcExcludes").value = editedBOFRules_ProcExcludes;
    $("hiddenID_Server_BOFRules_ruleEnforce").value = editedBOFRules_Enforce;
    $("hiddenID_Server_BOFRules_ruleReport").value = editedBOFRules_Report;

    $("hiddenID_Server_userRules_ruleName").value = userRules_Name;
    $("hiddenID_Server_userRules_ruleID").value = userRules_ID;
    $("hiddenID_Server_userRules_ruleProcIncludes").value = userRules_ProcIncludes;
    $("hiddenID_Server_userRules_ruleProcExcludes").value = userRules_ProcExcludes;
    $("hiddenID_Server_userRules_ruleEnforce").value = userRules_Enforce;
    $("hiddenID_Server_userRules_ruleReport").value = userRules_Report;
    $("hiddenID_Server_userRules_ruleDefinition").value = userRules_Definition;

    $("hiddenID_Server_deletedUserRules").value = deletedUserRules_ID;
}

APCategoryData = function(obj)
{
    var categoryName = "";
    var categoryID = "";
}

APRuleData = function(obj)
{
    var ruleName = "";
    var ruleID = "";
    var ruleEnforce = false;
    var ruleReport = false;
    var ruleProcIncludes = "";
    var ruleProcExcludes = "";
    var ruleDefinition = "";
}

function displayUserCategoryRuleData(selectedRuleItem)
{
    if(selectedRuleItem != null)
    {
        g_selectedRuleType = fnGetRuleType(selectedRuleItem.itemData.ruleDefinition);
    }

    if(g_selectedRuleType == RULE_TYPE_PORT)
    {
        $("divID_PortRuleData").style.display = "";
        fnPopulatePortRuleValues(selectedRuleItem);
    }
    else if(g_selectedRuleType == RULE_TYPE_FILE)
    {
        $("divID_FileRuleData").style.display = "";
        fnPopulateFileRuleValues(selectedRuleItem);
    }
    else if(g_selectedRuleType == RULE_TYPE_REGISTRY)
    {
        $("divID_RegistryRuleData").style.display = "";
        fnPopulateRegRuleValues(selectedRuleItem);
    }
}

function fnPopulatePortRuleValues(selectedRuleItem)
{
    $("checkboxID_Inbound").checked = false;
    $("checkboxID_Outbound").checked = false;
    $("ID_StartPort").value = "";
    $("ID_EndPort").value = "";

    if (selectedRuleItem != null)
    {
        // Parse the rule definition to populate fields
        var szRuleDefinition = selectedRuleItem.itemData.ruleDefinition;
        var szSubStr;
        var szTokens;
        var i;

        i = szRuleDefinition.search(/Port\s[IO]+UT/);
        if(i == -1)
            return;

        szSubStr = szRuleDefinition.substr(i);
        szTokens = szSubStr.split(/\s/);

        if(-1 == szTokens[1].search(/[IO]+UT/))
            return;

        if(-1 != szTokens[1].search(/I/))
            $("checkboxID_Inbound").checked = true;
        if(-1 != szTokens[1].search(/O/))
            $("checkboxID_Outbound").checked = true;

        $("ID_StartPort").value = szTokens[4];

        if(szTokens[5].charAt(0) >= 0 && szTokens[5].charAt(0) <= 9)
        {
            $("ID_EndPort").value = szTokens[5];
        }            
    }
    validatePortRule();
}

function fnPopulateFileRuleValues(selectedRuleItem)
{
    $("checkboxID_ReadAccess").checked = false;
    $("checkboxID_WriteAccess").checked = false;
    $("checkboxID_ExecuteAccess").checked = false;
    $("checkboxID_CreateAccess").checked = false;
    $("checkboxID_DeleteAccess").checked = false;
    $("textboxID_FileOrFolderName").value = "";

    if (selectedRuleItem != null)
    {
        // Parse the rule definition to populate fields
        var szRuleDefinition = selectedRuleItem.itemData.ruleDefinition;
        var szSubStr;
        var szTokens;
        var szWildcard = "";
        var i;

        i = szRuleDefinition.search(/File\s[RWXCD]/);
        if(i == -1)
            return;

        szSubStr = szRuleDefinition.substr(i);
        szTokens = szSubStr.split(/\s/);

        if(-1 != szTokens[1].search(/R/))
            $("checkboxID_ReadAccess").checked = true;
        if(-1 != szTokens[1].search(/W/))
            $("checkboxID_WriteAccess").checked = true;
        if(-1 != szTokens[1].search(/X/))
            $("checkboxID_ExecuteAccess").checked = true;
        if(-1 != szTokens[1].search(/C/))
            $("checkboxID_CreateAccess").checked = true;
        if(-1 != szTokens[1].search(/D/))
            $("checkboxID_DeleteAccess").checked = true;

        szWildcard = szTokens[4];
        if(szTokens[5] != "}")
        {
            i = 5;
            while((i < szTokens.length) && szTokens[i] != "}")
            {
                szWildcard += " ";
                szWildcard += szTokens[i];
                ++i;
            }
        }

        $("textboxID_FileOrFolderName").value = RemoveTclFormat(szWildcard);
    }
    validateFileRule();

}

function fnPopulateRegRuleValues(selectedRuleItem)
{
    $("checkboxID_RegWriteAccess").checked = false;
    $("checkboxID_RegCreateAccess").checked = false;
    $("checkboxID_RegDeleteAccess").checked = false;
    $("radioID_KeyType").checked = true;
    $("selectID_RegRoot").selectedIndex = 0;
    $("textboxID_RegKeyValueToBlock").value = "";
    
    if (selectedRuleItem != null)
    {
        // Parse the rule definition to populate fields
        var szRuleDefinition = selectedRuleItem.itemData.ruleDefinition;
        var szSubStr;
        var szTokens;
        var i;
        var szRegistryPath;

        i = szRuleDefinition.search(/Key\s[RWCD]/);
        if(i == -1)
        {
            i = szRuleDefinition.search(/Value\s[RWCD]/);

            if(i == -1)
                return;
            else
                $("radioID_ValueType").checked = true;
        }
        else
        {
            $("radioID_KeyType").checked = true;
        }

        szSubStr = szRuleDefinition.substr(i);
        szTokens = szSubStr.split(/\s/);

        if(-1 != szTokens[1].search(/W/))
            $("checkboxID_RegWriteAccess").checked = true;
        if(-1 != szTokens[1].search(/C/))
            $("checkboxID_RegCreateAccess").checked = true;
        if(-1 != szTokens[1].search(/D/))
            $("checkboxID_RegDeleteAccess").checked = true;

        szRegistryPath = szSubStr.substr(szSubStr.indexOf("{Include ")+9);
        szRegistryPath = szRegistryPath.substr(0,szRegistryPath.lastIndexOf("}"));

        // parse out the registry root
        var szRegPathUnformatted = RemoveTclFormat(szRegistryPath);
        var szRegRuleTokens = szRegPathUnformatted.split("/");
        if(szRegRuleTokens[0] == "HKLM" || szRegRuleTokens[0] == "HKCU" ||
           szRegRuleTokens[0] == "HKCR" || szRegRuleTokens[0] == "HKCCS" ||
           szRegRuleTokens[0] == "HKULM" || szRegRuleTokens[0] == "HKALL")
        {
            for(var i = 0; i < $("selectID_RegRoot").length; ++i)
            {
                if(szRegRuleTokens[0] == $("selectID_RegRoot").options[i].text)
                {
                    $("selectID_RegRoot").selectedIndex = i;
                    break;
                }
            }
            $("textboxID_RegKeyValueToBlock").value = szRegPathUnformatted.substr(szRegRuleTokens[0].length);
        }
        else
        {
            $("textboxID_RegKeyValueToBlock").value = szRegPathUnformatted;
        }
    }

    validateRegistryRule();

}

function fnGetRuleType(szRuleDefintion)
{
	var rtn = RULE_TYPE_UNKNOWN;

	if(-1 != szRuleDefintion.search(/Port\s[IOUT]/))
		rtn = RULE_TYPE_PORT;
	else if(-1 != szRuleDefintion.search(/File\s[RWXCD]/))
		rtn = RULE_TYPE_FILE;
	else if(-1 != szRuleDefintion.search(/Key\s[RWCD]/))
		rtn = RULE_TYPE_REGISTRY;
	else if(-1 != szRuleDefintion.search(/Value\s[RWCD]/))
		rtn = RULE_TYPE_REGISTRY;

	return rtn;
}

function fnBuildPortRuleDefinition()
{
    var szRuleDefinition = "";

    szRuleDefinition += "Port ";
    if($("checkboxID_Inbound").checked)
    {
        szRuleDefinition += "I";
    }
    if($("checkboxID_Outbound").checked)
    {
        szRuleDefinition += "O";
    }
    szRuleDefinition += "UT { Include " + $("ID_StartPort").value + " ";
    if($("ID_EndPort").value != "")
    {
        szRuleDefinition += $("ID_EndPort").value;
    }
    szRuleDefinition += " }";

    return szRuleDefinition;
}

function fnBuildFileRuleDefinition()
{
    var szRuleDefinition = "";

    szRuleDefinition += "File ";
    if($("checkboxID_ReadAccess").checked)
    {
        szRuleDefinition += "R";
    }
    if($("checkboxID_WriteAccess").checked)
    {
        szRuleDefinition += "W";
    }
    if($("checkboxID_ExecuteAccess").checked)
    {
        szRuleDefinition += "X";
    }
    if($("checkboxID_CreateAccess").checked)
    {
        szRuleDefinition += "C";
    }
    if($("checkboxID_DeleteAccess").checked)
    {
        szRuleDefinition += "D";
    }
    szRuleDefinition += " { Include " + TclFormat($("textboxID_FileOrFolderName").value) + " }\n";

    return szRuleDefinition;
}

function fnBuildRegRuleDefinition()
{
	var szRuleDefinition = "";
	var szRegRootText = $("selectID_RegRoot").options[$("selectID_RegRoot").selectedIndex].text;

	if($("radioID_KeyType").checked)
	{
		szRuleDefinition += "Key ";
	}
	else
	{
		szRuleDefinition += "Value ";
	}
	if($("checkboxID_RegWriteAccess").checked)
	{
		szRuleDefinition += "W";
	}
	if($("checkboxID_RegCreateAccess").checked)
	{
		szRuleDefinition += "C";
	}
	if($("checkboxID_RegDeleteAccess").checked)
	{
		szRuleDefinition += "D";
	}
	szRuleDefinition += " {Include ";

	// get the registry path then properly escape it for tcl.
	var szRegistryPathString = "";
	if(szRegRootText != "")
	{
		var szRegKeyValFirstChar = $("textboxID_RegKeyValueToBlock").value.charAt(0);

		szRegistryPathString += szRegRootText;
		if(szRegKeyValFirstChar != "/" && szRegKeyValFirstChar != "\\")
		{
			szRegistryPathString += "/";
		}
	}
	szRegistryPathString += $("textboxID_RegKeyValueToBlock").value.replace(/\\/g, "/");

	szRuleDefinition += TclFormat(szRegistryPathString);
	szRuleDefinition += "}\n";

	return szRuleDefinition;
}

function trackEditedBOFRule(ruleDataItem)
{
    var bAlreadyInList = false;

    for(var i = 0; i < g_editedBOFRules[g_CurrentPolicyType].length; ++i)
    {
        if(g_editedBOFRules[g_CurrentPolicyType][i] == ruleDataItem)
        {
            bAlreadyInList = true;
            break;
        }
    }

    if(!bAlreadyInList)
    {
        g_editedBOFRules[g_CurrentPolicyType].push(ruleDataItem);
    }
}

function trackDeletedUserRule(ruleDataItem)
{
    var bAlreadyInList = false;

    if(ruleDataItem.ruleID == NEW_RULE_ID)
    {
        return;
    }

    for(var i = 0; i < g_deletedUserRules[g_CurrentPolicyType].length; ++i)
    {
        if(g_deletedUserRules[g_CurrentPolicyType][i] == ruleDataItem)
        {
            bAlreadyInList = true;
            break;
        }
    }

    if(!bAlreadyInList)
    {
        g_deletedUserRules[g_CurrentPolicyType].push(ruleDataItem);
    }
}

function ruleListAddCallback(newDiv)
{
    var ruleItem = g_APRuleListWidget.getItem(newDiv.id);
    if(ruleItem != null)
    {
        $(newDiv.id + "_checkbox0").checked = ruleItem.itemData.ruleEnforce;
        $(newDiv.id + "_checkbox1").checked = ruleItem.itemData.ruleReport;

        $(newDiv.id + "_checkbox0").disabled = g_readOnly;
        $(newDiv.id + "_checkbox1").disabled = g_readOnly;
    }
}

function ruleListCheckboxOnClickCallback(evt)
{
    var checkboxID = "";
    var rowID = "";

    if(evt != null)
    {
        checkboxID = evt.target.id;
    }
    else
    {
        checkboxID =  window.event.srcElement.id;
    }

    rowID = $(checkboxID).parentNode.parentNode.id;

    if(rowID != "")
    {
        var ruleItem = g_APRuleListWidget.getItem(rowID);
        if(ruleItem != null)
        {
            var checkboxNum = checkboxID.replace(rowID + "_", "")
            if(checkboxNum == "checkbox0")
            {
                ruleItem.itemData.ruleEnforce = $(checkboxID).checked
            }
            else
            {
                ruleItem.itemData.ruleReport = $(checkboxID).checked
            }

            var selectedCategoryItem = g_APCategoryListWidget.getSelected();
            if (selectedCategoryItem != null)
            {
                if (selectedCategoryItem.itemData.categoryID != "G_User")
                {
                    trackEditedBOFRule(ruleItem.itemData);
                }
            }
            validatePolicy();            
        }
    }
}

function displayAPCategories()
{
    g_APCategoryListWidget.clearList();

    for (var i = 0; i < arrCategoryData[g_CurrentPolicyType].length; ++i)
    {
        var item = new VSE.ListItem();
        item.displayText = arrCategoryData[g_CurrentPolicyType][i].categoryName;
        item.itemData = arrCategoryData[g_CurrentPolicyType][i];
        g_APCategoryListWidget.add(item);
    }

    if(g_APRuleListWidget != null)
        g_APRuleListWidget.clearList();
}

function storePolicyData(policyType)
{
    // We don't need to store the rule data because it is already stored in variables.
    // Only need to store AP, Self Protection, and Log settings
    bAPEnabled[g_CurrentPolicyType] = $("checkboxID_APEnabled").checked;
    bLockdownEnabled[g_CurrentPolicyType] = $("checkboxID_LockdownEnabled").checked;
    logFileFormat[g_CurrentPolicyType] = $("selectID_LogFileFormat").selectedIndex;
    bLogToFile[g_CurrentPolicyType] = $("checkboxID_LogToFile").checked;
    szLogFileName[g_CurrentPolicyType] = $("textboxID_LogFileName").value;
    bLimitSize[g_CurrentPolicyType] = $("checkboxID_LimitLogFileSize").checked;
    dwMaxLogSizeMB[g_CurrentPolicyType] = $("textboxID_MaxLogSize").value;
}

function displayPolicyData(policyType)
{
    displayAPCategories();

    // Display AP Settings
    _APTabInit();

    // Display Report Settings
    _reportsTabInit();

    _doReadonly();
}

function IsDuplicateRuleName(ruleName)
{
    var bReturn = false;
    var selectedRuleItem = g_APRuleListWidget.getSelected();
    var bExists = true;

    if(selectedRuleItem == null)
    {
        bExists = false;
    }

    if(g_arrListRuleData[g_CurrentPolicyType]["G_User"] != null)
    {
        for(var i = 0; i < g_arrListRuleData[g_CurrentPolicyType]["G_User"].length; ++i)
        {
            if(ruleName == g_arrListRuleData[g_CurrentPolicyType]["G_User"][i].ruleName)
            {
                if(g_isNew)
                {
                    bReturn = true;
                    break;                    
                }
                else
                { 
		  if(bExists)
                  {
                    if(selectedRuleItem &&
                       selectedRuleItem.itemData.ruleName != g_arrListRuleData[g_CurrentPolicyType]["G_User"][i].ruleName)
                    {
                        bReturn = true;
                        break;
                    }
                  }
                }
            }
        }
    }
    return bReturn;
}