var g_locationsAddWidget;
var g_exclusionsAddWidget;
var g_bMASInstalled;

// Note: these values only appear in the registry and should NOT be localized.
var g_ScanItemValues = new Array();
g_ScanItemValues[0] = "Invalid";
g_ScanItemValues[1] = "SpecialScanForRootkits";
g_ScanItemValues[2] = "SpecialMemory";
g_ScanItemValues[3] = "SpecialCritical";
g_ScanItemValues[4] = "My Computer";
g_ScanItemValues[5] = "LocalDrives";
g_ScanItemValues[6] = "All fixed disks";
g_ScanItemValues[7] = "All removable media";
g_ScanItemValues[8] = "All Network drives";
g_ScanItemValues[9] = "HomeDir";
g_ScanItemValues[10] = "ProfileDir";
g_ScanItemValues[11] = "WinDir";
g_ScanItemValues[12] = "ProgramFilesDir";
g_ScanItemValues[13] = "TempDir";
g_ScanItemValues[14] = "SpecialRecycleName";
g_ScanItemValues[15] = "DriveOrFolder";
g_ScanItemValues[16] = "File";
g_ScanItemValues[17] = "SpecialRegistrySpyware";
g_ScanItemValues[18] = "SpecialCookiesSpyware";

var SCAN_ITEM_FOLDER 	= 15;
var SCAN_ITEM_FILE	= 16;
var SCAN_ITEM_REGISTRY = 17;
var SCAN_ITEM_COOKIES = 18;

var ACTION_VALUE_INVALID	= 0;
var ACTION_VALUE_CONTINUE	= 1;
var ACTION_VALUE_MOVE		= 3;
var ACTION_VALUE_DELETE		= 4;
var ACTION_VALUE_CLEAN		= 5;

var ACTION_INDEX_CONTINUE	= 0;
var ACTION_INDEX_CLEAN		= 1;
//var ACTION_INDEX_MOVE		= 2;
var ACTION_INDEX_DELETE		= 2;

var g_iCurrentPrimaryActionValue 			= 0;
var g_iCurrentPrimaryActionUnwantedValue 	= 0;
var g_iCurrentSecondaryActionValue			= 0;
var g_iCurrentSecondaryActionUnwantedValue	= 0;
var g_ScanItemsCount = 0;

// Exclusions constants to OR against the "flags" value..
var ON_READ 		= 2;
var ON_WRITE		= 1;
var INCLUDE_SUBFOLDERS	= 4;

// Exclusions
var addeditExclDialog = null;
var g_bNewExclusion = false;
var g_ExclusionListWidget;
var g_arrListExclusionData;
var ExclusionsList;

ExclusionDataItem = function(obj)
{
    var exclData = "";
}


// Global DOM objects
var g_primaryActionSelect;
var g_secondaryActionSelect;
var g_primaryActionSelectUnwanted;
var g_secondaryActionSelectUnwanted;

// ===========================================================================
// ===========================================================================
function fnSetPrimaryAction(selectID_CurrentAction, iPrimaryValue)
{
	for (var i = 0; i < selectID_CurrentAction.length; i++)
	{
		if ( parseInt(selectID_CurrentAction.options[i].value) == parseInt(iPrimaryValue) )
		{
			selectID_CurrentAction.selectedIndex = i;
		}
	}
}

// ===========================================================================
// ===========================================================================
function fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue)
{
	for(var i=0; i<selectID_CurrentSecondaryAction.length;i++)
	{
		if (selectID_CurrentSecondaryAction.options[i].value == iSecondaryValue)
		{
			selectID_CurrentSecondaryAction.selectedIndex = i;
		}
	}
}

// ===========================================================================
// ===========================================================================
function fnSecondaryAction_OnChange(selectID_CurrentSecondaryAction, iSecondaryValue, bPromptForDelete)
{
    if( selectID_CurrentSecondaryAction == g_secondaryActionSelect )
    {
        g_iCurrentSecondaryActionValue = iSecondaryValue;
    }
    else if( selectID_CurrentSecondaryAction == g_secondaryActionSelectUnwanted )
    {
        g_iCurrentSecondaryActionProgramValue = iSecondaryValue;
    }

    fnSetSecondaryActionValue(selectID_CurrentSecondaryAction, iSecondaryValue);
}

// ===========================================================================
// ===========================================================================
function locAddCallback(newDiv)
{
    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("locationsList_awrow_", "");
        var hiddenValueName = "locationsList_hiddenvalue_" + itemID;
        var hiddenValueElement = document.getElementById(hiddenValueName);
        var hiddenValue = g_ScanItemValues[0];
        var pathValueElement = document.getElementById("item_path_" + itemID);
        var selectElement = document.getElementById("select_location_" + itemID);

        if(hiddenValueElement != null)
        {
            if(hiddenValueElement.value != "")
            {
                hiddenValue = hiddenValueElement.value;
            }
        }

        // clear the path value for newly added items
        if(hiddenValue == g_ScanItemValues[0])
        {

            if(pathValueElement != null)
            {
                pathValueElement.value = "";
            }
        }

        // set the selection index to the appropriate index based on the the value of
        // the select object.
        var bSelectedItemSet = false;
        if(selectElement != null)
        {
            for(var i = 0; i < SCAN_ITEM_FOLDER; ++i)
            {
                if(hiddenValue == g_ScanItemValues[i])
                {
                    selectElement.selectedIndex = i;
                    bSelectedItemSet = true;
                }
            }

            if(hiddenValue == g_ScanItemValues[SCAN_ITEM_REGISTRY])
            {
                selectElement.selectedIndex = SCAN_ITEM_REGISTRY;
                bSelectedItemSet = true;
            }
            else if(hiddenValue == g_ScanItemValues[SCAN_ITEM_COOKIES])
            {
                selectElement.selectedIndex = SCAN_ITEM_COOKIES;
                bSelectedItemSet = true;
            }

        }

        // The value was not found so it is either a folder or a file
        if(!bSelectedItemSet)
        {
            pathValueElement.value = hiddenValue;
            // if the value ends in a slash, it's a folder
            if(hiddenValue.charAt(hiddenValue.length-1) == "\\")
            {
                selectElement.selectedIndex = SCAN_ITEM_FOLDER;
            }
            else
            {
                selectElement.selectedIndex = SCAN_ITEM_FILE;
            }
            showPathInput(itemID, selectElement.selectedIndex, true);
        }

        // Register Event Handlers
        OrionEvent.registerHandlerById("select_location_" + itemID,
                                       function() {selectScanItemChange($("select_location_" + itemID)); validateTask();},
                                       null,
                                       "change",
                                       false);

        OrionEvent.registerHandlerById("item_path_" + itemID,
                                       function() {locationPathOnBlur($("item_path_" + itemID)); },
                                       null,
                                       "blur",
                                       false);

        OrionEvent.registerHandlerById("item_path_" + itemID,
                                       function() {locationPathOnKeyup($("item_path_" + itemID)); validateTask();},
                                       null,
                                       "keyup",
                                       false);

        updateLocationIDList();
        onChange();
    }
}

// ===========================================================================
// ===========================================================================
function locRemoveCallback()
{
    updateLocationIDList();
    onChange();
}

// ===========================================================================
// ===========================================================================
function selectScanItemChange(selectItem)
{
    var itemValue = selectItem.value;
    var itemID = selectItem.id.replace("select_location_", "");
    var bMatchFound = false;

    if(itemValue != "Invalid" && itemValue != "DriveOrFolder" && itemValue != "File")
    {
        var matchCount = 0;
        // loop through the list of locations and look for more than one instance of value
        var myrows = g_locationsAddWidget.getList();
        for(var i in myrows)
        {
            var currentElement = document.getElementById("select_location_" + myrows[i].replace("locationsList_awrow_", ""));
            if(currentElement.value == itemValue)
            {
                ++matchCount;
            }
        }

        if(matchCount > 1)
        {
            selectItem.selectedIndex = 0;
            itemValue = selectItem.value;
        }
    }

    if(itemValue == "DriveOrFolder")
    {
        showPathInput(itemID, SCAN_ITEM_FOLDER, true);
        validatePath(itemID);
    }
    else if(itemValue == "File")
    {
        showPathInput(itemID, SCAN_ITEM_FILE, true);
        validatePath(itemID);
    }
    else
    {
        showPathInput(itemID, 0, false);
    }

    updateLocationIDList();
    onChange();
}

// ===========================================================================
// ===========================================================================
function updateLocationIDList()
{
    // update the hidden list of element ID's containing values
    var myrows = g_locationsAddWidget.getList();
    var elementIDList = "";
    for(var i in myrows)
    {
        var currentItemID = myrows[i].replace("locationsList_awrow_", "");
        var currentElement = $("select_location_" + currentItemID);

        if(currentElement.value == "DriveOrFolder" || currentElement.value == "File")
        {
            elementIDList += ("item_path_" + currentItemID);
        }
        else
        {
            elementIDList += ("select_location_" + currentItemID);
        }

        elementIDList += ",";
    }

    $("hiddenID_LocationItemIDList").value = elementIDList.substring(0, elementIDList.length-1);
}

// ===========================================================================
// ===========================================================================
function locationPathOnKeyup(locationPathInput)
{
    var itemValue = locationPathInput.value;
    var itemID = locationPathInput.id.replace("item_path_", "");
    var hiddenSelectValueInput = $("select_hidden_value_");

    validatePath(itemID);
    onChange();
}

// ===========================================================================
// add the backslash to the path if it is missing for folders
// ===========================================================================
function locationPathOnBlur(locationPathInput)
{
    var itemValue = locationPathInput.value;
    var itemID = locationPathInput.id.replace("item_path_", "");
    var scanItemSelectionValue = $("select_location_" + itemID).value;

    if(IsValidODSFile(itemValue))
    {
        if((scanItemSelectionValue == "DriveOrFolder"))
        {
            var lastchar = itemValue.length-1;
            var lastcharval = itemValue.lastIndexOf('\\');
            if(lastcharval!=lastchar)
            {
               itemValue += "\\";
            }
            locationPathInput.value = itemValue;
        }
    }
}

// ===========================================================================
// ===========================================================================
function showPathInput(itemID, scanItemType, bShow)
{
    var pathDivElement = document.getElementById("div_itempath_" + itemID);

    if(pathDivElement != null)
    {
        if(bShow)
        {
            pathDivElement.style.display ="inline";
            if(scanItemType == SCAN_ITEM_FOLDER)
            {
                $("labelID_path_" + itemID).style.display = "";
                $("labelID_filename_" + itemID).style.display = "none";
            }
            else
            {
                $("labelID_path_" + itemID).style.display = "none";
                $("labelID_filename_" + itemID).style.display = "";
            }
        }
        else
        {
            pathDivElement.style.display = "none";
        }
    }
}

// ===========================================================================
// Callback function that is called whenever an item is added to the
// ListWidget2 for the exclusion list.
//
// The data that was passed into the Add function when the item was added
// to the list is available in the exclusionList_hiddenvalue_X element.
// This data is parsed and used to select the appropriate type of
// exlcusion and to fill in the necessary data.
//
// INPUT: The container object for the item that was just added to the list.
// ===========================================================================
function Exclusion_AddCallback(newDiv)
{
    if(newDiv != null)
    {
        var itemID = newDiv.id.replace("divID_ExclusionsList_lwrow_", "");
        var exclusionItemElement = $("exclusion_item_" + itemID);
        var exclusionSubsElement = $("exclusion_include_subs_" + itemID);
        var exclusionAccessElement = $("exclusion_read_write_" + itemID);
        var hiddenValue = "||";

        var ruleItem = g_ExclusionListWidget.getItem(newDiv.id);
        if(ruleItem != null)
        {
            hiddenValue = ruleItem.itemData.exclData;
        }

        if(hiddenValue != "||" && hiddenValue !="")
        {
            var exclusionSplit = hiddenValue.split("|");
            if(exclusionSplit.length > 0)
            {
                var exclusionFlags = 0;
                if(exclusionSplit[1])
                {
                    exclusionFlags = parseInt(exclusionSplit[1]);
                }

                $("labelID_SubsYes_" + itemID).style.display = "None";
                $("labelID_SubsNo_" + itemID).style.display = "None";
                $("labelID_SubsNA_" + itemID).style.display = "";

                // exclusion is by age
                if(exclusionSplit[0] >= "0" && exclusionSplit[0] <= "2")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        if(exclusionSplit[0] == "0")
                        {
                            $("labelID_TypeModifiedAge_" + itemID).style.display = "";
                            $("labelID_TypeModifiedAge_" + itemID).innerHTML = $("labelID_TypeModifiedAge_" + itemID).innerHTML.replace("DDD", exclusionSplit[2]);
                        }
                        else if(exclusionSplit[0] == "1")
                        {
                            $("labelID_TypeAccessedAge_" + itemID).style.display = "";
                            $("labelID_TypeAccessedAge_" + itemID).innerHTML = $("labelID_TypeAccessedAge_" + itemID).innerHTML.replace("DDD", exclusionSplit[2]);
                        }
                        else if(exclusionSplit[0] == "2")
                        {
                            $("labelID_TypeCreatedAge_" + itemID).style.display = "";
                            $("labelID_TypeCreatedAge_" + itemID).innerHTML = $("labelID_TypeCreatedAge_" + itemID).innerHTML.replace("DDD", exclusionSplit[2]);
                        }
                    }
                }
                // By pattern
                else if(exclusionSplit[0] == "3")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        $("labelID_Pattern_" + itemID).style.display = "";
                        $("labelID_Pattern_" + itemID).innerHTML = exclusionSplit[2];

                        if(exclusionFlags & INCLUDE_SUBFOLDERS)
                        {
                            $("labelID_SubsYes_" + itemID).style.display = "";
                            $("labelID_SubsNo_" + itemID).style.display = "None";
                            $("labelID_SubsNA_" + itemID).style.display = "None";
                        }
                        else
                        {
                            $("labelID_SubsYes_" + itemID).style.display = "None";
                            $("labelID_SubsNo_" + itemID).style.display = "";
                            $("labelID_SubsNA_" + itemID).style.display = "None";
                        }
                    }
                }
                // By file type
                else if(exclusionSplit[0] == "4")
                {
                    if(exclusionSplit[1] && exclusionSplit[2])
                    {
                        if(exclusionSplit[2] == ":::")
                        {
                            $("labelID_TypeNoExt_" + itemID).style.display = "";
                        }
                        else
                        {
                            $("labelID_TypeExt_" + itemID).style.display = "";
                            $("labelID_TypeExt_" + itemID).innerHTML = $("labelID_TypeExt_" + itemID).innerHTML.replace("TTT", exclusionSplit[2]);
                        }
                    }
                }
                // Windows Filexe Protection
                else if(exclusionSplit[0] == "5")
                {
                    $("labelID_TypeWFP_" + itemID).style.display = "";
                }
                // Unknown -- should never get here
                else
                {
                    exclusionItemElement.innerHTML = "Error";
                }

                var bOnRead = exclusionFlags & ON_READ;
                var bOnWrite = exclusionFlags & ON_WRITE;

                if(bOnRead && bOnWrite)
                {
                    $("labelID_ExclOnRead_" + itemID).style.display = "";
                    $("labelID_ExclSlash_" + itemID).style.display = "";
                    $("labelID_ExclOnWrite_" + itemID).style.display = "";
                }
                else if(bOnRead)
                {
                    $("labelID_ExclOnRead_" + itemID).style.display = "";
                    $("labelID_ExclSlash_" + itemID).style.display = "none";
                    $("labelID_ExclOnWrite_" + itemID).style.display = "none";
                }
                else if(bOnWrite)
                {
                    $("labelID_ExclOnRead_" + itemID).style.display = "none";
                    $("labelID_ExclSlash_" + itemID).style.display = "none";
                    $("labelID_ExclOnWrite_" + itemID).style.display = "";
                }
            }

            // Widen subs column and hide Access type column for ODS 
            exclusionSubsElement.style.width = "40%";
            exclusionAccessElement.style.width = "0%";
            exclusionAccessElement.style.display = "none";

            updateExclList();
        }
    }
}

function exclUpdateRowDataCallback(selectedRow)
{
    // Update ExclusionData with data stored in Widget
    var exclItems = g_ExclusionListWidget.getItemList();
    g_arrListExclusionData = new Array();
    for(i = 0; i < exclItems.length; ++i)
    {
        g_arrListExclusionData[i] = exclItems[i].itemData;
    }

    populateExclusionsList();
}

// ===========================================================================
// Callback function that is passed into the ListWidget2 to be called whenever
// an item is removed from the exclusion list.
// ===========================================================================
function exclRemoveCallback()
{
    validateTask();
    updateExclList();
}

// ===========================================================================
// Updates the hidden exclusion list that stores a list of exclusions
//
// The list is a comma-separated list of exclusions
// ===========================================================================
function updateExclList()
{
    var exclItems = g_ExclusionListWidget.getItemList();
    var szExclusionList = "";

    for(var i = 0; i < exclItems.length; ++i)
    {
        if(exclItems[i].itemData.exclData != "")
        {
            szExclusionList += exclItems[i].itemData.exclData;
            if((i+1) < exclItems.length)
            {
                szExclusionList += ",";
            }
        }
    }
    $("hiddenID_ExclusionList").value = szExclusionList;
}

// ===========================================================================
// Validates the path element and displays an error if the path is invalid
//
// INPUT: The ID of the path element that contains the value to be checked.
// ===========================================================================
function validatePath(itemID)
{
    var szPath = $("item_path_"+itemID).value;

    if((szPath == "") || !IsValidODSFile(szPath))
    {
        $("labelID_path_error_" + itemID).style.display = "";
    }
    else
    {
        $("labelID_path_error_" + itemID).style.display = "none";
    }
}

// ===========================================================================
// Check for invalid characters in the filename/folder path
//
// INPUT: The filename/folderpath to be checked.
// RETURNS: true if the path is valid. false otherwise
// ===========================================================================
function IsValidODSFile(szPath)
{
    var r;

    r = szPath.indexOf("/");

    if (r == -1)
        r = szPath.indexOf("\"");

    if (r == -1)
        r = szPath.indexOf("|");

    if (r == -1)
        r = szPath.indexOf(";");

    return r == -1;
}

// ===========================================================================
// Function to validate both items that are handled and not handled by Orion
// validatoin
//
// REUTRN: true if the task contains valid data. false otherwise.
// ===========================================================================
function isTaskValid()
{
    var valid = true;
    var myrows = g_locationsAddWidget.getList();
    for(var i in myrows)
    {
        var currentItemID = myrows[i].replace("locationsList_awrow_", "");
        var currentElement = $("select_location_" + currentItemID);

        if(currentElement.value == "DriveOrFolder" || currentElement.value == "File")
        {
            var pathValue = $("item_path_" + currentItemID).value;
            if((pathValue == "") || !IsValidODSFile(pathValue))
            {
                valid = false;
                break;
            }
        }
    }

    if(valid)
    {
        // if still valid, use orion validation to determine whether or not the task is valid.
        // this will work only for items that have an onvalidate attribute.
        valid = OrionForm.isFormValid();
    }

    return valid;
}

function IsValidExclusionPattern(szPattern)
{
    var r;
    var patternlen = 0;
    var wildcharlen = 0;
    
    r = szPattern.indexOf("/");

	if(r == -1)
		r = szPattern.indexOf("|");

    if(r == -1)
		r = szPattern.indexOf("<");

    if(r == -1)
		r = szPattern.indexOf(">");

    //we do not allow only the wildchars (?,*) in the 'by Pattern' field. For eg: ***, ???, *?*.
    if(r == -1)
    {
         patternlen = szPattern.length;
         for(var i=0; i<patternlen; i++)
         {
            if(szPattern.charAt(i)=="*" || szPattern.charAt(i) == "?")
            wildcharlen++;
          }

         if(patternlen!=wildcharlen)
            return true;
    }
    return false;
}

function IsValidExclusionFileType(szFiletype)
{
    var r;
    var filetypelen = 0;
    var wildcharlen = 0;

    if(szFiletype == ":::")
        return true;

    r = szFiletype.indexOf("/");

	if(r == -1)
		r = szFiletype.indexOf("\"");

	if(r == -1)
		r = szFiletype.indexOf("|");

    if(r == -1)
		r = szFiletype.indexOf("<");

    if(r == -1)
		r = szFiletype.indexOf(">");

    if(r == -1)
		r = szFiletype.indexOf(":");

    if(r == -1)
		r = szFiletype.indexOf("\\");

    //we do not allow * on the vse console
    if(r == -1)
		r = szFiletype.indexOf("*");

    // we do not allow just ? in the filetype field, for eg: ???, ?? etc.
    if(r == -1)
	{
       filetypelen = szFiletype.length;
       for(var i=0; i<filetypelen; i++)
       {
          if(szFiletype.charAt(i) == "?")
           wildcharlen++;
       }
        if(filetypelen != wildcharlen)
        return true;
    }
    
	return false;
}

function IsValidFileAge(szFileAge)
{
    var valid = true;

    if(szFileAge == "")
        return false;

    for(var i=0; i < szFileAge.length; ++i)
    {
        if(szFileAge.charAt(i) < "0" || szFileAge.charAt(i) > "9")
        {
            valid = false;
            break;
        }
    }

    var fileAge = parseInt(szFileAge);

    if(valid)
    {
        valid = !(fileAge < 1 || fileAge > 9999);
    }

    return valid;
}

function enableUnwantedProgramsActions(enable)
{
    $("selectID_UnwantedPrimaryAction").disabled = !enable;
    $("selectID_UnwantedSecondaryAction").disabled = !enable;
}

function requireSpecifiedFileTypes(require)
{
    OrionForm.setFieldRequired("textareaID_SpecifiedFileTypes", require);
}

// ===========================================================================
// Generic event handler for items that do not need specific handling when
// their state is changed.
// ===========================================================================
function onChange()
{
    validateTask();
}

// ===========================================================================
// Called by orion whenever the state of the form changes (checkbox checked,
// textbox edited, etc.)
//
// We use this to deteremine whether or not the Next button should be
// enabled
// ===========================================================================
function taskStateChangeHandler( isDirty, isValid )
{
    if(isValid && isDirty)
    {
        OrionWizard.enableNavigation();
    }
    else
    {
        OrionWizard.disableNavigation();
    }
}

// ===========================================================================
// Validator for File Types text boxes
//
// ===========================================================================
function validateFileTypes(szFileTypes)
{
    var valid = true;
    var filetypelen = 0;
    var wildcharlen = 0;
    
    if(szFileTypes != "")
    {
        // convert whitespace to spaces
        szFileTypes.replace(/\W+/g,' ');
        var szFileTypeTokens = szFileTypes.split(" ");

        var r = szFileTypes.indexOf("/");

        if (r == -1)
            r = szFileTypes.indexOf("\"");

        if (r == -1)
            r = szFileTypes.indexOf("|");

        if (r == -1)
            r = szFileTypes.indexOf("<");

        if (r == -1)
            r = szFileTypes.indexOf(">");

        if (r == -1)
            r = szFileTypes.indexOf("\\");

        //We do not allow * for filetypes.

        if (r == -1)
            r = szFileTypes.indexOf("*");

        //We do not allow only ? for filetype, for eg: ?, ???
        if (r == -1)
        {
           filetypelen = szFileTypes.length;

           for(var i=0; i<filetypelen; i++)
           {
                if(szFileTypes.charAt(i) == "?")
                {
                    wildcharlen++;
                }
            }

            if(filetypelen == wildcharlen)
                valid = false;
        }
        
        if(r != -1)
        {
            valid = false;
        }

        for(var i=0; valid && (i < szFileTypeTokens.length); ++i)
        {
            if(szFileTypeTokens[i].length > 3)
            {
                valid = false;
            }
            else if(szFileTypeTokens[i] != ":::") 
            {
                r = szFileTypeTokens[i].indexOf(":");
                if (r != -1)
                {
                    valid = false;
                }
            }
        }
        
    }

    return valid;
}

function validateExclusions(exclusionRows)
{
    var elementIDList = "";
    for(var i in exclusionRows)
    {
        var currentItemID = exclusionRows[i].replace("exclusionsList_awrow_", "");
        var exclusionType = $("select_exclusion_" + currentItemID).value;

        if(exclusionType == 1) // by pattern
        {
            if($("excl_pattern_" + currentItemID).value == "")
            {
               return false;
            }
        }
        else if(exclusionType == 2) // by type
        {
            if($("excl_filetype_" + currentItemID).value == "")
            {
                return false;
            }
        }
        else if(exclusionType == 3) // by age
        {
            var fileAge = $("excl_fileage_" + currentItemID).value;
            if(fileAge == "" || fileAge < 1 || fileAge > 9999)
            {
                return false;
            }
        }
    }

    return true;
}

function validateScanLocations(scanLocationRows)
{
    var valid = true;
    for(var i in scanLocationRows)
    {
        var currentItemID = scanLocationRows[i].replace("locationsList_awrow_", "");
        var locationSelection = $("select_location_" + currentItemID).selectedIndex;
        $("select_location_" + currentItemID + "_empty").style.display = "none";

        if(locationSelection == ACTION_VALUE_INVALID)
        {
            $("select_location_" + currentItemID + "_empty").style.display = "";
            valid = false;
        }
        
        if(locationSelection == SCAN_ITEM_FILE || locationSelection == SCAN_ITEM_FOLDER)
        {
            var szFileName = $("item_path_" + currentItemID).value;
            if(szFileName == null || szFileName == "")
            {
                valid = false;
            }
            
            if(!IsValidODSFile(szFileName))
            {
                valid = false;
            }
        }
    }


    return valid;
}

// ************************************************************************
// ************************************************************************
// Exclusion button click event handlers
// ************************************************************************
// ************************************************************************

// ************************************************************************
// Add Exclusion button handler
// ************************************************************************
function AddExcl_onclick()
{
    g_bNewExclusion = true;
    $("divID_WhenToExcludeContent").style.display = "none";

    addeditExclDialog.showDialog(true);
    addeditExclDialog.setWidth("400px");

    // Show select element that was hidden by dialog code.
    var AccessTypeElement = $("selectID_AccessType");
    if(AccessTypeElement._visibility != null)
    {
        AccessTypeElement.style.visibility = AccessTypeElement._visibility;
        AccessTypeElement._visibility = null;
    }

    $("radioID_ExclByPattern").checked = true;
    $("textboxID_ExclPattern").value = "";
    $("checkboxID_ExclSubfolders").checked = false;
    $("textboxID_ExclFileType").value = "";
    $("textboxID_MinimumAge").value = "";
    $("checkboxID_ExclOnRead").checked = true;
    $("checkboxID_ExclOnWrite").checked = true;

    onExclTypeChange();
}

// ************************************************************************
// Edit existing exclusion button handler
// ************************************************************************
function EditExcl_onclick()
{
    g_bNewExclusion = false;
    $("divID_WhenToExcludeContent").style.display = "none";

    var selectedCategoryItem = g_ExclusionListWidget.getSelected();
    if (selectedCategoryItem == null)
    {
        return;
    }

    var szExclusionItem = g_ExclusionListWidget.getSelected().itemData.exclData;
    if(szExclusionItem == "" && szExclusionItem != "||")
    {
        return;
    }

    addeditExclDialog.showDialog(true);
    addeditExclDialog.setWidth("400px");

    // Show select element that was hidden by dialog code.
    var AccessTypeElement = $("selectID_AccessType");
    if(AccessTypeElement._visibility != null)
    {
        AccessTypeElement.style.visibility = AccessTypeElement._visibility;
        AccessTypeElement._visibility = null;
    }

    $("radioID_ExclByPattern").checked = false;
    $("textboxID_ExclPattern").value = "";
    $("checkboxID_ExclSubfolders").checked = false;
    $("textboxID_ExclFileType").value = "";
    $("textboxID_MinimumAge").value = "";
    $("checkboxID_ExclOnRead").checked = true;
    $("checkboxID_ExclOnWrite").checked = true;

    var exclusionSplit = szExclusionItem.split("|");
    if(exclusionSplit.length > 0)
    {
        var exclusionFlags = 0;
        if(exclusionSplit[1])
        {
            exclusionFlags = parseInt(exclusionSplit[1]);
        }

        // exclusion is by age
        if(exclusionSplit[0] >= "0" && exclusionSplit[0] <= "2")
        {
            if(exclusionSplit[1] && exclusionSplit[2])
            {
                $("radioID_ExclByFileAge").checked = true;
                $("selectID_AccessType").selectedIndex = parseInt(exclusionSplit[0]);
                $("textboxID_MinimumAge").value = exclusionSplit[2];
            }
        }
        // By pattern
        else if(exclusionSplit[0] == "3")
        {
            $("radioID_ExclByPattern").checked = true;
            if(exclusionSplit[1] && exclusionSplit[2])
            {
                $("textboxID_ExclPattern").value = exclusionSplit[2];
                $("checkboxID_ExclSubfolders").checked = (exclusionFlags & INCLUDE_SUBFOLDERS);
            }
        }
        // By file type
        else if(exclusionSplit[0] == "4")
        {
            $("radioID_ExclByFileType").checked = true;
            if(exclusionSplit[1] && exclusionSplit[2])
            {
                if(exclusionSplit[2] == ":::")
                {
                    $("textboxID_ExclFileType").value = "";
                }
                else
                {
                    $("textboxID_ExclFileType").value = exclusionSplit[2];
                }
            }
        }
        // Windows Filexe Protection
        else if(exclusionSplit[0] == "5")
        {
            $("radioID_ExclWindowsProtection").checked = true;
        }

        $("checkboxID_ExclOnRead").checked = exclusionFlags & ON_READ;
        $("checkboxID_ExclOnWrite").checked = exclusionFlags & ON_WRITE;
    }

    onExclTypeChange();
}

// ************************************************************************
// Remove Exclusion button handler
// ************************************************************************
function RemoveExcl_onclick()
{
    g_ExclusionListWidget.removeSelected();
}

// ************************************************************************
// Clear Exclusions button handler
// ************************************************************************
function ClearExcl_onclick()
{
    g_ExclusionListWidget.clearList();
    updateExclList();
}


// ************************************************************************
// ************************************************************************
// Exclusion DialogBox support code
// ************************************************************************
// ************************************************************************
function onAddEditExclOK()
{
    var exclusionFlags = 0;
    var exclusionType = 0;
    var exclusionData = "";

    if($("radioID_ExclByPattern").checked)
    {
        var strExclPattern = new String($("textboxID_ExclPattern").value);
        exclusionType = 3;
        exclusionData = strExclPattern.replace(/^\s+|\s+$/g,'');
        if($("checkboxID_ExclSubfolders").checked)
        {
            exclusionFlags += INCLUDE_SUBFOLDERS;
        }
    }
    else if($("radioID_ExclByFileType").checked)
    {
        exclusionType = 4;
        if($("textboxID_ExclFileType").value != "")
        {
            exclusionData = $("textboxID_ExclFileType").value;
        }
        else
        {
            if(!confirm($("stringID_ConfirmNoExtension").innerHTML))
            {
                return;
            }

            exclusionData = ":::";
        }
    }
    else if($("radioID_ExclByFileAge").checked)
    {
        exclusionType = $("selectID_AccessType").value;
        exclusionData = $("textboxID_MinimumAge").value;
    }
    else if($("radioID_ExclWindowsProtection").checked)
    {
        exclusionType = 5;
    }

    exclusionFlags += ON_READ;
    exclusionFlags += ON_WRITE;

    addeditExclDialog.showDialog(false);

    var szExclusion = exclusionType + "|" + exclusionFlags + "|" + exclusionData;
    var ExclDataItem = new ExclusionDataItem();
    ExclDataItem.exclData = szExclusion;

    if(g_bNewExclusion)
    {
        var item = new VSE.ListItem2();
        item.itemData = ExclDataItem;
        g_ExclusionListWidget.add(item);
    }
    else
    {
        g_ExclusionListWidget.getSelected().itemData = ExclDataItem;
    }

    g_ExclusionListWidget.selectedRowUpdate();
}

function onAddEditExclCancel()
{
    addeditExclDialog.showDialog(false);
}

function onExclTypeChange()
{
    $("textboxID_ExclPattern").disabled = true;
    $("checkboxID_ExclSubfolders").disabled = true;
    $("textboxID_ExclFileType").disabled = true;
    $("labelID_AccessType").disabled = true;
    $("selectID_AccessType").disabled = true;
    $("labelID_MinimumAge").disabled = true;
    $("textboxID_MinimumAge").disabled = true;

    if($("radioID_ExclByPattern").checked)
    {
        $("textboxID_ExclPattern").disabled = false;
        $("checkboxID_ExclSubfolders").disabled = false;
    }
    else if($("radioID_ExclByFileType").checked)
    {
        $("textboxID_ExclFileType").disabled = false;
    }
    else if($("radioID_ExclByFileAge").checked)
    {
        $("labelID_AccessType").disabled = false;
        $("selectID_AccessType").disabled = false;
        $("labelID_MinimumAge").disabled = false;
        $("textboxID_MinimumAge").disabled = false;
    }

    validateExclusion();
}

function validateExclusion()
{
    var valid = false;

    $("exclusion_pattern_error").style.display = "none";
    $("exclusion_pattern_empty").style.display = "none";
    $("exclusion_filetype_error").style.display = "none";
    $("exclusion_fileage_error").style.display = "none";
    $("exclusion_fileage_empty").style.display = "none";
    $("exclusion_whentoexclude_empty").style.display = "none";

    if($("radioID_ExclByPattern").checked)
    {
        if($("textboxID_ExclPattern").value == "")
        {
            $("exclusion_pattern_empty").style.display = "";
        }
        else
        {
            valid = IsValidExclusionPattern($("textboxID_ExclPattern").value);
            if(!valid)
            {
                $("exclusion_pattern_error").style.display = "";
            }
        }
    }
    else if($("radioID_ExclByFileType").checked)
    {
        if($("textboxID_ExclFileType").value != "")
        {
            valid = IsValidExclusionFileType($("textboxID_ExclFileType").value);
            if(!valid)
            {
                $("exclusion_filetype_error").style.display = "";
            }
        }
        else
        {
            valid = true;
        }
    }
    else if($("radioID_ExclByFileAge").checked)
    {
        if($("textboxID_MinimumAge").value == "")
        {
            $("exclusion_fileage_empty").style.display = "";
        }
        else
        {
            valid = IsValidFileAge($("textboxID_MinimumAge").value);
            if(!valid)
            {
                $("exclusion_fileage_error").style.display = "";
            }
        }
    }
    else if($("radioID_ExclWindowsProtection").checked)
    {
        valid = true;
    }

    $("buttonID_ruleTypeSelectOK").disabled = !valid;
}

// *******************************************************************
// removeNoExtensionMarker - Removes all ::: entries
//
// Input: szExtensions - whitespace delimited list of extensions
//
// Returns: A space delimited list of extensions with ::: removed
// *******************************************************************
function removeNoExtensionMarker(szExtensions)
{
    var szReturn = "";
    var szExtItems = szExtensions.split(/\s+/);
    szExtItems = szExtItems.sort();

    for(var i=0; i < szExtItems.length; ++i)
    {
        if(szExtItems[i] != ":::")
        {
            szReturn += szExtItems[i];
        }

        if(i < szExtItems.length - 1 &&  szReturn != "")
        {
            szReturn += " ";
        }
    }

    return szReturn;
}